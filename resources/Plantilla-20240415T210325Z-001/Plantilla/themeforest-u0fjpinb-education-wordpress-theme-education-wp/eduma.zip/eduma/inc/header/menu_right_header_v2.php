<?php
if( is_active_sidebar( 'menu_top' ) ) {
	dynamic_sidebar( 'menu_top' );
}