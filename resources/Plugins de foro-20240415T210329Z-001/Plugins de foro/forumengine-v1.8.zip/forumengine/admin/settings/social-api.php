<div id="setting-social" class="inner-content et-main-main clearfix hide">
    <?php
    $facebook_key    = et_get_option("et_facebook_key");
    $facebook_secret = et_get_option("et_facebook_secret");
    $gplus_client_id = et_get_option("gplus_client_id");
    $gplus_secret_id = et_get_option("gplus_secret_id");
    $validator       = new ET_Validator();
    ?>
    <!-- GENERAL -->
    <div class="title font-quicksand"><?php _e("Facebook Login API", ET_DOMAIN); ?></div>
    <div class="desc">
        <?php _e("Enabling this will allow users to login via Facebook.", ET_DOMAIN); ?>
        <div class="inner no-border btn-left">
            <div class="payment">
                <?php et_toggle_button('facebook_login', __("Facebook Login", ET_DOMAIN), get_option('facebook_login', false)); ?>
            </div>
        </div>
        <div class="form no-margin no-background">
            <div class="form-item">
                <div class="label"><?php _e("Facebook Application ID", ET_DOMAIN); ?></div>
                <input class="bg-grey-input <?php if ($facebook_key == "") echo 'color-error' ?>" type="text" value="<?php echo htmlentities($facebook_key) ?>" id="twitter_account" name="et_facebook_key" />
                <span class="icon <?php if ($facebook_key == '') echo 'color-error' ?>" data-icon="<?php data_icon($facebook_key) ?>"></span>
            </div>
            <div class="form-item">
                <div class="label"><?php _e("Facebook Application Secret", ET_DOMAIN); ?></div>
                <input class="bg-grey-input <?php if ($facebook_secret == "") echo 'color-error' ?>" type="text" value="<?php echo htmlentities($facebook_secret) ?>" id="facebook_link" name="et_facebook_secret" />
                <span class="icon <?php if ($facebook_secret == '') echo 'color-error' ?>" data-icon="<?php data_icon($facebook_secret) ?>"></span>
            </div>
        </div>
    </div>

    <div class="title font-quicksand"><?php _e("Google Login API", ET_DOMAIN); ?></div>
    <div class="desc">
        <?php _e("Enabling this will allow users to login using their Google accounts.<br>  (<a target='_blank' href='https://code.google.com/apis/console'>Get key here</a> - <a target='_blank' href='https://developers.google.com/identity/gsi/web/guides/get-google-api-clientid'>Instructions</a>)", ET_DOMAIN) ?>
        <div class="inner no-border btn-left">
            <div class="payment">
                <?php et_toggle_button('gplus_login', __("Google Login", ET_DOMAIN), get_option('gplus_login', false)); ?>
            </div>
        </div>
        <div class="form no-margin no-background">
            <div class="form-item">
                <div class="label"><?php _e("Client ID", ET_DOMAIN); ?></div>
                <input class="bg-grey-input <?php if ($gplus_client_id == "") echo 'color-error' ?>" type="text" value="<?php echo htmlentities($gplus_client_id) ?>" id="twitter_account" name="gplus_client_id" />
                <span class="icon <?php if ($gplus_client_id == '') echo 'color-error' ?>" data-icon="<?php data_icon($gplus_client_id) ?>"></span>
            </div>
            <div class="form-item">
                <div class="label"><?php _e("Client Secret", ET_DOMAIN); ?></div>
                <input class="bg-grey-input <?php if ($gplus_secret_id == "") echo 'color-error' ?>" type="text" value="<?php echo htmlentities($gplus_secret_id) ?>" id="twitter_account" name="gplus_secret_id" />
                <span class="icon <?php if ($gplus_client_id == '') echo 'color-error' ?>" data-icon="<?php data_icon($gplus_secret_id) ?>"></span>
            </div>
        </div>
    </div>

</div> <!-- END #setting-social -->