<?php
class SchClothingStore extends SchStore{
	function __construct(){$this->namespace = "ClothingStore";}
}