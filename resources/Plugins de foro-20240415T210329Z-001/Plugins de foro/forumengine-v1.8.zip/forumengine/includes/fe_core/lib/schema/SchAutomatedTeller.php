<?php
class SchAutomatedTeller extends SchFinancialService{
	function __construct(){$this->namespace = "AutomatedTeller";}
}