<?php
class SchComedyEvent extends SchEvent{
	function __construct(){$this->namespace = "ComedyEvent";}
}