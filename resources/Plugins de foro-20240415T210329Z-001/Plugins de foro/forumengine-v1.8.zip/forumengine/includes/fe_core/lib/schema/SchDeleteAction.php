<?php
class SchDeleteAction extends SchUpdateAction{
	function __construct(){$this->namespace = "DeleteAction";}
}