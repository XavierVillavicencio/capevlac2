<?php
class SchMedicalObservationalStudyDesign extends SchMedicalEnumeration{
	function __construct(){$this->namespace = "MedicalObservationalStudyDesign";}
}