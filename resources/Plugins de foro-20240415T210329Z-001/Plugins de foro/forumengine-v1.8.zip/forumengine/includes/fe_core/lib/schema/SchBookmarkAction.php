<?php
class SchBookmarkAction extends SchOrganizeAction{
	function __construct(){$this->namespace = "BookmarkAction";}
}