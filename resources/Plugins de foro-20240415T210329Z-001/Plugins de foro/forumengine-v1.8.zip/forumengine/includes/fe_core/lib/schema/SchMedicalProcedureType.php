<?php
class SchMedicalProcedureType extends SchMedicalEnumeration{
	function __construct(){$this->namespace = "MedicalProcedureType";}
}