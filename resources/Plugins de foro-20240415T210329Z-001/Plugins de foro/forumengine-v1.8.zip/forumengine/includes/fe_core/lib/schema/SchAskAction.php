<?php
class SchAskAction extends SchCommunicateAction{
	protected $question	=	'Text';
	function __construct(){$this->namespace = "AskAction";}
}