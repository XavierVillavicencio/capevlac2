<?php
class SchMensClothingStore extends SchStore{
	function __construct(){$this->namespace = "MensClothingStore";}
}