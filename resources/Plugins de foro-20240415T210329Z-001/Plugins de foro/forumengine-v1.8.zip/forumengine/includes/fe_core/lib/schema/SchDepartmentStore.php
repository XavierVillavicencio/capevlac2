<?php
class SchDepartmentStore extends SchStore{
	function __construct(){$this->namespace = "DepartmentStore";}
}