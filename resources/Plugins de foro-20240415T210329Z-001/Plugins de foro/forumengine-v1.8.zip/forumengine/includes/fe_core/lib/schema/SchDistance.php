<?php
class SchDistance extends SchQuantity{
	function __construct(){$this->namespace = "Distance";}
}