<?php
class SchMobilePhoneStore extends SchStore{
	function __construct(){$this->namespace = "MobilePhoneStore";}
}