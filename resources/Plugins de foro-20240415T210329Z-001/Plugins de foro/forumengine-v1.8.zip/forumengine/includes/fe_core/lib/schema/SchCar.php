<?php
class SchCar extends SchVehicle{
	function __construct(){$this->namespace = "Car";}
}