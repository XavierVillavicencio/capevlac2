<?php
class SchEmailMessage extends SchCreativeWork{
	function __construct(){$this->namespace = "EmailMessage";}
}