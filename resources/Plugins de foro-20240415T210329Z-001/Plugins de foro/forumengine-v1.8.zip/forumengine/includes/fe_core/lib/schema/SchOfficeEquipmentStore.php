<?php
class SchOfficeEquipmentStore extends SchStore{
	function __construct(){$this->namespace = "OfficeEquipmentStore";}
}