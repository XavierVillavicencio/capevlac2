<?php
class SchMaximumDoseSchedule extends SchDoseSchedule{
	function __construct(){$this->namespace = "MaximumDoseSchedule";}
}