<?php
class SchBrand extends SchIntangible{
	protected $logo	=	'ImageObject,URL';
	function __construct(){$this->namespace = "Brand";}
}