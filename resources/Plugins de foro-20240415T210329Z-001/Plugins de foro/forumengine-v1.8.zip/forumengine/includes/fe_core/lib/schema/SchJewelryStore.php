<?php
class SchJewelryStore extends SchStore{
	function __construct(){$this->namespace = "JewelryStore";}
}