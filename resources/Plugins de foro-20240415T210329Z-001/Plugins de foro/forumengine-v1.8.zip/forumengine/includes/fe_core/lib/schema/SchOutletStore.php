<?php
class SchOutletStore extends SchStore{
	function __construct(){$this->namespace = "OutletStore";}
}