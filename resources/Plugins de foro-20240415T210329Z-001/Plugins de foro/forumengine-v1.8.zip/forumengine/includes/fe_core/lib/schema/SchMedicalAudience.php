<?php
class SchMedicalAudience extends SchEnumeration{
	function __construct(){$this->namespace = "MedicalAudience";}
}