<?php
class SchLandmarksOrHistoricalBuildings extends SchPlace{
	function __construct(){$this->namespace = "LandmarksOrHistoricalBuildings";}
}