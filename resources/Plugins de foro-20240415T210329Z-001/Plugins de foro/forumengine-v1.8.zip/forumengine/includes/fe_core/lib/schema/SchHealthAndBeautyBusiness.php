<?php
class SchHealthAndBeautyBusiness extends SchLocalBusiness{
	function __construct(){$this->namespace = "HealthAndBeautyBusiness";}
}