<?php
class SchLakeBodyOfWater extends SchBodyOfWater{
	function __construct(){$this->namespace = "LakeBodyOfWater";}
}