<?php
class SchMusicVideoObject extends SchMediaObject{
	function __construct(){$this->namespace = "MusicVideoObject";}
}