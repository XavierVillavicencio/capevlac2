<?php
class SchPreschool extends SchEducationalOrganization{
	function __construct(){$this->namespace = "Preschool";}
}