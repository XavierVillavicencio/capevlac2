<?php
class SchMiddleSchool extends SchEducationalOrganization{
	function __construct(){$this->namespace = "MiddleSchool";}
}