<?php
class SchGovernmentBuilding extends SchCivicStructure{
	function __construct(){$this->namespace = "GovernmentBuilding";}
}