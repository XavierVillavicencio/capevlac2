<?php
class SchApartmentComplex extends SchResidence{
	function __construct(){$this->namespace = "ApartmentComplex";}
}