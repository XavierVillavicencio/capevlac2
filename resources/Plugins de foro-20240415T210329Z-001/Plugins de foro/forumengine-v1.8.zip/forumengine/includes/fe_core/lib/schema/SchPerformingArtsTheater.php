<?php
class SchPerformingArtsTheater extends SchCivicStructure{
	function __construct(){$this->namespace = "PerformingArtsTheater";}
}