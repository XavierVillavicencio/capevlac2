<?php
class SchItemAvailability extends SchEnumeration{
	function __construct(){$this->namespace = "ItemAvailability";}
}