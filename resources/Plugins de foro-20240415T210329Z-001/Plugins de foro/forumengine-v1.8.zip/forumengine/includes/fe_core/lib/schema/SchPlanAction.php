<?php
class SchPlanAction extends SchOrganizeAction{
	protected $scheduledTime	=	'DateTime';
	function __construct(){$this->namespace = "PlanAction";}
}