<?php
class SchAdministrativeArea extends SchPlace{
	function __construct(){$this->namespace = "AdministrativeArea";}
}