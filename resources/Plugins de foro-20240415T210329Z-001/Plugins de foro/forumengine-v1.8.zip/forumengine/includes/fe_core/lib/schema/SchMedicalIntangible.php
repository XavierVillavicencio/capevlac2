<?php
class SchMedicalIntangible extends SchMedicalEntity{
	function __construct(){$this->namespace = "MedicalIntangible";}
}