<?php
class SchGatedResidenceCommunity extends SchResidence{
	function __construct(){$this->namespace = "GatedResidenceCommunity";}
}