<?php
class SchComedyClub extends SchEntertainmentBusiness{
	function __construct(){$this->namespace = "ComedyClub";}
}