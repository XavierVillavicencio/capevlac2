<?php
class SchInfectiousAgentClass extends SchEnumeration{
	function __construct(){$this->namespace = "InfectiousAgentClass";}
}