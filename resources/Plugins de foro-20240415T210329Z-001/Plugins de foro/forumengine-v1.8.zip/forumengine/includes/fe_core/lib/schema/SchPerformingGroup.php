<?php
class SchPerformingGroup extends SchOrganization{
	function __construct(){$this->namespace = "PerformingGroup";}
}