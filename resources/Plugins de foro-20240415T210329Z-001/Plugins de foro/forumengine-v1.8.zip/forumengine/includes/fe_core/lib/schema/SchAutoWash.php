<?php
class SchAutoWash extends SchAutomotiveBusiness{
	function __construct(){$this->namespace = "AutoWash";}
}