<?php
class SchIntangible extends SchThing{
	function __construct(){$this->namespace = "Intangible";}
}