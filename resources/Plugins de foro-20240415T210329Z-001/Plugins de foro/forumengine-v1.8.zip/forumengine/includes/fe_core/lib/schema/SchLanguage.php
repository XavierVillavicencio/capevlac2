<?php
class SchLanguage extends SchIntangible{
	function __construct(){$this->namespace = "Language";}
}