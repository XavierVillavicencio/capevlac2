<?php
class SchBedAndBreakfast extends SchLodgingBusiness{
	function __construct(){$this->namespace = "BedAndBreakfast";}
}