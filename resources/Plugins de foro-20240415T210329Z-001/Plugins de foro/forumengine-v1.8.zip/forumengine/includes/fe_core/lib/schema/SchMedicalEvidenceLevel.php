<?php
class SchMedicalEvidenceLevel extends SchEnumeration{
	function __construct(){$this->namespace = "MedicalEvidenceLevel";}
}