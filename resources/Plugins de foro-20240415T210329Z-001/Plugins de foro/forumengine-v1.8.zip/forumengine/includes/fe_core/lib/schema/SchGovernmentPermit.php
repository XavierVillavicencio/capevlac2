<?php
class SchGovernmentPermit extends SchPermit{
	function __construct(){$this->namespace = "GovernmentPermit";}
}