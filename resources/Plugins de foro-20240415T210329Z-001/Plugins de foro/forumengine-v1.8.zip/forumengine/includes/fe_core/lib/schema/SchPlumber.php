<?php
class SchPlumber extends SchProfessionalService{
	function __construct(){$this->namespace = "Plumber";}
}