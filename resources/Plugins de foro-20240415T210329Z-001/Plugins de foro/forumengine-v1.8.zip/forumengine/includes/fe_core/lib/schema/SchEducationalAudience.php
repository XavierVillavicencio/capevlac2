<?php
class SchEducationalAudience extends SchAudience{
	protected $educationalRole	=	'Text';
	function __construct(){$this->namespace = "EducationalAudience";}
}