<?php
class SchMedicalRiskCalculator extends SchMedicalRiskEstimator{
	function __construct(){$this->namespace = "MedicalRiskCalculator";}
}