<?php
class SchMusicEvent extends SchEvent{
	function __construct(){$this->namespace = "MusicEvent";}
}