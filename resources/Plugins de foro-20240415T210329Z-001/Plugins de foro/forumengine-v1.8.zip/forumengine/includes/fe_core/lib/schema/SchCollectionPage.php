<?php
class SchCollectionPage extends SchWebPage{
	function __construct(){$this->namespace = "CollectionPage";}
}