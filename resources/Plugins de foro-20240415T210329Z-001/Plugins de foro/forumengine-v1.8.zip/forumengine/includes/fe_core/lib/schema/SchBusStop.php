<?php
class SchBusStop extends SchCivicStructure{
	function __construct(){$this->namespace = "BusStop";}
}