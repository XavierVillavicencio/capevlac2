<?php
class SchAboutPage extends SchWebPage{
	function __construct(){$this->namespace = "AboutPage";}
}