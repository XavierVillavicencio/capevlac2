<?php
class SchFestival extends SchEvent{
	function __construct(){$this->namespace = "Festival";}
}