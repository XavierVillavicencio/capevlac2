<?php
class SchContactPointOption extends SchEnumeration{
	function __construct(){$this->namespace = "ContactPointOption";}
}