<?php
class SchHVACBusiness extends SchHomeAndConstructionBusiness{
	function __construct(){$this->namespace = "HVACBusiness";}
}