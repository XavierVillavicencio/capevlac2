<?php
class SchPetStore extends SchStore{
	function __construct(){$this->namespace = "PetStore";}
}