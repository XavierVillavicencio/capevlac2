<?php
class SchPaymentMethod extends SchEnumeration{
	function __construct(){$this->namespace = "PaymentMethod";}
}