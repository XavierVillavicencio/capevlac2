<?php
class SchMap extends SchCreativeWork{
	protected $mapType	=	'MapCategoryType';
	function __construct(){$this->namespace = "Map";}
}