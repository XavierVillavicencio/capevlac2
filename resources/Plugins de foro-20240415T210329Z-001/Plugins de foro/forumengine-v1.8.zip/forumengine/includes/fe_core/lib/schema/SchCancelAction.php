<?php
class SchCancelAction extends SchPlanAction{
	function __construct(){$this->namespace = "CancelAction";}
}