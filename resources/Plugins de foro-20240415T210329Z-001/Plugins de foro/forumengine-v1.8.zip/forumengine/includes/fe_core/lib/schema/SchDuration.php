<?php
class SchDuration extends SchQuantity{
	function __construct(){$this->namespace = "Duration";}
}