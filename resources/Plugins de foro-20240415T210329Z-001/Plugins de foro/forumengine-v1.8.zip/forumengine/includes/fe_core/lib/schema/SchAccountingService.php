<?php
class SchAccountingService extends SchFinancialService{
	function __construct(){$this->namespace = "AccountingService";}
}