<?php
class SchAttorney extends SchProfessionalService{
	function __construct(){$this->namespace = "Attorney";}
}