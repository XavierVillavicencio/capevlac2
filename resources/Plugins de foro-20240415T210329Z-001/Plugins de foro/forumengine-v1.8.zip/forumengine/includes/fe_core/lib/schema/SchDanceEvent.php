<?php
class SchDanceEvent extends SchEvent{
	function __construct(){$this->namespace = "DanceEvent";}
}