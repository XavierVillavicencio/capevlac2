<?php
class SchMovingCompany extends SchHomeAndConstructionBusiness{
	function __construct(){$this->namespace = "MovingCompany";}
}