<?php
class SchMedicalIndication extends SchMedicalEntity{
	function __construct(){$this->namespace = "MedicalIndication";}
}