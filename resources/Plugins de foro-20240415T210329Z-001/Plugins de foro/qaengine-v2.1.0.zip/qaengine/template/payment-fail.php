<div class="payment-success">
    <p class="thanks"><?php _e('Your payment has failed, friend.', ET_DOMAIN); ?></p>
    <p class="link"><?php printf(__('You could <a href="%s">buy more pumps to continue</a> or <a href="%s">return home</a>.', ET_DOMAIN), et_get_page_link('buy-package'), get_home_url()); ?></p>
</div>