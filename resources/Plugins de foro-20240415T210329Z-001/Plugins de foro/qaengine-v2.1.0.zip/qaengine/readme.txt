Version 2.1.0
Mar 4, 2023
 * Migrate from the old approach using Google Sign-in to the new API version
 * Compatible to PHP 8.2

Version 2.0.20
Date: Mar 09, 2022
 * Fix google login in mobile version.

Version 2.0.19
Date: Sep 01, 2021
 * Fix php warning.
 * Fix chart in poll question.
 * Fixed pagination.