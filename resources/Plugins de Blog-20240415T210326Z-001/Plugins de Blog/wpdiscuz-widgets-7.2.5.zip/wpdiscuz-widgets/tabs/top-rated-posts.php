<?php if (!defined("ABSPATH")) exit(); ?>

<div id="wpdiscuz-top-rated-posts-box" class="top-rated-posts">
	<?php
	$get_date_mvdi = self::getDateIntervals($top_rated_posts_date_interval);

	if ($top_rated_posts_date_interval == "all_time") {
		$query_date = [];
	} elseif ($top_rated_posts_date_interval == "custom_date") {
		$query_date = [
			"column" => "post_date_gmt",
			[
				"after" => $top_rated_posts_from_date,
				"before" => $top_rated_posts_to_date,
				"inclusive" => true
			]
		];
	} else {
		$query_date = [
			"column" => "post_date_gmt",
			[
				"after" => $get_date_mvdi["from"],
				"inclusive" => true
			]
		];
	}

	$all_posts_args = [
		"numberposts" => $count_top_rated_posts,
		"orderby" => ["meta_value_num", "post_date_gmt"],
		"order" => "DESC",
		"meta_key" => WpDiscuzConstants::POSTMETA_POST_RATING,
		"meta_query" => [
            [
                "meta_key" => WpDiscuzConstants::POSTMETA_POST_RATING,
                "meta_compare" => "!=",
                "meta_value" => "",
                "meta_type" => "decimal",
            ],
        ],
		"date_query" => $query_date
	];

	$all_posts_args = apply_filters("wpdiscuz_widget_top_rated_posts_args", $all_posts_args);

    $posts = get_posts($all_posts_args);

	if ($this->options["wpdiscuz_widget_theme_title_struct"] === 1) {
		echo $before_title . $title_top_rated_posts . $after_title;
	} else {
		echo "<h2 class='wpd_widgets_title'> $title_top_rated_posts </h2>";
	}
	?>
	<div class="wpd_widgets_items_wrapper">
		<?php
		foreach ($posts as $post) {
			if ($this->options["wpdiscuz_widget_post_title_cutting"]) {
				$post_title = get_the_title($post);
				$post_title = wp_trim_words($post_title, $this->options["wpdiscuz_widgets_post_title_word_count"]);
			} else {
				$post_title = get_the_title($post);
			}
			$post_date = date($this->widget_date_format, strtotime($post->post_date_gmt));
			$post_rating = (float) get_post_meta($post->ID, WpDiscuzConstants::POSTMETA_POST_RATING, true);
			$post_rating_count = (int) get_post_meta($post->ID, WpDiscuzConstants::POSTMETA_POST_RATING_COUNT, true);
			$post_rating_prefix = (int) $post_rating;
			$post_rating_suffix = $post_rating - $post_rating_prefix;
			$postLink = get_the_permalink($post);
            ?>
            <div class="wpdiscuz-widget-comment top-rated-posts like-count-first">
                <div class="wpd-widget-comment-top">
                    <div class="wpdiscuz-widget-icon-show-box <?php if ($this->options["wpdiscuz_widget_icon_circle"] === 1) echo "icon-circle"; ?>">
                        <a href="<?php echo $postLink; ?>">
                            <i class="far fa-star"></i>
                        </a>
                        <div class="wpd-widget-comp-count"><?php echo $post_rating ?></div>
                    </div>
                    <div class="wpdiscuz-widget-comment-content">
                        <a href="<?php echo $postLink; ?>"><?php echo $post_title; ?></a>
                        <div class="wpdd-stars">
                            <?php
							$fullStarSVG = apply_filters("wpdiscuz_full_star_svg", "<svg xmlns='https://www.w3.org/2000/svg' width='22' height='22' viewBox='0 0 24 24'><path d='M0 0h24v24H0z' fill='none'/><path class='wpd-star' d='M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z'/><path d='M0 0h24v24H0z' fill='none'/></svg>", "post", "fas fa-star");
							$halfStarSVG = apply_filters("wpdiscuz_half_star_svg", "<svg xmlns='https://www.w3.org/2000/svg' width='22' height='22' xmlns:xlink='https://www.w3.org/1999/xlink' viewBox='0 0 24 24'><defs><path id='a' d='M0 0h24v24H0V0z'/></defs><clipPath id='b'><use xlink:href='#a' overflow='visible'/></clipPath><path class='wpd-star wpd-active' clip-path='url(#b)' d='M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4V6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z'/></svg>", "post", "fas fa-star");
							if ($post_rating_prefix) {
								for ($i = 1; $i < 6; $i++) {
									if ($i <= $post_rating_prefix) {
										echo str_replace("wpd-star", "wpd-star wpd-active", $fullStarSVG);
									} else if ($post_rating_suffix && $i - $post_rating_prefix === 1) {
										echo $halfStarSVG;
									} else {
										echo $fullStarSVG;
									}
								}
							} else if ($post_rating_suffix) {
								echo $halfStarSVG . str_repeat($fullStarSVG, 4);
							} else {
								echo str_repeat($fullStarSVG, 5);
							}
                            ?>
                            <span class="wpdw-sep">/</span>&nbsp;<span><?php echo $post_rating_count . " " . ($post_rating_count === 1 ? $wpdiscuz->options->getPhrase("wc_vote_phrase") : $wpdiscuz->options->getPhrase("wc_votes_phrase")); ?></span>
                        </div>
                    </div>
                </div>
                <hr class='delim'>
            </div>
            <?php
		}
		?>
	</div>
</div>