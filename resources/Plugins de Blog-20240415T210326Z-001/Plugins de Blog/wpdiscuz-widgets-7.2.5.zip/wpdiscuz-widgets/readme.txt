=== wpDiscuz - Widgets ===
Contributors: gVectors Team
Requires at least: 5.0
Tested up to: 6.3
Stable tag: 7.2.5
Requires PHP: 5.4 and higher
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

wpDiscuz Widgets Addon comes with four (Most voted comments, Active comment threads, 
Most commented posts and Active comment authors) widgets. These widgets display 
all the best you have on your site. You can use those widgets together with Tabbed 
layout or separately as a simple widget. You can enable/disable each widget 
Tab individually. There are options to set each Tab title, number of listed 
items and time-frame for counting Best/Top results. Also there are lots of options 
to customize background and icon colors, width, margins and paddings. 
All widgets are responsive, look nice on any screen dimension and ready 
for Right to Left usage too.