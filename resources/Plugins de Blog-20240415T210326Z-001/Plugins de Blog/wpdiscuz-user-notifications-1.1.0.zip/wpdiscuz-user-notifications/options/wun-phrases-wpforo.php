<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( WunHelper::isWpForoActive() ) {
	?>
    <div class="wun-accordion-item">

        <div class="wpd-subtitle fas wun-accordion-title" style="margin-top: 20px;"
             data-wun-selector="wun-notifications-wpforo-texts">
            <p><?php esc_html_e( "wpForo Notifications' Texts", "wpdiscuz-user-notifications" ) ?></p>
        </div>

        <div class="wun-accordion-content">

            <div class="wpd-subtitle wun-subtitle" style="margin-top: 20px;">
				<?php esc_html_e( "The user's Topic/Post has been replied to", "wpdiscuz-user-notifications" ) ?>
            </div>

            <!-- Option start -->
            <div class="wpd-opt-row" data-wpd-opt="wpforoNtfTitleNewReply">
                <div class="wpd-opt-name">
                    <label for="wpforoNtfTitleNewReply"><?php esc_html_e( $setting["options"]["wpforoNtfTitleNewReply"]["label"] ) ?></label>
                    <p class="wpd-desc"><?php esc_html_e( $setting["options"]["wpforoNtfTitleNewReply"]["description"] ) ?></p>
                </div>
                <div class="wpd-opt-input">
                    <input type="text"
                           value="<?php esc_attr_e( $setting["values"]->data["wpforoNtfTitleNewReply"] ); ?>"
                           name="<?php echo $tab; ?>[wpforoNtfTitleNewReply]" id="wpforoNtfTitleNewReply"/>
                </div>
                <div class="wpd-opt-doc">
					<?php $wpdiscuz->options->printDocLink( $setting["options"]["wpforoNtfTitleNewReply"]["docurl"] ) ?>
                </div>
            </div>
            <!-- Option end -->

            <!-- Option start -->
            <div class="wpd-opt-row" data-wpd-opt="wpforoNtfMessageNewReply">
                <div class="wpd-opt-name">
                    <label for="wpforoNtfMessageNewReply"><?php esc_html_e( $setting["options"]["wpforoNtfMessageNewReply"]["label"] ); ?></label>
                    <p class="wpd-desc"><?php esc_html_e( $setting["options"]["wpforoNtfMessageNewReply"]["description"] ); ?></p>
                    <p class="wpd-desc"><?php esc_html_e( "Available shortcodes", "wpdiscuz-user-notifications" ); ?>:
                    <p class="wpd-desc">
                        <span class="wc_available_variable" data-wpd-clipboard="[NOTIFIER]">[NOTIFIER]</span>
                        <span class="wc_available_variable" data-wpd-clipboard="[NOTIFIER_AVATAR_IMG]">[NOTIFIER_AVATAR_IMG]</span>
                        <span class="wc_available_variable" data-wpd-clipboard="[NOTIFIER_AVATAR_URL]">[NOTIFIER_AVATAR_URL]</span>
                        <span class="wc_available_variable" data-wpd-clipboard="[POST_URL]">[POST_URL]</span>
                        <span class="wc_available_variable"
                              data-wpd-clipboard="[POST_CONTENT]">[POST_CONTENT]</span>
                        <span class="wc_available_variable" data-wpd-clipboard="[DATE]">[DATE]</span>
                        <span class="wc_available_variable" data-wpd-clipboard="[MARK_READ_URL]">[MARK_READ_URL]</span>
                    </p>
                    <p class="wpd-desc wun-note">
						<?php esc_html_e( "Please do not remove or change <!--wundelete--> and <!--/wundelete--> HTML comments from this text! It's used to remove unnecessary HTML from browser notifications.", "wpdiscuz-user-notifications" ); ?>
                    </p>
                </div>
                <div class="wpd-opt-input">
					<?php wp_editor( $setting["values"]->data["wpforoNtfMessageNewReply"], "wpforoNtfMessageNewReply", [
						"textarea_name" => $tab . "[wpforoNtfMessageNewReply]",
						"textarea_rows" => 5,
						"teeny"         => true,
						"media_buttons" => false
					] ); ?>
                </div>
                <div class="wpd-opt-doc">
					<?php $wpdiscuz->options->printDocLink( $setting["options"]["wpforoNtfMessageNewReply"]["docurl"] ); ?>
                </div>
            </div>
            <!-- Option end -->

            <div class="wpd-subtitle wun-subtitle" style="margin-top: 20px;">
				<?php esc_html_e( "The user's post has been liked", "wpdiscuz-user-notifications" ) ?>
            </div>

            <!-- Option start -->
            <div class="wpd-opt-row" data-wpd-opt="wpforoNtfTitleNewLike">
                <div class="wpd-opt-name">
                    <label for="wpforoNtfTitleNewLike"><?php esc_html_e( $setting["options"]["wpforoNtfTitleNewLike"]["label"] ) ?></label>
                    <p class="wpd-desc"><?php esc_html_e( $setting["options"]["wpforoNtfTitleNewLike"]["description"] ) ?></p>
                </div>
                <div class="wpd-opt-input">
                    <input type="text"
                           value="<?php esc_attr_e( $setting["values"]->data["wpforoNtfTitleNewLike"] ); ?>"
                           name="<?php echo $tab; ?>[wpforoNtfTitleNewLike]" id="wpforoNtfTitleNewLike"/>
                </div>
                <div class="wpd-opt-doc">
					<?php $wpdiscuz->options->printDocLink( $setting["options"]["wpforoNtfTitleNewLike"]["docurl"] ) ?>
                </div>
            </div>
            <!-- Option end -->

            <!-- Option start -->
            <div class="wpd-opt-row" data-wpd-opt="wpforoNtfMessageNewLike">
                <div class="wpd-opt-name">
                    <label for="wpforoNtfMessageNewLike"><?php esc_html_e( $setting["options"]["wpforoNtfMessageNewLike"]["label"] ); ?></label>
                    <p class="wpd-desc"><?php esc_html_e( $setting["options"]["wpforoNtfMessageNewLike"]["description"] ); ?></p>
                    <p class="wpd-desc"><?php esc_html_e( "Available shortcodes", "wpdiscuz-user-notifications" ); ?>:
                    <p class="wpd-desc">
                        <span class="wc_available_variable" data-wpd-clipboard="[NOTIFIER]">[NOTIFIER]</span>
                        <span class="wc_available_variable" data-wpd-clipboard="[NOTIFIER_AVATAR_IMG]">[NOTIFIER_AVATAR_IMG]</span>
                        <span class="wc_available_variable" data-wpd-clipboard="[NOTIFIER_AVATAR_URL]">[NOTIFIER_AVATAR_URL]</span>
                        <span class="wc_available_variable" data-wpd-clipboard="[POST_URL]">[POST_URL]</span>
                        <span class="wc_available_variable" data-wpd-clipboard="[POST_CONTENT]">[POST_CONTENT]</span>
                        <span class="wc_available_variable" data-wpd-clipboard="[DATE]">[DATE]</span>
                        <span class="wc_available_variable" data-wpd-clipboard="[MARK_READ_URL]">[MARK_READ_URL]</span>
                    </p>
                    <p class="wpd-desc wun-note">
						<?php esc_html_e( "Please do not remove or change <!--wundelete--> and <!--/wundelete--> HTML comments from this text! It's used to remove unnecessary HTML from browser notifications.", "wpdiscuz-user-notifications" ); ?>
                    </p>
                </div>
                <div class="wpd-opt-input">
					<?php wp_editor( $setting["values"]->data["wpforoNtfMessageNewLike"], "wpforoNtfMessageNewLike", [
						"textarea_name" => $tab . "[wpforoNtfMessageNewLike]",
						"textarea_rows" => 5,
						"teeny"         => true,
						"media_buttons" => false
					] ); ?>
                </div>
                <div class="wpd-opt-doc">
					<?php $wpdiscuz->options->printDocLink( $setting["options"]["wpforoNtfMessageNewLike"]["docurl"] ); ?>
                </div>
            </div>
            <!-- Option end -->

            <div class="wpd-subtitle wun-subtitle" style="margin-top: 20px;">
				<?php esc_html_e( "The user's post has been disliked", "wpdiscuz-user-notifications" ) ?>
            </div>

            <!-- Option start -->
            <div class="wpd-opt-row" data-wpd-opt="wpforoNtfTitleNewDislike">
                <div class="wpd-opt-name">
                    <label for="wpforoNtfTitleNewDislike"><?php esc_html_e( $setting["options"]["wpforoNtfTitleNewDislike"]["label"] ) ?></label>
                    <p class="wpd-desc"><?php esc_html_e( $setting["options"]["wpforoNtfTitleNewDislike"]["description"] ) ?></p>
                </div>
                <div class="wpd-opt-input">
                    <input type="text"
                           value="<?php esc_attr_e( $setting["values"]->data["wpforoNtfTitleNewDislike"] ); ?>"
                           name="<?php echo $tab; ?>[wpforoNtfTitleNewDislike]" id="wpforoNtfTitleNewDislike"/>
                </div>
                <div class="wpd-opt-doc">
					<?php $wpdiscuz->options->printDocLink( $setting["options"]["wpforoNtfTitleNewDislike"]["docurl"] ) ?>
                </div>
            </div>
            <!-- Option end -->

            <!-- Option start -->
            <div class="wpd-opt-row" data-wpd-opt="wpforoNtfMessageNewDislike">
                <div class="wpd-opt-name">
                    <label for="wpforoNtfMessageNewDislike"><?php esc_html_e( $setting["options"]["wpforoNtfMessageNewDislike"]["label"] ); ?></label>
                    <p class="wpd-desc"><?php esc_html_e( $setting["options"]["wpforoNtfMessageNewDislike"]["description"] ); ?></p>
                    <p class="wpd-desc"><?php esc_html_e( "Available shortcodes", "wpdiscuz-user-notifications" ); ?>:
                    <p class="wpd-desc">
                        <span class="wc_available_variable" data-wpd-clipboard="[NOTIFIER]">[NOTIFIER]</span>
                        <span class="wc_available_variable" data-wpd-clipboard="[NOTIFIER_AVATAR_IMG]">[NOTIFIER_AVATAR_IMG]</span>
                        <span class="wc_available_variable" data-wpd-clipboard="[NOTIFIER_AVATAR_URL]">[NOTIFIER_AVATAR_URL]</span>
                        <span class="wc_available_variable" data-wpd-clipboard="[POST_URL]">[POST_URL]</span>
                        <span class="wc_available_variable"
                              data-wpd-clipboard="[POST_CONTENT]">[POST_CONTENT]</span>
                        <span class="wc_available_variable" data-wpd-clipboard="[DATE]">[DATE]</span>
                        <span class="wc_available_variable" data-wpd-clipboard="[MARK_READ_URL]">[MARK_READ_URL]</span>
                    </p>
                    <p class="wpd-desc wun-note">
						<?php esc_html_e( "Please do not remove or change <!--wundelete--> and <!--/wundelete--> HTML comments from this text! It's used to remove unnecessary HTML from browser notifications.", "wpdiscuz-user-notifications" ); ?>
                    </p>
                </div>
                <div class="wpd-opt-input">
					<?php wp_editor( $setting["values"]->data["wpforoNtfMessageNewDislike"], "wpforoNtfMessageNewDislike", [
						"textarea_name" => $tab . "[wpforoNtfMessageNewDislike]",
						"textarea_rows" => 5,
						"teeny"         => true,
						"media_buttons" => false
					] ); ?>
                </div>
                <div class="wpd-opt-doc">
					<?php $wpdiscuz->options->printDocLink( $setting["options"]["wpforoNtfMessageNewDislike"]["docurl"] ); ?>
                </div>
            </div>
            <!-- Option end -->

            <div class="wpd-subtitle wun-subtitle" style="margin-top: 20px;">
				<?php esc_html_e( "The user's post has been up voted", "wpdiscuz-user-notifications" ) ?>
            </div>

            <!-- Option start -->
            <div class="wpd-opt-row" data-wpd-opt="wpforoNtfTitleNewUpvote">
                <div class="wpd-opt-name">
                    <label for="wpforoNtfTitleNewUpvote"><?php esc_html_e( $setting["options"]["wpforoNtfTitleNewUpvote"]["label"] ) ?></label>
                    <p class="wpd-desc"><?php esc_html_e( $setting["options"]["wpforoNtfTitleNewUpvote"]["description"] ) ?></p>
                </div>
                <div class="wpd-opt-input">
                    <input type="text"
                           value="<?php esc_attr_e( $setting["values"]->data["wpforoNtfTitleNewUpvote"] ); ?>"
                           name="<?php echo $tab; ?>[wpforoNtfTitleNewUpvote]" id="wpforoNtfTitleNewUpvote"/>
                </div>
                <div class="wpd-opt-doc">
					<?php $wpdiscuz->options->printDocLink( $setting["options"]["wpforoNtfTitleNewUpvote"]["docurl"] ) ?>
                </div>
            </div>
            <!-- Option end -->

            <!-- Option start -->
            <div class="wpd-opt-row" data-wpd-opt="wpforoNtfMessageNewUpvote">
                <div class="wpd-opt-name">
                    <label for="wpforoNtfMessageNewUpvote"><?php esc_html_e( $setting["options"]["wpforoNtfMessageNewUpvote"]["label"] ); ?></label>
                    <p class="wpd-desc"><?php esc_html_e( $setting["options"]["wpforoNtfMessageNewUpvote"]["description"] ); ?></p>
                    <p class="wpd-desc"><?php esc_html_e( "Available shortcodes", "wpdiscuz-user-notifications" ); ?>:
                    <p class="wpd-desc">
                        <span class="wc_available_variable" data-wpd-clipboard="[NOTIFIER]">[NOTIFIER]</span>
                        <span class="wc_available_variable" data-wpd-clipboard="[NOTIFIER_AVATAR_IMG]">[NOTIFIER_AVATAR_IMG]</span>
                        <span class="wc_available_variable" data-wpd-clipboard="[NOTIFIER_AVATAR_URL]">[NOTIFIER_AVATAR_URL]</span>
                        <span class="wc_available_variable" data-wpd-clipboard="[POST_URL]">[POST_URL]</span>
                        <span class="wc_available_variable" data-wpd-clipboard="[POST_CONTENT]">[POST_CONTENT]</span>
                        <span class="wc_available_variable" data-wpd-clipboard="[DATE]">[DATE]</span>
                        <span class="wc_available_variable" data-wpd-clipboard="[MARK_READ_URL]">[MARK_READ_URL]</span>
                    </p>
                    <p class="wpd-desc wun-note">
						<?php esc_html_e( "Please do not remove or change <!--wundelete--> and <!--/wundelete--> HTML comments from this text! It's used to remove unnecessary HTML from browser notifications.", "wpdiscuz-user-notifications" ); ?>
                    </p>
                </div>
                <div class="wpd-opt-input">
					<?php wp_editor( $setting["values"]->data["wpforoNtfMessageNewUpvote"], "wpforoNtfMessageNewUpvote", [
						"textarea_name" => $tab . "[wpforoNtfMessageNewUpvote]",
						"textarea_rows" => 5,
						"teeny"         => true,
						"media_buttons" => false
					] ); ?>
                </div>
                <div class="wpd-opt-doc">
					<?php $wpdiscuz->options->printDocLink( $setting["options"]["wpforoNtfMessageNewUpvote"]["docurl"] ); ?>
                </div>
            </div>
            <!-- Option end -->

            <div class="wpd-subtitle wun-subtitle" style="margin-top: 20px;">
				<?php esc_html_e( "The user's post has been down voted", "wpdiscuz-user-notifications" ) ?>
            </div>

            <!-- Option start -->
            <div class="wpd-opt-row" data-wpd-opt="wpforoNtfTitleNewDownvote">
                <div class="wpd-opt-name">
                    <label for="wpforoNtfTitleNewDownvote"><?php esc_html_e( $setting["options"]["wpforoNtfTitleNewDownvote"]["label"] ) ?></label>
                    <p class="wpd-desc"><?php esc_html_e( $setting["options"]["wpforoNtfTitleNewDownvote"]["description"] ) ?></p>
                </div>
                <div class="wpd-opt-input">
                    <input type="text"
                           value="<?php esc_attr_e( $setting["values"]->data["wpforoNtfTitleNewDownvote"] ); ?>"
                           name="<?php echo $tab; ?>[wpforoNtfTitleNewDownvote]" id="wpforoNtfTitleNewDownvote"/>
                </div>
                <div class="wpd-opt-doc">
					<?php $wpdiscuz->options->printDocLink( $setting["options"]["wpforoNtfTitleNewDownvote"]["docurl"] ) ?>
                </div>
            </div>
            <!-- Option end -->

            <!-- Option start -->
            <div class="wpd-opt-row" data-wpd-opt="wpforoNtfMessageNewDownvote">
                <div class="wpd-opt-name">
                    <label for="wpforoNtfMessageNewDownvote"><?php esc_html_e( $setting["options"]["wpforoNtfMessageNewDownvote"]["label"] ); ?></label>
                    <p class="wpd-desc"><?php esc_html_e( $setting["options"]["wpforoNtfMessageNewDownvote"]["description"] ); ?></p>
                    <p class="wpd-desc"><?php esc_html_e( "Available shortcodes", "wpdiscuz-user-notifications" ); ?>:
                    <p class="wpd-desc">
                        <span class="wc_available_variable" data-wpd-clipboard="[NOTIFIER]">[NOTIFIER]</span>
                        <span class="wc_available_variable" data-wpd-clipboard="[NOTIFIER_AVATAR_IMG]">[NOTIFIER_AVATAR_IMG]</span>
                        <span class="wc_available_variable" data-wpd-clipboard="[NOTIFIER_AVATAR_URL]">[NOTIFIER_AVATAR_URL]</span>
                        <span class="wc_available_variable" data-wpd-clipboard="[POST_URL]">[POST_URL]</span>
                        <span class="wc_available_variable" data-wpd-clipboard="[POST_CONTENT]">[POST_CONTENT]</span>
                        <span class="wc_available_variable" data-wpd-clipboard="[DATE]">[DATE]</span>
                        <span class="wc_available_variable" data-wpd-clipboard="[MARK_READ_URL]">[MARK_READ_URL]</span>
                    </p>
                    <p class="wpd-desc wun-note">
						<?php esc_html_e( "Please do not remove or change <!--wundelete--> and <!--/wundelete--> HTML comments from this text! It's used to remove unnecessary HTML from browser notifications.", "wpdiscuz-user-notifications" ); ?>
                    </p>
                </div>
                <div class="wpd-opt-input">
					<?php wp_editor( $setting["values"]->data["wpforoNtfMessageNewDownvote"], "wpforoNtfMessageNewDownvote", [
						"textarea_name" => $tab . "[wpforoNtfMessageNewDownvote]",
						"textarea_rows" => 5,
						"teeny"         => true,
						"media_buttons" => false
					] ); ?>
                </div>
                <div class="wpd-opt-doc">
					<?php $wpdiscuz->options->printDocLink( $setting["options"]["wpforoNtfMessageNewDownvote"]["docurl"] ); ?>
                </div>
            </div>
            <!-- Option end -->

            <div class="wpd-subtitle wun-subtitle" style="margin-top: 20px;">
		        <?php esc_html_e( "The user has been mentioned", "wpdiscuz-user-notifications" ) ?>
            </div>

            <!-- Option start -->
            <div class="wpd-opt-row" data-wpd-opt="wpforoNtfTitleNewMention">
                <div class="wpd-opt-name">
                    <label for="wpforoNtfTitleNewMention"><?php esc_html_e( $setting["options"]["wpforoNtfTitleNewMention"]["label"] ) ?></label>
                    <p class="wpd-desc"><?php esc_html_e( $setting["options"]["wpforoNtfTitleNewMention"]["description"] ) ?></p>
                </div>
                <div class="wpd-opt-input">
                    <input type="text" value="<?php esc_attr_e( $setting["values"]->data["wpforoNtfTitleNewMention"] ); ?>"
                           name="<?php echo $tab; ?>[wpforoNtfTitleNewMention]" id="wpforoNtfTitleNewMention"/>
                </div>
                <div class="wpd-opt-doc">
			        <?php $wpdiscuz->options->printDocLink( $setting["options"]["wpforoNtfTitleNewMention"]["docurl"] ) ?>
                </div>
            </div>
            <!-- Option end -->

            <!-- Option start -->
            <div class="wpd-opt-row" data-wpd-opt="wpforoNtfMessageNewMention">
                <div class="wpd-opt-name">
                    <label for="wpforoNtfMessageNewMention"><?php esc_html_e( $setting["options"]["wpforoNtfMessageNewMention"]["label"] ); ?></label>
                    <p class="wpd-desc"><?php esc_html_e( $setting["options"]["wpforoNtfMessageNewMention"]["description"] ); ?></p>
                    <p class="wpd-desc"><?php esc_html_e( "Available shortcodes", "wpdiscuz-user-notifications" ); ?>:
                    <p class="wpd-desc">
                        <span class="wc_available_variable" data-wpd-clipboard="[NOTIFIER]">[NOTIFIER]</span>
                        <span class="wc_available_variable" data-wpd-clipboard="[NOTIFIER_AVATAR_IMG]">[NOTIFIER_AVATAR_IMG]</span>
                        <span class="wc_available_variable" data-wpd-clipboard="[NOTIFIER_AVATAR_URL]">[NOTIFIER_AVATAR_URL]</span>
                        <span class="wc_available_variable" data-wpd-clipboard="[POST_URL]">[POST_URL]</span>
                        <span class="wc_available_variable"
                              data-wpd-clipboard="[POST_CONTENT]">[POST_CONTENT]</span>
                        <span class="wc_available_variable" data-wpd-clipboard="[DATE]">[DATE]</span>
                        <span class="wc_available_variable" data-wpd-clipboard="[MARK_READ_URL]">[MARK_READ_URL]</span>
                    </p>
                    <p class="wpd-desc wun-note">
				        <?php esc_html_e( "Please do not remove or change <!--wundelete--> and <!--/wundelete--> HTML comments from this text! It's used to remove unnecessary HTML from browser notifications.", "wpdiscuz-user-notifications" ); ?>
                    </p>
                </div>
                <div class="wpd-opt-input">
			        <?php wp_editor( $setting["values"]->data["wpforoNtfMessageNewMention"], "wpforoNtfMessageNewMention", [
				        "textarea_name" => $tab . "[wpforoNtfMessageNewMention]",
				        "textarea_rows" => 5,
				        "teeny"         => true,
				        "media_buttons" => false
			        ] ); ?>
                </div>
                <div class="wpd-opt-doc">
			        <?php $wpdiscuz->options->printDocLink( $setting["options"]["wpforoNtfMessageNewMention"]["docurl"] ); ?>
                </div>
            </div>
            <!-- Option end -->

        </div>
    </div>
	<?php
}