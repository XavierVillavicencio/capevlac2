<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( WunHelper::isWpForoActive() ) {
	?>
    <!-- Option start -->
    <div class="wpd-opt-row" data-wpd-opt="wpforoNotifications">
        <div class="wpd-opt-name">
            <label for="wpforoNotifications"><?php esc_html_e( $setting["options"]["wpforoNotifications"]["label"] ); ?></label>
            <p class="wpd-desc"><?php esc_html_e( $setting["options"]["wpforoNotifications"]["description"] ); ?></p>
        </div>
        <div class="wpd-opt-input">

            <div class="wpd-opt-input-wtext">
                <div class="wpd-switcher wpd-switcher-wtext">
                    <input type="hidden" value="0" name="<?php echo $tab; ?>[wpforoNotifications][new_reply]"/>
                    <input type="checkbox" <?php checked( ( (int) $setting["values"]->data["wpforoNotifications"]["new_reply"] ) === 1 ); ?>
                           value="1" name="<?php echo $tab; ?>[wpforoNotifications][new_reply]" id="wpforoNtfNewReply"/>
                    <label for="wpforoNtfNewReply"></label>
                </div>
                <div class="wpd-switcher-label">
                    <label for="wpforoNtfNewReply"><?php esc_html_e( "someone replied to my topic", "wpdiscuz-user-notifications" ); ?></label>
                </div>
            </div>

            <div class="wpd-opt-input-wtext">
                <div class="wpd-switcher wpd-switcher-wtext">
                    <input type="hidden" value="0" name="<?php echo $tab; ?>[wpforoNotifications][new_like]"/>
                    <input type="checkbox" <?php checked( ( (int) $setting["values"]->data["wpforoNotifications"]["new_like"] ) === 1 ); ?>
                           value="1" name="<?php echo $tab; ?>[wpforoNotifications][new_like]" id="wpforoNtfNewLike"/>
                    <label for="wpforoNtfNewLike"></label>
                </div>
                <div class="wpd-switcher-label">
                    <label for="wpforoNtfNewLike"><?php esc_html_e( "someone liked my post", "wpdiscuz-user-notifications" ); ?></label>
                </div>
            </div>

            <div class="wpd-opt-input-wtext">
                <div class="wpd-switcher wpd-switcher-wtext">
                    <input type="hidden" value="0" name="<?php echo $tab; ?>[wpforoNotifications][new_dislike]"/>
                    <input type="checkbox" <?php checked( ( (int) $setting["values"]->data["wpforoNotifications"]["new_dislike"] ) === 1 ); ?>
                           value="1" name="<?php echo $tab; ?>[wpforoNotifications][new_dislike]"
                           id="wpforoNtfNewDislike"/>
                    <label for="wpforoNtfNewDislike"></label>
                </div>
                <div class="wpd-switcher-label">
                    <label for="wpforoNtfNewDislike"><?php esc_html_e( "someone disliked my post", "wpdiscuz-user-notifications" ); ?></label>
                </div>
            </div>

            <div class="wpd-opt-input-wtext">
                <div class="wpd-switcher wpd-switcher-wtext">
                    <input type="hidden" value="0" name="<?php echo $tab; ?>[wpforoNotifications][new_up_vote]"/>
                    <input type="checkbox" <?php checked( ( (int) $setting["values"]->data["wpforoNotifications"]["new_up_vote"] ) === 1 ); ?>
                           value="1" name="<?php echo $tab; ?>[wpforoNotifications][new_up_vote]"
                           id="wpforoNtfNewUpvote"/>
                    <label for="wpforoNtfNewUpvote"></label>
                </div>
                <div class="wpd-switcher-label">
                    <label for="wpforoNtfNewUpvote"><?php esc_html_e( "someone up-voted my post", "wpdiscuz-user-notifications" ); ?></label>
                </div>
            </div>

            <div class="wpd-opt-input-wtext">
                <div class="wpd-switcher wpd-switcher-wtext">
                    <input type="hidden" value="0" name="<?php echo $tab; ?>[wpforoNotifications][new_down_vote]"/>
                    <input type="checkbox" <?php checked( ( (int) $setting["values"]->data["wpforoNotifications"]["new_down_vote"] ) === 1 ); ?>
                           value="1" name="<?php echo $tab; ?>[wpforoNotifications][new_down_vote]"
                           id="wpforoNtfNewDownvote"/>
                    <label for="wpforoNtfNewDownvote"></label>
                </div>
                <div class="wpd-switcher-label">
                    <label for="wpforoNtfNewDownvote"><?php esc_html_e( "someone down-voted my post", "wpdiscuz-user-notifications" ); ?></label>
                </div>
            </div>

            <div class="wpd-opt-input-wtext">
                <div class="wpd-switcher wpd-switcher-wtext">
                    <input type="hidden" value="0" name="<?php echo $tab; ?>[wpforoNotifications][new_mention]"/>
                    <input type="checkbox" <?php checked( ( (int) $setting["values"]->data["wpforoNotifications"]["new_mention"] ) === 1 ); ?>
                           value="1" name="<?php echo $tab; ?>[wpforoNotifications][new_mention]"
                           id="wpforoNtfNewMention"/>
                    <label for="wpforoNtfNewMention"></label>
                </div>
                <div class="wpd-switcher-label">
                    <label for="wpforoNtfNewMention"><?php esc_html_e( "someone mentioned me", "wpdiscuz-user-notifications" ); ?></label>
                </div>
            </div>

        </div>

        <div class="wpd-opt-doc">
			<?php $wpdiscuz->options->printDocLink( $setting["options"]["wpforoNotifications"]["docurl"] ); ?>
        </div>
    </div>
    <!-- Option end -->
	<?php
}
