<?php
if ( ! defined( "ABSPATH" ) ) {
	exit();
}
$wpdiscuz                      = wpDiscuz();
$mainPage                      = WpDiscuzConstants::PAGE_SETTINGS;
$tab                           = esc_attr( $setting["values"]->tabKey );
$nonce                         = WunHelper::uniqueNonce();
$mainUrl                       = admin_url( "admin.php?page={$mainPage}&wpd_tab={$tab}" );
$redirectTo                    = urlencode_deep( $mainUrl );
$deleteAllNotificationsUrl     = $mainUrl . "&wun_delete=all&_nonce={$nonce}&redirect_to={$redirectTo}";
$deleteExpiredNotificationsUrl = $mainUrl . "&wun_delete=expired&_nonce={$nonce}&redirect_to={$redirectTo}";
$deleteReadNotificationsUrl    = $mainUrl . "&wun_delete=read&_nonce={$nonce}&redirect_to={$redirectTo}";

$allNotificationsCount     = $setting["values"]->dbManager->allNotificationsCount();
$expiredNotificationsCount = $setting["values"]->dbManager->allNotificationsCount( [ "lastXDays" => $setting["values"]->data["lastXDays"] ] );
$readNotificationsCount    = $setting["values"]->dbManager->allNotificationsCount( [ "is_new" => 0 ] );


$allDisabled     = $allNotificationsCount ? "" : "disabled='disabled'";
$expiredDisabled = $expiredNotificationsCount ? "" : "disabled='disabled'";
$readDisabled    = $readNotificationsCount ? "" : "disabled='disabled'";
?>

<!-- options start -->
<?php include_once WPDUN_DIR_PATH . '/options/wun-options.php'; ?>
<!-- options end -->

<!-- phrases start -->
<?php include_once WPDUN_DIR_PATH . '/options/wun-phrases.php'; ?>
<!-- phrases end -->
