<?php
if (!defined("ABSPATH")) {
    exit();
}
?>
<ul class="wpdiscuz-bell-shortcode-menu">
    <li class="menu-item-wun-bell">
        <a href="#!">
            <?php echo $this->getBell(); ?>
        </a>
    </li>
</ul>