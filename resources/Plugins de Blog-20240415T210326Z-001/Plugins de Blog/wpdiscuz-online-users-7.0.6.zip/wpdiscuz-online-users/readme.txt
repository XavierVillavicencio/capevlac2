=== wpDiscuz - Online Users ===
Contributors: gVectors Team
Requires at least: 5.0
Tested up to: 5.9
Stable tag: 7.0.6
Requires PHP: 5.4 and higher
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

wpDiscuz Online users addon is designed to indicate users online status on comment list. 
It adds online/offline badges on the right side of comment author name. 
Addon checks all user statuses real-time and changes badges on comment list 
without reloading page. When a new user signs in (login), wpDiscuz Online Users 
addon displays a pop-up notification with just logged in user details (name, avatar) 
and last comment (comment intro and link to comment). Addon also comes with many options 
and front-end style settings.

 