<?php

if (!defined("ABSPATH")) {
    exit();
}

interface WOUConstants {
    
    const OPTION_MAIN        = "wou_options";
    const OPTION_VERSION     = "wou_version";
    const HASH_KEY           = "wou_uuid";
}
