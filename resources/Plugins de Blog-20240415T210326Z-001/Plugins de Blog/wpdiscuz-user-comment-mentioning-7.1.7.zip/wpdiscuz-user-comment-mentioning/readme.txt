=== wpDiscuz - User & Comment Mentioning ===
Contributors: gVectors Team
Requires at least: 5.0
Tested up to: 6.4
Stable tag: 7.1.7
Requires PHP: 5.4 and higher
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

wpDiscuz User and Comment Mentioning allows to mention certain comments and users 
in comment text using #comment-id and @username tags. It comes with User Search bar, 
so you can find and tag any user/guest very easy. It also displays #ID of each comment 
to let you tag them. All mentioned users and comment authors will be notified via email. 
This addon replace @author and #comment-id to links with avatars. It opens a pop-up 
window with user and comment information when you hover on @author and #comment-id links. 
Please note, that the Comment Rich Editor must be enabled for this addon.
