=== wpDiscuz - Syntax Highlighter ===
Contributors: gVectors Team
Requires at least: 5.0
Tested up to: 5.7
Stable tag: 1.0.3
Requires PHP: 5.4 and higher
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

wpDiscuz Syntax Highlighter addon displays formatted source code using the highlight.js 
JavaScript library in comment content. This addon supports almost all programming 
languages including Apache, Bash, C#, C++, CSS, HTML, XML, JSON, Java, JavaScript, 
Objective-C, PHP, Perl, Python, Ruby, SQL, Basic, Delphi, Erlang, Matlab, Prolog, ScalaScheme, 
Swift, TypeScript, VB.NET, Shell with dozens of different syntax highlighting styles. 
With this addons your commenters can insert different scripts and codes using the [</>] 
code toolbar button in comment editor. In the dashboard settings you can enable/disable 
certain programming language and change the highlighting style.