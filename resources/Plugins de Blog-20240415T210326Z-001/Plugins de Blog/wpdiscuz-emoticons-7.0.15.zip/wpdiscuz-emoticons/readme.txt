=== wpDiscuz - Emoticons ===
Contributors: gVectors Team
Requires at least: 5.0
Tested up to: 6.3
Stable tag: 7.0.15
Requires PHP: 5.4 and higher
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Smiles and emoticons are one of the most used feature in all kind of communities, chats, 
forums and blogs. It’s an essential solution if you want to display your emotion in a text . 
Unfortunately WordPress emoticons are not so impressive and we were getting lots of request 
to create a new set/package of emoticons for wpDiscuz comment plugin. And now it’s here! 
wpDiscuz Emoticons Addon brings an ocean of emotions to your website comments. 
It comes with an awesome and unique smile package. And we’ll add more nice packages in future releases.