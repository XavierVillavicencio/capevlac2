<?php
/*
 * Plugin Name: wpDiscuz - Voice Commenting
 * Description: Allows to discuss with your voice in the comment section. Simply click the microphone icon located on the comment editor toolbar and record your reply.
 * Version: 1.0.3
 * Author: gVectors Team
 * Author URI: https://gvectors.com/
 * Plugin URI: https://gvectors.com/product/wpdiscuz-voice-commenting/
 * Text Domain: wpdiscuz_audio
 * Domain Path: /languages/
 */

if (!defined("ABSPATH")) {
    exit();
}

define("WPDAUDIO_DIR_PATH", dirname(__FILE__));

include_once WPDAUDIO_DIR_PATH . "/includes/gvt-api-manager.php";
include_once WPDAUDIO_DIR_PATH . "/includes/wpdAudioCommentDBManager.php";
include_once WPDAUDIO_DIR_PATH . "/options/wpdAudioOptions.php";

class wpDiscuzAudioComment {

    private $pVersion;
    private $dbManager;
    private $options;
    private $isSupportAudioComment;
    private $isUserCanAddAudioComment;
    public $apimanager;

    public function __construct() {
        $this->options = new wpdAudioOptions();
        $this->dbManager = new wpdAudioCommentDBManager();
        add_action("plugins_loaded", [&$this, "pluginsLoaded"], 269);
        register_activation_hook(__FILE__, [&$this, "pluginActivation"]);

        register_activation_hook(__FILE__, [&$this, "registerDeleteUnusedFiles"]);
        register_deactivation_hook(__FILE__, [&$this, "deregisterDeleteUnusedFiles"]);
        add_filter("cron_schedules", [&$this, "setDeleteFilesInterval"]);
    }

    public function pluginsLoaded() {
        if (function_exists("wpDiscuz")) {
            
            $this->options->init();
            $this->apimanager = new GVT_API_Manager(__FILE__, "wpdiscuz_options_page", "wpdiscuz_option_page");
            if (is_dir($this->options->mainDir)) {
                $this->initPluginVersion();
                load_plugin_textdomain("wpdiscuz_audio", false, dirname(plugin_basename(__FILE__)) . "/languages/");

                $this->isUserCanAddAudioComment();
                add_filter("wpdiscuz_editor_buttons_html", [&$this, "addAudioButton"], 3, 2);
                add_action("wpdiscuz_front_scripts", [&$this, "frontendFiles"], 109, 1);
                add_filter("wpdiscuz_js_options", [&$this, "jsOptions"]);
                add_action("wp_footer", [&$this, "recordButtons"]);
                add_filter("wpdiscuz_get_form", [&$this, "isSupportAudioComment"], 59);
                add_action("wp_ajax_wpdUploadAudio", [&$this, "uploadAudio"]);
                add_action("wp_ajax_nopriv_wpdUploadAudio", [&$this, "uploadAudio"]);
                add_action("wp_ajax_wpdDeleteAudio", [&$this, "deleteAudio"]);
                add_action("wp_ajax_nopriv_wpdDeleteAudio", [&$this, "deleteAudio"]);
                add_action("wp_insert_comment", [&$this, "updateCommentID"], 234);
                add_filter("wpdiscuz_comment_post", [&$this, "setJSCallback"], 234);
                add_filter("wpdiscuz_is_comment_editable", [&$this, "isCommentEditable"], 79, 2);
                add_filter("comment_text", [&$this, "audioShortcode"], 245, 2);
                add_filter("get_comment_excerpt", [&$this, "audioShortcodeInExcerpt"], 246, 3 );
                add_filter("deleted_comment", [&$this, "deleteAudioByCommentID"]);
                add_action("wpdiscuz_audio_delete_unused_files", [&$this, "deleteUnusedFiles"]);
            } else {
                add_action('admin_notices', [&$this, 'mainDirRequiredNotice']);
            }
        } else {
            add_action("admin_notices", [&$this, "requirements"], 1);
        }
    }

    public function audioShortcode($commentText, $comment) {
        if (preg_match('@\[wpd_audio\]([^\[]+)\[\/wpd_audio\]@is', $commentText, $match)) {
            $audioData = $this->dbManager->getAudioInfoByKey($match[1]);
            if ($audioData && $audioData['comment_id'] == $comment->comment_ID) {
                $url = esc_attr($this->options->baseurl . '/' . wpdAudioOptions::AUDIO_DIR . '/' . $audioData['path']);
                $html = "<div class='wac-audio-comment'><audio  controls ><source src='$url' type='audio/mpeg'>";
                $html .= __("Your browser does not support the audio tag.", "wpdiscuz_audio");
                $html .= "</audio></div>";
                $commentText = str_replace($match[0], $html, $commentText);
            }
        }
        return $commentText;
    }
    
    public function audioShortcodeInExcerpt($excerpt, $commentID, $comment){
        if (preg_match('@\[wpd_audio\]([^\[]+)\[\/wpd_audio\]@is', $comment->comment_content, $match)) {
            $audioData = $this->dbManager->getAudioInfoByKey($match[1]);
            if ($audioData && $audioData['comment_id'] == $comment->comment_ID) {
                $url = esc_attr($this->options->baseurl . '/' . wpdAudioOptions::AUDIO_DIR . '/' . $audioData['path']);
                $html = "<div class='wac-audio-comment'><audio  controls ><source src='$url' type='audio/mpeg'>";
                $html .= __("Your browser does not support the audio tag.", "wpdiscuz_audio");
                $html .= "</audio></div>";
                return str_replace($match[0], $html, $comment->comment_content);
            }
        }
        return $excerpt;
    }

    public function uploadAudio() {
        $response = [];
        $caneAdd = false;
        check_ajax_referer('wpd-audio-comment', 'wpd_audio_nonce');
        $postID = filter_input(INPUT_POST, 'postId', FILTER_SANITIZE_NUMBER_INT);
        if ($postID && $this->isUserCanAddAudioComment && wpdiscuz()->wpdiscuzForm->getForm($postID) && $this->isSupportAudioComment) {
            $caneAdd = true;
        }
        if ($caneAdd && !empty($_FILES['audio_file']) && ($_FILES['audio_file']['type'] === "audio/mp3" || $_FILES['audio_file']['type'] === "audio/mpeg") && $_FILES['audio_file']['error'] == 0) {
            $fileName = filter_input(INPUT_POST, 'audio_file_name', FILTER_SANITIZE_STRING);
            if ($fileName && $postID) {
                $currentUser = wp_get_current_user();
                $fileName = str_replace(['.', ':'], '', $fileName) . ".mp3";
                if ($this->createSubDir()) {
                    $uploadsPath = $this->options->mainDir . '/' . $this->options->subDir;
                    $path = $this->options->subDir . "/" . $fileName;
                    if (@move_uploaded_file($_FILES['audio_file']['tmp_name'], $uploadsPath . "/" . $fileName)) {
                        $response = $this->dbManager->addAudio($path, $postID, $currentUser->ID);
                    }
                } else {
                    wp_send_json(["error" => __("Can't create subdirectory.", 'wpdiscuz_audio')]);
                }
            }
            wp_send_json($response);
        }
        wp_send_json(["error" => __('Failed', 'wpdiscuz_audio')]);
    }

    public function updateCommentID($commentID) {
        $audioID = filter_input(INPUT_POST, 'wac_audio_comment', FILTER_SANITIZE_NUMBER_INT);
        if ($audioID) {
            $this->dbManager->updateCommentID($audioID, $commentID);
        }
    }

    public function setJSCallback($response) {
        $audioID = filter_input(INPUT_POST, 'wac_audio_comment', FILTER_SANITIZE_NUMBER_INT);
        if ($audioID && !empty($response["new_comment_id"]) && $response["new_comment_id"]) {
            $response["callbackFunctions"][] = "wpdAudioRecCancle";
        }
        return $response;
    }

    public function deleteAudio() {
        check_ajax_referer('wpd-audio-comment', 'wpd_audio_nonce');
        $audioID = filter_input(INPUT_POST, 'wpd_audio_id', FILTER_SANITIZE_NUMBER_INT);
        $postID = filter_input(INPUT_POST, 'postId', FILTER_SANITIZE_NUMBER_INT);
        if ($audioID && $postID) {
            $path = $this->dbManager->getPathByID($audioID);
            if ($path && $this->dbManager->deleteAudio($audioID)) {
                unlink($this->options->mainDir . '/' . $path);
            }
        }
    }

    public function deleteAudioByCommentID($commentID) {
        $path = $this->dbManager->getPathByCommentID($commentID);
        if ($path && $this->dbManager->deleteAudioByCommentID($commentID)) {
            unlink($this->options->mainDir . '/' . $path);
        }
    }

    public function addAudioButton($html, $uid) {
        if ($this->isSupportAudioComment && $this->isUserCanAddAudioComment) {
            $html .= "<span id='wac-audio-$uid' data-uid='$uid' class='wac-audio-wrap' wpd-tooltip='" . __("Voice Comment", "wpdiscuz_audio") . "' wpd-tooltip-position='" . (!is_rtl() ? 'left' : 'right' ) . "'>";
            $html .= "<i class='fas fa-microphone' data-uid='$uid'></i>";
            $html .= "</span>";
        }
        return $html;
    }

    public function frontendFiles($globalOptions) {
        if ($this->isSupportAudioComment && $this->isUserCanAddAudioComment) {
            $suf = $globalOptions->general["loadMinVersion"] ? ".min" : "";
            //https://github.com/webrtchacks/adapter
            wp_register_script("wpdiscuz-adapter", plugins_url("/assets/js/adapter/adapter$suf.js", __FILE__), ['jquery'], '7.7.0', false);
            wp_enqueue_script("wpdiscuz-adapter");
//            //https://github.com/closeio/mic-recorder-to-mp3
            wp_register_script("wpdiscuz-mp3-recorder", plugins_url("/assets/js/mp3-recorder/dist/index$suf.js", __FILE__), ["wpdiscuz-adapter"], '2.2.2', false);
            wp_enqueue_script("wpdiscuz-mp3-recorder");
            wp_register_script("wpdiscuz-audio-js", plugins_url("/assets/js/wpd-audio-comment$suf.js", __FILE__), ["wpdiscuz-mp3-recorder"], $this->pVersion, true);
            wp_enqueue_script("wpdiscuz-audio-js");
        }
        if (is_rtl()) {
            wp_register_style("wpd-audio-comment-rtl", plugins_url("/assets/css/wpd-audio-comment-rtl.css", __FILE__), null, $this->pVersion);
            wp_enqueue_style("wpd-audio-comment-rtl");
        } else {
            wp_register_style("wpd-audio-comment", plugins_url("/assets/css/wpd-audio-comment.css", __FILE__), null, $this->pVersion);
            wp_enqueue_style("wpd-audio-comment");
        }
    }

    public function jsOptions($options) {
        if ($this->isSupportAudioComment && $this->isUserCanAddAudioComment) {
            $options['wpdAudioNonce'] = wp_create_nonce('wpd-audio-comment');
            $options['wpdAudioTimerLimit'] = $this->options->timeLimit;
        }
        return $options;
    }

    public function isSupportAudioComment($form) {
        $this->isSupportAudioComment = $form && in_array($form->getFormID(), $this->options->enableForForms);
        return $form;
    }

    private function isUserCanAddAudioComment() {
        $this->isUserCanAddAudioComment = false;
        $currentUser = wp_get_current_user();
        if (!$currentUser->exists() && $this->options->guestCanAddAudioComment) {
            $this->isUserCanAddAudioComment = true;
        } else if ($currentUser->exists() && $roles = (array) $currentUser->roles) {
            foreach ($roles as $role) {
                if (in_array($role, $this->options->canAddAudioComment)) {
                    $this->isUserCanAddAudioComment = true;
                    break;
                }
            }
        }
        return $this->isUserCanAddAudioComment;
    }

    public function isCommentEditable($isEditable, $comment) {
        if (!$this->options->allowEditing && get_comment_meta($comment->comment_ID, 'wpd_audio_id', true)) {
            return false;
        }
        return $isEditable;
    }

    public function recordButtons() {
        $wpdiacuz = wpDiscuz();
        if ($wpdiacuz->isWpdiscuzLoaded && $this->isSupportAudioComment && $this->isUserCanAddAudioComment) {
            ?>
            <div style="display:none" id="wac-rec-container">
                <div class="wac-rec-buttons" id="wac-rec-container-uniqueid">
                    <input name="wac_audio_comment" id="wac-audio-comment-uniqueid" type="hidden" value="" >
                    <div  id="wac-rec-timer-uniqueid" class="wac-rec-timer"></div>
                    <div  id="wac-player-uniqueid" class="wac-player"></div>
                    <button id ="wac-record-uniqueid" class="wac-record"><i class="fas fa-microphone"></i>&nbsp; <?php _e("Record", "wpdiscuz_audio"); ?></button>
                    <button id ="wac-stop-uniqueid" class="wac-stop"> <?php _e("Stop", "wpdiscuz_audio"); ?></button>
                    <button id ="wac-delete-uniqueid" class="wac-delete"><i class="far fa-trash-alt"></i>&nbsp; <?php _e("Delete", "wpdiscuz_audio"); ?></button>
                    <button id ="wac-cancel-uniqueid" class="wac-cancel"><i class="far fa-times-circle"></i>&nbsp; <?php _e("Cancel", "wpdiscuz_audio"); ?></button>
                </div>
            </div>
            <?php
        }
    }

    public function deleteUnusedFiles() {
        $unusedFiles = $this->dbManager->getUnusedFiles();
        if ($unusedFiles) {
            foreach ($unusedFiles as $unusedFile) {
                if (unlink($this->options->mainDir . '/' . $unusedFile["path"])) {
                    $this->dbManager->deleteAudio($unusedFile["id"]);
                }
            }
        }
    }

    public function registerDeleteUnusedFiles() {
        if (!wp_next_scheduled("wpdiscuz_audio_delete_unused_files")) {
            wp_schedule_event(current_time("timestamp"), "wpdiscuz_audio_delete_unused_files_every_week", "wpdiscuz_audio_delete_unused_files");
        }
    }

    public function deregisterDeleteUnusedFiles() {
        if (wp_next_scheduled("wpdiscuz_audio_delete_unused_files")) {
            wp_clear_scheduled_hook("wpdiscuz_audio_delete_unused_files");
        }
    }

    public function setDeleteFilesInterval($schedules) {
        $schedules["wpdiscuz_audio_delete_unused_files_every_week"] = [
            "interval" => 7 * DAY_IN_SECONDS,
            "display" => esc_html__("Every Week", "wpdiscuz")
        ];
        return $schedules;
    }

    public function pluginActivation($networkWide) {
        $this->dbManager->createTable($networkWide);
        $this->createAudioMainDir();
    }

    private function createSubDir() {
        $subDir = $this->options->mainDir . '/' . $this->options->subDir;
        if (!is_dir($subDir)) {
            if (mkdir($subDir, 0755, true)) {
                file_put_contents($subDir . '/index.html', "");
            } else {
                return false;
            }
        }
        return true;
    }

    private function createAudioMainDir() {
        if (!is_dir($this->options->mainDir)) {
            if (mkdir($this->options->mainDir, 0755, true)) {
                file_put_contents($this->options->mainDir . '/robots.txt', "User-agent: *\nDisallow: /");
                file_put_contents($this->options->mainDir . '/index.html', "");
            }
        }
    }

    public function mainDirRequiredNotice() {
        if (current_user_can("manage_options")) {
            echo "<div class='error'><p>" . __("wpDiscuz - Voice Commenting can't create upload directory.", "wpdiscuz_audio") . "</p></div>";
        }
    }

    private function initPluginVersion() {
        if (!function_exists("get_plugins")) {
            require_once ABSPATH . "wp-admin/includes/plugin.php";
        }
        $plugin_folder = get_plugins("/" . plugin_basename(dirname(__FILE__)));
        $plugin_file = basename(( __FILE__));
        $this->pVersion = $plugin_folder[$plugin_file]["Version"];
    }

    public function requirements() {
        if (current_user_can("manage_options")) {
            echo "<div class='error'><p>" . __("wpDiscuz - Voice Commenting requires wpDiscuz to be installed!", "wpdiscuz_audio") . "</p></div>";
        }
    }

}

$wpdiscuzAudioComment = new wpDiscuzAudioComment();
