jQuery(document).ready(function($) {

	let wpdAudioRecorder = new MicRecorder({
		bitRate: 128
	});

	let uid = '';
	let audioID = 0;
	let isLoadRichEditor = parseInt(wpdiscuzAjaxObj.loadRichEditor);
	let timerLimit = wpdiscuzAjaxObj.wpdAudioTimerLimit;
	let url = '';
	let wpdAudioTimerDeadline, wpdAudioTimerTimeinterval;
//    navigator.permissions.query({name: 'microphone'}).then(function (result) {
//        if (result.state == 'granted') {
//            console.log('granted');
//        } else if (result.state == 'prompt') {
//            console.log('prompt');
//        } else if (result.state == 'denied') {
//            console.log('denied');
//        }
//        result.onchange = function () {
//
//        };
//    });

	if (navigator.mediaDevices && navigator.mediaDevices.enumerateDevices) {
		navigator.mediaDevices.enumerateDevices()
			.then(function(devices) {
				devices = devices.filter((d) => d.kind === 'audioinput');
				if (!devices.length) {
					$('#wpdcom .wac-audio-wrap').remove();
					$('#wac-rec-container').remove();
					console.log("Recording features are not supported in your browser.");
				}
			})
			.catch(function(err) {
				console.log(err.name + ": " + err.message);
			});
	}

	if (typeof navigator.mediaDevices === 'undefined') {
		$('#wpdcom .wac-audio-wrap').remove();
		$('#wac-rec-container').remove();
		console.log("Recording features are not supported in your browser.");
	}

	$(document).on('click', '#wpdcom .wac-audio-wrap', function(e) {
		e.preventDefault();
		$('.wpd-form-foot', $(this).parents('.wpd_comm_form')).slideDown(parseInt(wpdiscuzAjaxObj.enableDropAnimation) ? 500 : 0);
		uid = $(this).attr('data-uid');
		wpdAudioRecStart();
	});

	$(document).on('click', '#wpdcom .wac-cancel', function(e) {
		e.preventDefault();
		wpdAudioRecCancle();
	});

	$(document).on('click', '#wpdcom .wac-record', function(e) {
		e.preventDefault();
		wpdAudioRecStart();
	});

	$(document).on('click', '#wpdcom .wac-stop', function(e) {
		e.preventDefault();
		wpdAudioStop();
	});

	$(document).on('click', '#wpdcom .wac-delete', function(e) {
		e.preventDefault();
		wpdAudioDelete();
	});


	function wpdAudioRecStart() {
		wpdAudioRecorder.start().then(function() {
			if (!$('#wac-record-' + uid).length) {
				let audioConsole = $('#wac-rec-container').html().replace(/uniqueid/g, uid);
				if (isLoadRichEditor === 1) {
					$('#wpd-editor-wraper-' + uid).hide();
					$('#wpd-editor-wraper-' + uid).parents('.wpdiscuz-textarea-wrap ').append(audioConsole);
				} else {
					$('#wc-textarea-' + uid).hide();
					$('#wac-audio-' + uid).hide();
					$('#wc-textarea-' + uid).parents('.wpd-textarea-wrap').append(audioConsole);
				}
			}
			$('#wac-stop-' + uid).show();
			$('#wac-cancel-' + uid).show();
			$('#wac-record-' + uid).hide();
			$('#wac-delete-' + uid).hide();
			let current_time = Date.parse(new Date());
			wpdAudioTimerDeadline = new Date(current_time + timerLimit * 1000);
			wpdAudioTimerRun('wac-rec-timer-' + uid, wpdAudioTimerDeadline);
		}).catch(function(e) {
			wpdiscuzAjaxObj.setCommentMessage('MicRecorder:' + e.message, 'error', 3000);
			console.error(e);
		});
	}

	function wpdAudioStop() {
		wpdAudioRecorder.stop().getMp3().then(function([buffer, blob]) {
			$('#wac-stop-' + uid).hide();
			$('#wac-cancel-' + uid).hide();
			$('#wac-record-' + uid).hide();
			$('#wac-delete-' + uid).hide();
			wpdAudioTimerStop('#wac-rec-timer-' + uid);
			wpdAudioRecordComplete(blob);
		}).catch(function(e) {
			wpdiscuzAjaxObj.setCommentMessage('MicRecorder:' + e.message, 'error', 3000);
			console.error(e);
		});
	}


	function wpdAudioRecordComplete(dataBlob) {
		$('#wpdiscuz-loading-bar').show();
		let size = dataBlob.size;
		let fileName = new Date().toISOString();
		url = URL.createObjectURL(dataBlob);

		let audio = document.createElement('audio');
		audio.controls = true;
		audio.src = url;

		$('#wac-player-' + uid).html(audio);

		let data = new FormData();
		data.append('action', 'wpdUploadAudio');
		data.append('wpd_audio_nonce', wpdiscuzAjaxObj.wpdAudioNonce);
		data.append('audio_file_name', fileName);
		data.append('audio_file', dataBlob);

		if (size > parseInt(wpdiscuzAjaxObj.wmuPostMaxSize)) {
			wpdiscuzAjaxObj.setCommentMessage(wpdiscuzAjaxObj.wmuPhrasePostMaxSize, 'error', 3000);
		} else {
			let submitButton = $('#wpd-field-submit-' + uid);
			submitButton.removeClass('wpd_not_clicked');
			submitButton.attr("disabled", true);
			wpdiscuzAjaxObj.getAjaxObj(true, true, data).done(function(r) {
				if (r.key && r.audio_id) {
					audioID = r.audio_id;
					let shortcode = '[wpd_audio]' + r.key + '[/wpd_audio]';
					wpdAudioAddShortcode(shortcode);
					$('#wac-audio-comment-' + uid).val(audioID);
					$('#wac-delete-' + uid).show();
				} else {
					wpdiscuzAjaxObj.setCommentMessage(r.error, 'error', 3000);
					$('#wac-cancel-' + uid).show();
				}
				$('#wpdiscuz-loading-bar').fadeOut(250);
			}).fail(function(jqXHR, textStatus, errorThrown) {
				console.log(errorThrown);
				$('#wpdiscuz-loading-bar').fadeOut(250);
			});
			submitButton.attr("disabled", false);
			submitButton.addClass('wpd_not_clicked');
		}
	}

	function wpdAudioRevokeObjectURL() {
		if (url) {
			URL.revokeObjectURL(url);
			url = '';
		}
	}

	function wpdAudioRecCancle() {
		wpdAudioRecorder.stop();
		if (isLoadRichEditor === 1) {
			$('#wpd-editor-wraper-' + uid).show();
		} else {
			$('#wc-textarea-' + uid).show();
			$('#wac-audio-' + uid).show();
		}
		$('#wac-rec-container-' + uid).remove();
		wpdAudioDeleteShortcode();
		uid = '';
		audioID = 0;
		wpdAudioRevokeObjectURL();
		wpdAudioTimerStop('#wac-rec-timer-' + uid);
	}

	wpdiscuzAjaxObj.wpdAudioRecCancle = wpdAudioRecCancle;

	function wpdAudioDelete() {
		wpdAudioTimerStop('#wac-rec-timer-' + uid);
		if (audioID && uid) {
			let data = new FormData();
			data.append('action', 'wpdDeleteAudio');
			data.append('wpd_audio_nonce', wpdiscuzAjaxObj.wpdAudioNonce);
			data.append('wpd_audio_id', audioID);

			wpdiscuzAjaxObj.getAjaxObj(true, true, data).done(function(r) {
				audioID = 0;
				wpdAudioDeleteShortcode();
				wpdAudioRevokeObjectURL();
				$('#wac-player-' + uid).html('');
				$('#wac-audio-comment-' + uid).val(audioID);
				$('#wac-stop-' + uid).hide();
				$('#wac-cancel-' + uid).show();
				$('#wac-record-' + uid).show();
				$('#wac-delete-' + uid).hide();
				$('#wpdiscuz-loading-bar').fadeOut(250);
			}).fail(function(jqXHR, textStatus, errorThrown) {
				console.log(errorThrown);
				$('#wpdiscuz-loading-bar').fadeOut(250);
			});
		}
	}

	function wpdAudioAddShortcode(shortcode) {
		if (isLoadRichEditor === 1) {
			wpDiscuzEditor.createEditor('#wpd-editor-' + uid).setContents([{insert: shortcode}]);
		} else {
			$('#wc-textarea-' + uid).val(shortcode);
		}
	}

	function wpdAudioDeleteShortcode() {
		if (isLoadRichEditor === 1) {
			wpDiscuzEditor.createEditor('#wpd-editor-' + uid).setContents([{insert: '\n'}]);
		} else {
			$('#wc-textarea-' + uid).val('');
		}
	}

	function wpdAudioTimerRemaining(endtime) {
		let t = Date.parse(endtime) - Date.parse(new Date());
		let seconds = Math.floor((t / 1000) % 60);
		let minutes = Math.floor((t / 1000 / 60) % 60);
		let hours = Math.floor((t / (1000 * 60 * 60)) % 24);
		let days = Math.floor(t / (1000 * 60 * 60 * 24));
		return {'total': t, 'days': days, 'hours': hours, 'minutes': minutes, 'seconds': seconds};
	}

	function wpdAudioTimerRun(id, endtime) {
		let clock = document.getElementById(id);

		function wpdAudioTimerUpdate() {
			let t = wpdAudioTimerRemaining(endtime);
			let m = t.minutes < 10 ? '0' + t.minutes : t.minutes;
			let s = t.seconds >= 10 ? t.seconds : '0' + t.seconds;
			clock.innerHTML = m + ' : ' + s;
			if (t.total <= 0) {
				wpdAudioStop();
				clearInterval(wpdAudioTimerTimeinterval);
			}
		}

		wpdAudioTimerUpdate();
		wpdAudioTimerTimeinterval = setInterval(wpdAudioTimerUpdate, 1000);
	}


	function wpdAudioTimerStop(id) {
		clearInterval(wpdAudioTimerTimeinterval);
		$(id).html('');
	}
});