=== wpDiscuz - Voice Commenting ===
Contributors: gVectors Team
Requires at least: 5.0
Tested up to: 5.8
Stable tag: 1.0.3
Requires PHP: 5.4 and higher
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Discuss with your voice in the comment section! Simply click the microphone icon
located on the comment editor toolbar and record your reply. Your voice record 
will be posted as a comment or reply. All voice records will be displayed with 
audio players in comments. People can click the play button and listen to your 
message. During recording, the record button will be changed to a stop and 
cancel buttons. Click stop to stop the recording. Once record is stopped, you 
can either post it as a voice comment or delete it. The maximum duration of 
voice comments can be managed in the addon settings page.