<?php
if (!defined("ABSPATH")) {
	exit();
}
?>

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="enableForForms">
	<div class="wpd-opt-name">
		<label for="enableForForms"><?php echo $setting["options"]["enableForForms"]["label"] ?></label>
		<p class="wpd-desc"><?php echo $setting["options"]["enableForForms"]["description"] ?></p>
	</div>
	<div class="wpd-opt-input">
        <?php
        $forms = get_posts([
	        "numberposts" => - 1,
	        "post_type"   => "wpdiscuz_form",
	        "post_status" => "publish",
        ]);
        foreach ($forms as $form) {
            ?>
            <div class="wpd-mublock-inline wpd-mu-mimes" style="width: 200px; min-width: 33%;">
                <input type="checkbox" <?php checked(in_array($form->ID, $setting["values"]->enableForForms)); ?> value="<?php echo $form->ID; ?>" name="<?php echo $setting["values"]->tabKey; ?>[enableForForms][]" id="wpdaudioform-<?php echo $form->ID; ?>" style="margin:0px; vertical-align: middle;" />
                <label for="wpdaudioform-<?php echo $form->ID; ?>" style="white-space:nowrap; font-size:13px;"><?php echo $form->post_title ? $form->post_title : __("no title", "wpdiscuz_audio") . " ( ID : " . $form->ID . " )"; ?></label>
            </div>
            <?php
        }
        ?>
        <div class="wpd-clear"></div>
	</div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="timeLimit">
    <div class="wpd-opt-name">
        <label for="timeLimit"><?php echo esc_html($setting["options"]["timeLimit"]["label"]) ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["timeLimit"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
        <span><input type="number" value="<?php echo esc_attr($setting["values"]->timeLimit); ?>" name="<?php echo $setting["values"]->tabKey; ?>[timeLimit]" id="timeLimit" style="width:70px;"> <?php esc_html_e("seconds", "wpdiscuz_audio") ?></span>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="canAddAudioComment">
	<div class="wpd-opt-name">
		<label for="canAddAudioComment"><?php echo $setting["options"]["canAddAudioComment"]["label"] ?></label>
		<p class="wpd-desc"><?php echo $setting["options"]["canAddAudioComment"]["description"] ?></p>
	</div>
	<div class="wpd-opt-input">
		<?php
		foreach (get_editable_roles() as $role => $info) {
		    ?>
            <div class="wpd-mublock-inline" style="width: 45%;">
                <input type="checkbox" <?php checked(in_array($role, $setting["values"]->canAddAudioComment)); ?> value="<?php echo $role; ?>" name="<?php echo $setting["values"]->tabKey; ?>[canAddAudioComment][]" id="wpdaudioroles-<?php echo $role; ?>" style="margin:0px; vertical-align: middle;" />
                <label for="wpdaudioroles-<?php echo $role; ?>" style="white-space:nowrap; font-size:13px;"><?php echo $info["name"]; ?></label>
            </div>
            <?php
		}
		?>
        <div class="wpd-clear"></div>
	</div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="guestCanAddAudioComment">
    <div class="wpd-opt-name">
        <label for="guestCanAddAudioComment"><?php echo esc_html($setting["options"]["guestCanAddAudioComment"]["label"]) ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["guestCanAddAudioComment"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
        <div class="wpd-switcher">
            <input type="checkbox" <?php checked($setting["values"]->guestCanAddAudioComment == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[guestCanAddAudioComment]" id="guestCanAddAudioComment">
            <label for="guestCanAddAudioComment"></label>
        </div>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="allowEditing">
    <div class="wpd-opt-name">
        <label for="allowEditing"><?php echo esc_html($setting["options"]["allowEditing"]["label"]) ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["allowEditing"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
        <div class="wpd-switcher">
            <input type="checkbox" <?php checked($setting["values"]->allowEditing == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[allowEditing]" id="allowEditing">
            <label for="allowEditing"></label>
        </div>
    </div>
</div>
<!-- Option end -->