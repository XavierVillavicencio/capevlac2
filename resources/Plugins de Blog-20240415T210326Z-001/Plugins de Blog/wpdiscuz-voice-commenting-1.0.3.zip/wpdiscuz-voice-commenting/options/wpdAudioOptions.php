<?php

class wpdAudioOptions {

    const AUDIO_DIR = '/wpdiscuz/audio';

    public $settingsOptionName = "wpdiscuz_audio_settings";
    public $tabKey = "audio";
    public $enableForForms;
    public $timeLimit;
    public $canAddAudioComment;
    public $guestCanAddAudioComment;
    public $allowEditing;
    public $mainDir;
    public $subDir;
    public $baseurl;

    public function __construct() {
        add_action("wpdiscuz_save_options", [&$this, "saveOptions"], 13);
        add_action("wpdiscuz_reset_options", [&$this, "resetOptions"], 13);
        add_filter("wpdiscuz_settings", [&$this, "settingsArray"], 75);
        $this->initDirs();
    }

    public function init() {
        $this->addOptions();
        $this->initOptions(get_option($this->settingsOptionName));
    }

    private function initDirs() {
        $wpUploadsDir = wp_upload_dir();
        $this->mainDir = $wpUploadsDir['basedir'] . self::AUDIO_DIR;
        $this->subDir = trim($wpUploadsDir['subdir'], "/");
        $this->baseurl = $wpUploadsDir['baseurl'];
    }

    public function addOptions() {
        add_option($this->settingsOptionName, $this->defaultOptions(), "", "no");
    }

    public function initOptions($options) {
        $defaults = $this->defaultOptions();
        $this->enableForForms = isset($options["enableForForms"]) ? $options["enableForForms"] : $defaults["enableForForms"];
        $this->timeLimit = isset($options["timeLimit"]) ? $options["timeLimit"] : $defaults["timeLimit"];
        $this->canAddAudioComment = isset($options["canAddAudioComment"]) ? $options["canAddAudioComment"] : $defaults["canAddAudioComment"];
        $this->guestCanAddAudioComment = isset($options["guestCanAddAudioComment"]) ? $options["guestCanAddAudioComment"] : $defaults["guestCanAddAudioComment"];
        $this->allowEditing = isset($options["allowEditing"]) ? $options["allowEditing"] : $defaults["allowEditing"];
    }

    public function saveOptions() {
        if ($this->tabKey === $_POST["wpd_tab"]) {
            $this->enableForForms = isset($_POST[$this->tabKey]["enableForForms"]) && is_array($_POST[$this->tabKey]["enableForForms"]) ? $_POST[$this->tabKey]["enableForForms"] : [];
            $this->timeLimit = !empty($_POST[$this->tabKey]["timeLimit"]) ? intval($_POST[$this->tabKey]["timeLimit"]) : 120;
            $this->canAddAudioComment = isset($_POST[$this->tabKey]["canAddAudioComment"]) && is_array($_POST[$this->tabKey]["canAddAudioComment"]) ? $_POST[$this->tabKey]["canAddAudioComment"] : [];
            $this->guestCanAddAudioComment = isset($_POST[$this->tabKey]["guestCanAddAudioComment"]) ? intval($_POST[$this->tabKey]["guestCanAddAudioComment"]) : 0;
            $this->allowEditing = isset($_POST[$this->tabKey]["allowEditing"]) ? intval($_POST[$this->tabKey]["allowEditing"]) : 0;
            update_option($this->settingsOptionName, $this->toArray());
        }
    }

    public function resetOptions($tab) {
        if ($tab === $this->tabKey || $tab === "all") {
            update_option($this->settingsOptionName, $this->defaultOptions());
            $this->initOptions(get_option($this->settingsOptionName));
        }
    }

    public function defaultOptions() {
        $formIDs = [];
        $forms = get_posts([
            "numberposts" => - 1,
            "post_type" => "wpdiscuz_form",
            "post_status" => "publish",
        ]);
        foreach ($forms as $form) {
            $formIDs[] = $form->ID;
        }
        return [
            "enableForForms" => $formIDs,
            "timeLimit" => 30,
            "canAddAudioComment" => ["administrator", "editor", "author", "contributor", "subscriber"],
            "guestCanAddAudioComment" => 0,
            "allowEditing" => 0,
        ];
    }

    public function toArray() {
        return [
            "enableForForms" => $this->enableForForms,
            "timeLimit" => $this->timeLimit,
            "canAddAudioComment" => $this->canAddAudioComment,
            "guestCanAddAudioComment" => $this->guestCanAddAudioComment,
            "allowEditing" => $this->allowEditing,
        ];
    }

    public function settingsArray($settings) {
        $settings["addons"][$this->tabKey] = [
            "title" => __("Voice Commenting", "wpdiscuz_audio"),
            "title_original" => "Voice Commenting",
            "icon" => "",
            "icon-height" => "",
            "file_path" => WPDAUDIO_DIR_PATH . "/options/html-options.php",
            "values" => $this,
            "options" => [
                "enableForForms" => [
                    "label" => __("Enable for the following comment forms", "wpdiscuz_audio"),
                    "label_original" => "Enable for the following comment forms",
                    "description" => "",
                    "description_original" => "",
                    "docurl" => "",
                ],
                "timeLimit" => [
                    "label" => __("Recording time limit", "wpdiscuz_audio"),
                    "label_original" => "Recording time limit",
                    "description" => "",
                    "description_original" => "",
                    "docurl" => "",
                ],
                "canAddAudioComment" => [
                    "label" => __("Allow user roles to post voice comments", "wpdiscuz_audio"),
                    "label_original" => "Allow user roles to post voice comments",
                    "description" => "",
                    "description_original" => "",
                    "docurl" => "",
                ],
                "guestCanAddAudioComment" => [
                    "label" => __("Allow guests to post voice comments", "wpdiscuz_audio"),
                    "label_original" => "Allow guests to post voice comments",
                    "description" => "",
                    "description_original" => "",
                    "docurl" => "",
                ],
                "allowEditing" => [
                    "label" => __("Allow voice comments editing", "wpdiscuz_audio"),
                    "label_original" => "Allow voice comments editing",
                    "description" => "",
                    "description_original" => "",
                    "docurl" => "",
                ],
            ],
        ];
        return $settings;
    }

}
