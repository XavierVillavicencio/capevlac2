<?php

class wpdAudioCommentDBManager {

    private $db;
    private $audio;

    function __construct() {
        $this->initDB();
    }

    private function initDB() {
        global $wpdb;
        $this->db = $wpdb;
        $this->audio = $this->db->prefix . "wpd_audio_comments";
    }

    public function createTable($networkWide) {
        if (is_multisite() && $networkWide) {
            $oldBlogID = $this->db->blogid;
            $blogIDs = $this->db->getBlogIDs();
            foreach ($blogIDs as $k => $blogID) {
                switch_to_blog($blogID);
                $this->_createTable();
            }
            switch_to_blog($oldBlogID);
            return;
        }
        $this->_createTable();
    }

    public function getBlogIDs() {
        return $this->db->get_col("SELECT blog_id FROM `{$this->db->blogs}`");
    }

    private function _createTable() {
        $this->initDB();
        require_once(ABSPATH . "wp-admin/includes/upgrade.php");
        $charset_collate = $this->db->get_charset_collate();
        $sql = "CREATE TABLE `{$this->audio}` (`id` INT(11) NOT NULL AUTO_INCREMENT,`path` VARCHAR(254) DEFAULT NULL,`user_id` INT(11) DEFAULT NULL,`post_id` INT(11) DEFAULT NULL,`comment_id` INT(11) DEFAULT NULL,`key` VARCHAR(50) DEFAULT NULL,`type` VARCHAR(50) DEFAULT NULL,`date` INT(11) DEFAULT NULL,PRIMARY KEY (`id`),KEY `key` (`key`),KEY `comment_id` (`comment_id`)) {$charset_collate};";
        maybe_create_table($this->audio, $sql);
    }
    
    public function addAudio($path,$postID,$userID){
        $key = $postID.uniqid();
        $time = current_time("timestamp");
        $sql = $this->db->prepare("INSERT INTO `{$this->audio}` VALUES (NULL,%s,%d,%d,0,%s,'',%d)",$path,$userID,$postID,$key,$time);
        if($this->db->query($sql)){
            return ['audio_id' => $this->db->insert_id, 'key' => $key];
        }
        return [];
    }
    
    public function updateCommentID($audioID,$commentID){
        $sql = $this->db->prepare("UPDATE `{$this->audio}` SET `comment_id` = %d WHERE `comment_id`= 0 AND `id` = %d",$commentID,$audioID);
        if($this->db->query($sql)){
            update_comment_meta($commentID, 'wpd_audio_id', $audioID);
        }
    }
    
    public function getPathByID($audioID){
        $sql = $this->db->prepare("SELECT `path` FROM `{$this->audio}` WHERE `id` = %d",$audioID);
        return $this->db->get_var($sql);
    }
    
    public function getPathByCommentID($commentID){
        $sql = $this->db->prepare("SELECT `path` FROM `{$this->audio}` WHERE `comment_id` = %d",$commentID);
        return $this->db->get_var($sql);
    }
    
    public function getAudioInfoByKey($key){
        $sql = $this->db->prepare("SELECT `path`,`comment_id`  FROM `{$this->audio}` WHERE `key` = %s ", $key);
        return $this->db->get_row($sql,ARRAY_A);
    } 
    
    public function deleteAudio($audioID, $commentID = 0){
         $sql = $this->db->prepare("DELETE FROM `{$this->audio}` WHERE `id` = %d AND `comment_id` = %d",$audioID, $commentID);
         return $this->db->query($sql);
    }
  
    public function  deleteAudioByCommentID($commentID){
        $sql = $this->db->prepare("DELETE FROM `{$this->audio}` WHERE `comment_id` = %d", $commentID);
        return $this->db->query($sql);
    }
    
    public function getUnusedFiles(){
        $time = current_time("timestamp") - DAY_IN_SECONDS;
        $sql = $this->db->prepare("SELECT `id`,`path` FROM `{$this->audio}` WHERE `comment_id` = 0 AND `date` < %d", $time);
        return $this->db->get_results($sql,ARRAY_A);
    }
}
