<?php

if (!defined("ABSPATH")) {
    exit();
}

class WAMOptions implements WAMConstants {

    private $dbManager;
    private $defaultExpireTime;
    public $wamIsDisplayOnReplies;
    public $wamIsCachingDisabled;
    public $wamCacheExpireTime;
    public $tabKey = "wam";

    public function __construct($dbManager) {
        $this->dbManager = $dbManager;
        $options = maybe_unserialize(get_option(self::OPTION_MAIN_OPTIONS));
        $this->defaultExpireTime = 60 * 60 * 24 * 3; // seconds * minutes * hours
        $this->addOptions();
        $this->initOptions($options);
    }

    public function addOptions() {
        $options = [
            "wamIsDisplayOnReplies" => 0,
            "wamIsCachingDisabled" => 0,
            "wamCacheExpireTime" => $this->defaultExpireTime
        ];
        add_option(self::OPTION_MAIN_OPTIONS, $options, "", "no");
    }

    public function initOptions($options) {
        $options = maybe_unserialize($options);
        $this->wamIsDisplayOnReplies = isset($options["wamIsDisplayOnReplies"]) ? $options["wamIsDisplayOnReplies"] : 0;
        $this->wamIsCachingDisabled = isset($options["wamIsCachingDisabled"]) ? $options["wamIsCachingDisabled"] : 0;
        $this->wamCacheExpireTime = isset($options["wamCacheExpireTime"]) ? $options["wamCacheExpireTime"] : $this->defaultExpireTime;
    }

    public function toArray() {
        $options = [
            "wamIsDisplayOnReplies" => $this->wamIsDisplayOnReplies,
            "wamIsCachingDisabled" => $this->wamIsCachingDisabled,
            "wamCacheExpireTime" => $this->wamCacheExpireTime,
        ];
        return $options;
    }

    public function saveOptions() {
        if ($this->tabKey === $_POST["wpd_tab"]) {
            $this->wamIsDisplayOnReplies = isset($_POST[$this->tabKey]["wamIsDisplayOnReplies"]) ? absint($_POST[$this->tabKey]["wamIsDisplayOnReplies"]) : 0;
            $this->wamIsCachingDisabled = isset($_POST[$this->tabKey]["wamIsCachingDisabled"]) ? absint($_POST[$this->tabKey]["wamIsCachingDisabled"]) : 0;
            $this->wamCacheExpireTime = isset($_POST[$this->tabKey]["wamCacheExpireTime"]) ? absint($_POST[$this->tabKey]["wamCacheExpireTime"]) * HOUR_IN_SECONDS : $this->defaultExpireTime;
            update_option(self::OPTION_MAIN_OPTIONS, $this->toArray());
        }
    }

    public function resetOptions($tab) {
        if ($tab === $this->tabKey || $tab === "all") {
            delete_option(self::OPTION_MAIN_OPTIONS);
            $this->addOptions();
            $options = get_option(self::OPTION_MAIN_OPTIONS);
            $this->initOptions($options);
        }
    }

    public function resetCache() {
        $validNonce = isset($_GET["_wpnonce"]) && wp_verify_nonce($_GET["_wpnonce"], "resetCache");
        if ($validNonce && isset($_GET["cache"]) && ($key = filter_var($_GET["cache"], FILTER_SANITIZE_STRING)) && current_user_can("manage_options")) {
            delete_transient($key);
        }
        wp_redirect(admin_url("admin.php?page=" . WpdiscuzCore::PAGE_SETTINGS . "&wpd_tab=" . $this->tabKey));
    }

    public function settingsArray($settings) {
        $settings["addons"][$this->tabKey] = [
            "title" => __("Ads Manager", "wpdiscuz-ads-manager"),
            "title_original" => "Ads Manager",
            "icon" => "",
            "icon-height" => "",
            "file_path" => WAM_DIR_PATH . "/options/settings.php",
            "values" => $this,
            "options" => [
                "wamIsDisplayOnReplies" => [
                    "label" => __('Display ads between replies', "wpdiscuz-ads-manager"),
                    "label_original" => 'Display ads between replies',
                    "description" => "This option is related to the 'Comment list' location in Banner settings.",
                    "description_original" => "",
                    "docurl" => "#"
                ],
                "wamIsCachingDisabled" => [
                    "label" => __("Disable caching", "wpdiscuz-ads-manager"),
                    "label_original" => "Disable caching",
                    "description" => "",
                    "description_original" => "",
                    "docurl" => "#"
                ],
                "wamCacheExpireTime" => [
                    "label" => __("Set cache expire time for", "wpdiscuz-ads-manager"),
                    "label_original" => "Set cache expire time for",
                    "description" => "",
                    "description_original" => "",
                    "docurl" => "#"
                ],
                "wamResetCache" => [
                    "label" => __("Reset ads cache", "wpdiscuz-ads-manager"),
                    "label_original" => "Reset ads cache",
                    "description" => "",
                    "description_original" => "",
                    "docurl" => "#"
                ],
                "wamResetBannersCache" => [
                    "label" => __("Reset banners cache", "wpdiscuz-ads-manager"),
                    "label_original" => "Reset banners cache",
                    "description" => "",
                    "description_original" => "",
                    "docurl" => "#"
                ],
            ],
        ];
        return $settings;
    }

}
