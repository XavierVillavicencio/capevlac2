<?php
if (!defined('ABSPATH')) {
    exit();
}
?>
<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="wamIsDisplayOnReplies">
    <div class="wpd-opt-name">
        <label for="wamIsDisplayOnReplies"><?php echo $setting["options"]["wamIsDisplayOnReplies"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["wamIsDisplayOnReplies"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
        <div class="wpd-switcher">
            <input type="checkbox" <?php checked($setting["values"]->wamIsDisplayOnReplies == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[wamIsDisplayOnReplies]" id="wamIsDisplayOnReplies">
            <label for="wamIsDisplayOnReplies"></label>
        </div>
    </div>
</div>
<!-- Option end -->
<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="wamIsCachingDisabled">
    <div class="wpd-opt-name">
        <label for="wamIsCachingDisabled"><?php echo $setting["options"]["wamIsCachingDisabled"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["wamIsCachingDisabled"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
        <div class="wpd-switcher">
            <input type="checkbox" <?php checked($setting["values"]->wamIsCachingDisabled == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[wamIsCachingDisabled]" id="wamIsCachingDisabled">
            <label for="wamIsCachingDisabled"></label>
        </div>
    </div>
</div>
<!-- Option end -->
<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="wamCacheExpireTime">
    <div class="wpd-opt-name">
        <label for="wamCacheExpireTime"><?php echo $setting["options"]["wamCacheExpireTime"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["wamCacheExpireTime"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
        <select id="wamCacheExpireTime" name="<?php echo WpdiscuzCore::TAB_LIVE; ?>[wamCacheExpireTime]">
            <option value="1" <?php selected($setting["values"]->wamCacheExpireTime, 1 * HOUR_IN_SECONDS); ?>><?php _e("1 hour", "wpdiscuz-ads-manager"); ?></option>
            <option value="3" <?php selected($setting["values"]->wamCacheExpireTime, 3 * HOUR_IN_SECONDS); ?>><?php _e("3 hours", "wpdiscuz-ads-manager"); ?></option>
            <option value="6" <?php selected($setting["values"]->wamCacheExpireTime, 6 * HOUR_IN_SECONDS); ?>><?php _e("6 hours", "wpdiscuz-ads-manager"); ?></option>
            <option value="12" <?php selected($setting["values"]->wamCacheExpireTime, 12 * HOUR_IN_SECONDS); ?>><?php _e("12 hours", "wpdiscuz-ads-manager"); ?></option>
            <option value="24" <?php selected($setting["values"]->wamCacheExpireTime, 24 * HOUR_IN_SECONDS); ?>><?php _e("1 day", "wpdiscuz-ads-manager"); ?></option>
            <option value="48" <?php selected($setting["values"]->wamCacheExpireTime, 48 * HOUR_IN_SECONDS); ?>><?php _e("2 days", "wpdiscuz-ads-manager"); ?></option>
            <option value="72" <?php selected($setting["values"]->wamCacheExpireTime, 72 * HOUR_IN_SECONDS); ?>><?php _e("3 days", "wpdiscuz-ads-manager"); ?></option>
            <option value="168" <?php selected($setting["values"]->wamCacheExpireTime, 168 * HOUR_IN_SECONDS); ?>><?php _e("1 week", "wpdiscuz-ads-manager"); ?></option>
        </select>
    </div>
</div>
<!-- Option end -->
<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="wamResetCache">
    <div class="wpd-opt-name">
        <label for="wamResetCache"><?php echo $setting["options"]["wamResetCache"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["wamResetCache"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
        <?php
        $resetAdsCache = admin_url("admin-post.php?action=wamResetCache&cache=" . $setting["values"]::TRANSIENT_WAM_ADS);
        ?>
        <a href="<?php echo wp_nonce_url($resetAdsCache, "resetCache"); ?>" class="button button-secondary" style="text-decoration: none;"><?php _e("Reset ads cache", "wpdiscuz-ads-manager"); ?></a>
    </div>
</div>
<!-- Option end -->
<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="wamResetBannersCache">
    <div class="wpd-opt-name">
        <label for="wamResetBannersCache"><?php echo $setting["options"]["wamResetBannersCache"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["wamResetBannersCache"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
        <?php
        $resetBannersCache = admin_url("admin-post.php?action=wamResetCache&cache=" . $setting["values"]::TRANSIENT_WAM_BANNERS);
        ?>
        <a href="<?php echo wp_nonce_url($resetBannersCache, "resetCache"); ?>" class="button button-secondary" style="text-decoration: none;"><?php _e("Reset banners cache", "wpdiscuz-ads-manager"); ?></a>
    </div>
</div>
<!-- Option end -->