<?php
if (!defined("ABSPATH")) {
    exit();
}

interface WAMConstants {

    /* === OPTIONS SLUGS === */
    const OPTION_VERSION                            = "wam_version";
    const OPTION_MAIN_OPTIONS                       = "wam_options";
    const OPTION_DUMMY_DATA                         = "wam_dummy_data";
    
    /* === TRANSIENTS SLUGS === */
    const TRANSIENT_WAM_ADS                         = "wam_ads_cache";
    const TRANSIENT_WAM_BANNERS                     = "wam_banners_cache";

    /* === DASHBOARD MENU PAGES === */
    const PAGE_OPTIONS                              = "wam_options_page";
    
    /* === WPDISCUZ ADS POST TYPE === */
    const POST_TYPE                                 = "wpdiscuz_ad";

    /* === WPDISCUZ ADS TAXONOMY TYPE === */
    const TAXONOMY_TYPE                             = "wam_banner";
    
    /* === WPDISCUZ ADS POST TYPE CAPABILITIES === */
   
   const CAP_PUBLISH_ADS                            = "publish_wpdiscuz_ads";
   const CAP_READ_AD                                = "read_wpdiscuz_ad";
   const CAP_READ_PRIVATE_ADS                       = "read_private_wpdiscuz_ads";
   const CAP_EDIT_AD                                = "edit_wpdiscuz_ad";
   const CAP_EDIT_ADS                               = "edit_wpdiscuz_ads";
   const CAP_EDIT_OTHERS_ADS                        = "edit_others_wpdiscuz_ads";
   const CAP_DELETE_AD                              = "delete_wpdiscuz_ad";
   const CAP_DELETE_ADS                             = "delete_wpdiscuz_ads";
   const CAP_DELETE_OTHERS_ADS                      = "delete_others_wpdiscuz_ads";  
   
   
   /* === WPDISCUZ ADS TAXONOMY TYPE CAPABILITIES === */
   
   const CAP_MANAGE_BANNERS                         = "manage_wam_banners";
   const CAP_EDIT_BANNERS                           = "edit_wam_banners";
   const CAP_DELETE_BANNERS                         = "delete_wam_banners";
   const CAP_ASSIGN_BANNERS                         = "assign_wam_banners";  
   

   /* === WPDISCUZ AD META NONCE KEYS === */
   const META_NONCE_AD_POST_TYPES                   = "wam_meta_nonce_ad_post_types";
   const META_NONCE_AD_HIDE_FOR_ROLES               = "wam_meta_nonce_ad_hide_for_roles";
   const META_NONCE_AD_EXCLUDE_POSTS                = "wam_meta_nonce_ad_exclude_posts";
   const META_NONCE_AD_DATE_START                   = "wam_meta_nonce_ad_date_start";
   const META_NONCE_AD_DATE_END                     = "wam_meta_nonce_ad_date_end";
   
   /* === WPDISCUZ BANNER META NONCE KEYS === */
   const META_NONCE_BANNER_LOCATION                 = "wam_meta_nonce_banner_location";
   const META_NONCE_BANNER_REPEATS                  = "wam_meta_nonce_banner_repeats";
   
   /* === WPDISCUZ AD META KEYS === */
   const META_KEY_AD_POST_TYPES                     = "_wam_ad_post_types";
   const META_KEY_AD_HIDE_FOR_ROLES                 = "_wam_ad_hide_for_roles";
   const META_KEY_AD_EXCLUDE_POSTS                  = "_wam_ad_exclude_posts";
   const META_KEY_AD_DATE_START                     = "_wam_ad_date_start";
   const META_KEY_AD_DATE_END                       = "_wam_ad_date_end";
   
   /* === WPDISCUZ AD TAXONOMY META KEYS === */
   const META_KEY_BANNER_LOCATION                   = "_wam_banner_location";
   const META_KEY_BANNER_REPEATS                    = "_wam_banner_repeats";
   
   /* === WPDISCUZ BANNER LOCATION KEYS === */
   const LOCATION_FORM_TOP                          = "comments_form_top";
   const LOCATION_FORM_BOTTOM                       = "comments_form_bottom";
   const LOCATION_BOX_TOP                           = "comments_box_top";
   const LOCATION_BOX_BOTTOM                        = "comments_box_bottom";
   const LOCATION_LIST                              = "comments_list";
}
