=== wpDiscuz - Ads Manager ===
Contributors: gVectors Team
Requires at least: 5.0
Tested up to: 5.7
Stable tag: 7.0.7
Requires PHP: 5.4 and higher
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

wpDiscuz Ads Manager is a light and powerful advertisement management system that allows you 
to add ads in comment area (after and before comment form, after and before comment list, 
after and before comments). You can display adverts in comment form and on comment list. 
There are many locations and ability to create ad banners with different displaying logics. 
You can attach many ads to one banner and show them randomly on top/bottom of comment form 
and after X parent comment on comment list. You can use simple text, HTML, iframes and ad 
service codes like Google Ads in advert banners…