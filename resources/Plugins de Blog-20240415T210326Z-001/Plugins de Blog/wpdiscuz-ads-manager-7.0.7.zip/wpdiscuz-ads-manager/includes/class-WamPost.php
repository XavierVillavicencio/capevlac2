<?php

if (!defined("ABSPATH")) {
    exit();
}

class WAMPost implements WAMConstants {

    private $capabilities;
    private $dbManager;

    public function __construct($dbManager) {
        $this->dbManager = $dbManager;
        $this->initCapabilites();
        add_action("admin_post_changeStatus", [&$this, "changeStatus"]);
        add_action("transition_post_status", [&$this, "deleteCache"], 10, 3);
    }

    public function postTypeInit() {
        register_post_type(self::POST_TYPE, $this->getPostTypeArgs());
    }

    private function initCapabilites() {
        $this->capabilities = [
            "publish_posts" => self::CAP_PUBLISH_ADS,
            "read_post" => self::CAP_READ_AD,
            "read_private_posts" => self::CAP_READ_PRIVATE_ADS,
            "edit_post" => self::CAP_EDIT_AD,
            "edit_posts" => self::CAP_EDIT_ADS,
            "edit_others_posts" => self::CAP_EDIT_OTHERS_ADS,
            "delete_post" => self::CAP_DELETE_AD,
            "delete_posts" => self::CAP_DELETE_ADS,
            "delete_others_posts" => self::CAP_DELETE_OTHERS_ADS,
        ];
    }

    public function addCaps() {
        $admins = get_role("administrator");
        $admins->add_cap(self::CAP_PUBLISH_ADS);
        $admins->add_cap(self::CAP_READ_AD);
        $admins->add_cap(self::CAP_READ_PRIVATE_ADS);
        $admins->add_cap(self::CAP_EDIT_AD);
        $admins->add_cap(self::CAP_EDIT_ADS);
        $admins->add_cap(self::CAP_EDIT_OTHERS_ADS);
        $admins->add_cap(self::CAP_DELETE_AD);
        $admins->add_cap(self::CAP_DELETE_ADS);
        $admins->add_cap(self::CAP_DELETE_OTHERS_ADS);
    }

    public function addMetaBoxes() {
        add_meta_box("wam_meta_posttypes", __("Post types", "wpdiscuz-ads-manager"), [&$this, "wamMetaPosttypes"], self::POST_TYPE);
        add_meta_box("wam_meta_hideforroles", __("Hide for roles", "wpdiscuz-ads-manager"), [&$this, "wamMetaHideForRoles"], self::POST_TYPE);
        add_meta_box("wam_meta_excludeposts", __("Exclude posts by id", "wpdiscuz-ads-manager"), [&$this, "wamMetaExcludePosts"], self::POST_TYPE, "side");
        add_meta_box("wam_meta_date_start", __("Ad start date", "wpdiscuz-ads-manager"), [&$this, "wamMetaDateStart"], self::POST_TYPE, "side");
        add_meta_box("wam_meta_date_end", __("Ad end date", "wpdiscuz-ads-manager"), [&$this, "wamMetaDateEnd"], self::POST_TYPE, "side");
    }

    public function wamMetaPosttypes($post) {
        include_once WAM_DIR_PATH . "/includes/metas/post/meta-post-types.php";
    }

    public function wamMetaHideForRoles($post) {
        include_once WAM_DIR_PATH . "/includes/metas/post/meta-hide-for-roles.php";
    }

    public function wamMetaExcludePosts($post) {
        include_once WAM_DIR_PATH . "/includes/metas/post/meta-exclude-posts.php";
    }

    public function wamMetaDateStart($post) {
        include_once WAM_DIR_PATH . "/includes/metas/post/meta-date-start.php";
    }

    public function wamMetaDateEnd($post) {
        include_once WAM_DIR_PATH . "/includes/metas/post/meta-date-end.php";
    }

    public function wamSaveMeta($post_id, $post) {
        if ($post->post_type == self::POST_TYPE) {
            $isValidPostTypesNonce = (isset($_POST[self::META_NONCE_AD_POST_TYPES]) && wp_verify_nonce($_POST[self::META_NONCE_AD_POST_TYPES], WAM_BASENAME_FILE)) ? true : false;
            $isValidHideForRolesNonce = (isset($_POST[self::META_NONCE_AD_HIDE_FOR_ROLES]) && wp_verify_nonce($_POST[self::META_NONCE_AD_HIDE_FOR_ROLES], WAM_BASENAME_FILE)) ? true : false;
            $isValidExcludePostsNonce = (isset($_POST[self::META_NONCE_AD_EXCLUDE_POSTS]) && wp_verify_nonce($_POST[self::META_NONCE_AD_EXCLUDE_POSTS], WAM_BASENAME_FILE)) ? true : false;
            $isValidDateStartNonce = (isset($_POST[self::META_NONCE_AD_DATE_START]) && wp_verify_nonce($_POST[self::META_NONCE_AD_DATE_START], WAM_BASENAME_FILE)) ? true : false;
            $isValidDateEndNonce = (isset($_POST[self::META_NONCE_AD_DATE_END]) && wp_verify_nonce($_POST[self::META_NONCE_AD_DATE_END], WAM_BASENAME_FILE)) ? true : false;

            if ($isValidPostTypesNonce && $isValidHideForRolesNonce && $isValidExcludePostsNonce && $isValidDateStartNonce && $isValidDateEndNonce) {
                $postTypes = isset($_POST[self::META_KEY_AD_POST_TYPES]) && $_POST[self::META_KEY_AD_POST_TYPES] && is_array($_POST[self::META_KEY_AD_POST_TYPES]) ? implode(",", $_POST[self::META_KEY_AD_POST_TYPES]) : "";
                $hideforRoles = isset($_POST[self::META_KEY_AD_HIDE_FOR_ROLES]) && $_POST[self::META_KEY_AD_HIDE_FOR_ROLES] && is_array($_POST[self::META_KEY_AD_HIDE_FOR_ROLES]) ? implode(",", $_POST[self::META_KEY_AD_HIDE_FOR_ROLES]) : "";
                $excludeIds = isset($_POST[self::META_KEY_AD_EXCLUDE_POSTS]) && ($excludeIds = trim($_POST[self::META_KEY_AD_EXCLUDE_POSTS])) ? $excludeIds : "";
                $startDate = isset($_POST[self::META_KEY_AD_DATE_START]) && ($start = trim($_POST[self::META_KEY_AD_DATE_START])) ? $start : "";
                $endDate = isset($_POST[self::META_KEY_AD_DATE_END]) && ($end = trim($_POST[self::META_KEY_AD_DATE_END])) ? $end : "";

                update_post_meta($post_id, self::META_KEY_AD_POST_TYPES, $postTypes);
                update_post_meta($post_id, self::META_KEY_AD_HIDE_FOR_ROLES, $hideforRoles);
                update_post_meta($post_id, self::META_KEY_AD_EXCLUDE_POSTS, $excludeIds);
                update_post_meta($post_id, self::META_KEY_AD_DATE_START, $startDate);
                update_post_meta($post_id, self::META_KEY_AD_DATE_END, $endDate);
                delete_transient(self::TRANSIENT_WAM_ADS);
            }
        }
    }

    private function getPostTypeArgs() {
        $labels = [
            "name" => __("Advertising", "wpdiscuz-ads-manager"),
            "singular_name" => __("Advertising", "wpdiscuz-ads-manager"),
            "add_new" => __("Add New", "wpdiscuz-ads-manager"),
            "add_new_item" => __("Add New Advertising", "wpdiscuz-ads-manager"),
            "edit_item" => __("Edit Advertising", "wpdiscuz-ads-manager"),
            "new_item" => __("New Advertising", "wpdiscuz-ads-manager"),
            "view_item" => __("View Advertising", "wpdiscuz-ads-manager"),
            "menu_name" => __("Advertising", "wpdiscuz-ads-manager"),
            "name_admin_bar" => __("Advertising", "wpdiscuz-ads-manager"),
            "all_items" => __("&raquo; Advertising", "wpdiscuz-ads-manager"),
            "search_items" => __("Search ads", "wpdiscuz-ads-manager"),
            "not_found" => __("No ads found.", "wpdiscuz-ads-manager"),
            "not_found_in_trash" => __("No ads found in Trash.", "wpdiscuz-ads-manager")
        ];
        $args = [
            "labels" => $labels,
            "description" => __("Description.", "wpdiscuz-ads-manager"),
            "public" => false,
            "publicly_queryable" => false,
            "show_ui" => true,
            "show_in_menu" => false,
            "menu_position" => 25,
//            "query_var" => true,
            "rewrite" => true,
            "capability_type" => "post",
            "has_archive" => false,
            "hierarchical" => false,
            "exclude_from_search" => true,
            "supports" => ["title", "editor", "author"],
            "map_meta_cap" => true,
            "capabilities" => $this->capabilities,
        ];

        return $args;
    }

    public function wamAdColumns($columns) {
        if (is_array($columns)) {
            $columns["wam_post_types"] = __("Post Types", "wpdiscuz-ads-manager");
            $columns["wam_start_date"] = __("Start", "wpdiscuz-ads-manager");
            $columns["wam_end_date"] = __("End", "wpdiscuz-ads-manager");
            $columns["wam_post_status"] = __("Post Status", "wpdiscuz-ads-manager");
            $columns["wam_ad_status"] = __("Ad Status", "wpdiscuz-ads-manager");
        }
        return $columns;
    }

    public function wamAdCustomColumn($column, $post_id) {
        if ("wam_post_types" === $column) {
            $postTypes = get_post_meta($post_id, self::META_KEY_AD_POST_TYPES, true);
            if (is_array($postTypes)) {
                print implode(", ", $postTypes);
            } else {
                print $postTypes ? $postTypes : "";
            }
        } else if ("wam_start_date" === $column) {
            $dateStart = get_post_meta($post_id, self::META_KEY_AD_DATE_START, true);
            print $dateStart ? $dateStart : __("No start date", "wpdiscuz-ads-manager");
        } else if ("wam_end_date" === $column) {
            $dateEnd = get_post_meta($post_id, self::META_KEY_AD_DATE_END, true);
            print $dateEnd ? $dateEnd : __("No end date", "wpdiscuz-ads-manager");
        } else if ("wam_post_status" === $column) {
            $status = get_post_status($post_id);
            print $status;
        } else if ("wam_ad_status" === $column) {
            $dateStart = get_post_meta($post_id, self::META_KEY_AD_DATE_START, true);
            $dateEnd = get_post_meta($post_id, self::META_KEY_AD_DATE_END, true);
            $status = $this->getStatus($post_id, $dateStart, $dateEnd);
            print $status;
        }
    }

    private function getStatus($post_id, $dateStart, $dateEnd) {
        $start = strtotime($dateStart);
        $end = strtotime($dateEnd);
        $currDate = current_time("timestamp");
        $statusDesc = "";
        $postStatus = get_post_status($post_id);
        $statusClass = " wam-status-active ";
        $msg = __("Active", "wpdiscuz-ads-manager");


        if ($postStatus == "publish" && $start) {

            if ($start <= $currDate && ((!$end || $end >= $currDate))) {
                $statusClass = " wam-status-active ";
                $msg = __("Active", "wpdiscuz-ads-manager");
                $ending = $currDate + (3 * DAY_IN_SECONDS);
                if ($end && $end <= $ending) {
                    $statusClass .= " wam-status-ending ";
                    $msg = __("Ending", "wpdiscuz-ads-manager");
                }
                $statusDesc = __("Click to unpublish", "wpdiscuz-ads-manager");
            } else if ($start > $currDate && (!$end || $end >= $start)) {
                $statusClass = " wam-status-scheduled ";
                $msg = __("Scheduled", "wpdiscuz-ads-manager");
            } else if ($end && $end < $currDate) {
                $msg = __("Inactive", "wpdiscuz-ads-manager");
                $statusClass .= "wam-status-inactive wam-status-ended";
            }
        } else {
            $msg = __("Inactive", "wpdiscuz-ads-manager");
            $statusClass = " wam-status-inactive ";
            if ($end && $currDate > $end) {
                $statusClass .= "wam-status-ended";
            } else {
                $statusDesc = __("Click to publish", "wpdiscuz-ads-manager");
            }
        }

        $statusUrl = admin_url("admin-post.php/?action=changeStatus&post_id=$post_id");
        $status = "<div class='wam-status-block'>";
        $status .= "<div title='$statusDesc'>";
        $status .= "<a href='" . wp_nonce_url($statusUrl, "changeStatus") . "' class='wam-status $statusClass'>$msg</a>";
        $status .= "</div>";
        $status .= "</div>";
        return $status;
    }

    public function restrictAds() {
        global $typenow;
        if ($typenow == self::POST_TYPE) {
            $currentTax = isset($_GET[self::TAXONOMY_TYPE]) ? $_GET[self::TAXONOMY_TYPE] : "";
            $taxObject = get_taxonomy(self::TAXONOMY_TYPE);
            $terms = get_terms(self::TAXONOMY_TYPE);
            $bannersHtml = "";
            if (count($terms) > 0) {
                $bannersHtml .= "<select name='" . self::TAXONOMY_TYPE . "' id='" . self::TAXONOMY_TYPE . "' class='postform'>";
                $bannersHtml .= "<option value=''>" . __("All {$taxObject->labels->name}", "wpdiscuz-ads-manager") . "</option>";
                foreach ($terms as $term) {
                    $selected = $currentTax == $term->slug ? " selected='selected'" : "";
                    $bannersHtml .= "<option value='{$term->slug}' {$selected}>{$term->name} ({$term->count}) </option>";
                }
                $bannersHtml .= "</select>";
            }
            echo $bannersHtml;
        }
    }

    public function changeStatus() {
        if (current_user_can("manage_options") && !empty($_GET["_wpnonce"]) && wp_verify_nonce($_GET["_wpnonce"], "changeStatus") && !empty($_GET["post_id"]) && ($id = intval($_GET["post_id"]))) {
            $postStatus = (get_post_status($id) == "publish") ? "pending" : "publish";
            $postarr = array(
                "ID" => $id,
                "post_status" => $postStatus
            );
            wp_update_post($postarr);
        }
        wp_redirect(admin_url("edit.php?post_type=" . self::POST_TYPE));
    }

    public function deleteCache($newStatus, $oldStatus, $post) {
        if ($newStatus != $oldStatus && $post && $post->post_type == self::POST_TYPE) {
            delete_transient(self::TRANSIENT_WAM_ADS);
        }
    }

}
