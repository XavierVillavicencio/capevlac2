<?php
if (!defined('ABSPATH')) {
    exit();
}

wp_nonce_field(WAM_BASENAME_FILE, self::META_NONCE_AD_HIDE_FOR_ROLES);
$wamHideForRoles = get_post_meta($post->ID, self::META_KEY_AD_HIDE_FOR_ROLES, true);
if (!is_array($wamHideForRoles)) {
    $wamHideForRoles = explode(',', $wamHideForRoles);
}
$wpRoles = get_editable_roles();
?>
<div class="wam-meta-wrapper">
    <?php
    foreach ($wpRoles as $wpRole => $roleInfo) {
        $checked = (is_array($wamHideForRoles) && in_array($wpRole, $wamHideForRoles)) ? 'checked="checked"' : '';
        ?>
        <div class="wam-role-block">
            <input type="checkbox" id="wam-role-<?php echo $wpRole; ?>" name="<?php echo self::META_KEY_AD_HIDE_FOR_ROLES; ?>[]" value="<?php echo $wpRole; ?>" <?php echo $checked; ?> />
            <label for="wam-role-<?php echo $wpRole; ?>" class="wam-row-title wam-role"><?php echo $wpRole; ?></label>
        </div>
        <?php
    }
    ?>
</div>