<?php
if (!defined('ABSPATH')) {
    exit();
}
wp_nonce_field(WAM_BASENAME_FILE, self::META_NONCE_AD_POST_TYPES);
$wamPostTypes = get_post_meta($post->ID, self::META_KEY_AD_POST_TYPES, true);
if (!is_array($wamPostTypes)) {
    $wamPostTypes = explode(',', $wamPostTypes);
}

$postTypes = get_post_types(array('public' => true), 'names');
$url = $_SERVER['REQUEST_URI'];
if (preg_match('#(/post\-new\.php\?post_type=wpdiscuz_ad)+$#is', $url)) {
    $wamPostTypes = $postTypes;
}
?>
<div class="wam-meta-wrapper">
    <?php
    foreach ($postTypes as $type) {
        if (post_type_supports($type, 'comments')) {
            $checked = is_array($wamPostTypes) && in_array($type, $wamPostTypes) ? 'checked="checked"' : '';
            ?>
            <div class="wam-post-type-block">
                <input type="checkbox" id="wam-type-<?php echo $type; ?>" name="<?php echo self::META_KEY_AD_POST_TYPES; ?>[]" value="<?php echo $type; ?>" <?php echo $checked; ?> />
                <label for="wam-type-<?php echo $type; ?>" class="wam-row-title wam-post-type"><?php echo $type; ?></label>
            </div>
            <?php
        }
    }
    ?>
</div>