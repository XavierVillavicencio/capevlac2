<?php
if (!defined('ABSPATH')) {
    exit();
}

wp_nonce_field(WAM_BASENAME_FILE, self::META_NONCE_AD_DATE_END);
$wamDateEnd = get_post_meta($post->ID, self::META_KEY_AD_DATE_END, true);
$endDate = $wamDateEnd ? $wamDateEnd : '';
?>
<div class="wam-meta-wrapper">
    <div>
        <input type="text" id="wam-end-date" class="wam-ad-end" name="<?php echo self::META_KEY_AD_DATE_END; ?>" value="<?php echo $endDate; ?>"/>
        &nbsp;<label for="wam-end-date"><?php _e('End', 'wpdiscuz-ads-manager'); ?></label>
        <p class="howto" id="new-tag-wam_banner-desc"><?php _e('The ad will be disappeared at the first minute of the date you set in this option.', 'wpdiscuz-ads-manager'); ?></p>
    </div>
</div>