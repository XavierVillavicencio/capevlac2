<?php
if (!defined('ABSPATH')) {
    exit();
}
wp_nonce_field(WAM_BASENAME_FILE, self::META_NONCE_AD_DATE_START);
$wamDateStart = get_post_meta($post->ID, self::META_KEY_AD_DATE_START, true);
$startDate = $wamDateStart ? $wamDateStart : '';
?>
<div class="wam-meta-wrapper">
    <div>
        <input type="text" id="wam-start-date" class="wam-ad-start" name="<?php echo self::META_KEY_AD_DATE_START; ?>" value="<?php echo $startDate; ?>" />
        &nbsp;<label for="wam-start-date"><?php _e('Start', 'wpdiscuz-ads-manager'); ?></label>
    </div>    
</div>