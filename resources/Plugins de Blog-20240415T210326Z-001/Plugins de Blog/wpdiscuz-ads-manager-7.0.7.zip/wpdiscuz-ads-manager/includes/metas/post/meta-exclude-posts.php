<?php
if (!defined('ABSPATH')) {
    exit();
}

wp_nonce_field(WAM_BASENAME_FILE, self::META_NONCE_AD_EXCLUDE_POSTS);
$wamExcludePosts = ($postIds = trim(get_post_meta($post->ID, self::META_KEY_AD_EXCLUDE_POSTS, true))) ? $postIds : '';
?>
<div class="wam-meta-wrapper">
    <div><input type="text" id="wam-exclude-posts" name="<?php echo self::META_KEY_AD_EXCLUDE_POSTS; ?>" value="<?php echo $wamExcludePosts; ?>" /></div>
</div>