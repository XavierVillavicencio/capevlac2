<?php
if (!defined('ABSPATH')) {
    exit();
}
wp_nonce_field(WAM_BASENAME_FILE, self::META_NONCE_BANNER_REPEATS);
$val = ($bannerRepeats = (get_term_meta($term->term_id, self::META_KEY_BANNER_REPEATS, true))) ? $bannerRepeats : 3;
?>
<tr class="form-field wam-meta-repeats">
    <th scope="row" valign="top"><label for="<?php echo self::META_KEY_BANNER_REPEATS; ?>"><?php _e('Banner repeats each x comments', 'wpdiscuz-ads-manager'); ?></label></th>
    <td>
        <input type="number" id="<?php echo self::META_KEY_BANNER_REPEATS; ?>" class="wam-meta-ad-repeats" value="<?php echo $val; ?>" name="<?php echo self::META_KEY_BANNER_REPEATS; ?>" >
        <p class="description"><?php _e('Enter a value for this field', 'wpdiscuz-ads-manager'); ?></p>
    </td>
</tr>