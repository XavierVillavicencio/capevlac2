<?php
if (!defined('ABSPATH')) {
    exit();
}
wp_nonce_field(WAM_BASENAME_FILE, self::META_NONCE_BANNER_REPEATS);
?>
<div class="form-field wam-meta-repeats">
    <label for="<?php echo self::META_KEY_BANNER_REPEATS; ?>"><?php _e('Banner repeats each x comments', 'wpdiscuz-ads-manager'); ?></label>
    <input type="number" name="<?php echo self::META_KEY_BANNER_REPEATS; ?>" id="<?php echo self::META_KEY_BANNER_REPEATS; ?>" value="3">
    <p class="description"><?php _e('Enter a value for this field', 'wpdiscuz-ads-manager'); ?></p>
</div>