<?php
if (!defined('ABSPATH')) {
    exit();
}

wp_nonce_field(WAM_BASENAME_FILE, self::META_NONCE_BANNER_LOCATION);
$wamLocation = ($loc = get_term_meta($term->term_id, self::META_KEY_BANNER_LOCATION, true)) ? $loc : 'location_none';
?>
<tr class="form-field wam-meta-location-wrapper">
    <th scope="row" valign="top"><label for="<?php echo self::META_KEY_BANNER_LOCATION; ?>"><?php _e('Banner location', 'wpdiscuz-ads-manager'); ?></label></th>
    <td>
        <select id="<?php echo self::META_KEY_BANNER_LOCATION; ?>" name="<?php echo self::META_KEY_BANNER_LOCATION; ?>">
            <?php
            foreach ($this->locations as $key => $value) {
                $selected = selected($wamLocation == $key);
                ?>
                <option value="<?php echo $key; ?>" <?php echo $selected; ?>><?php echo $value; ?></option>
                <?php
            }
            ?>            
        </select>
    </td>
</tr>