<?php
if (!defined('ABSPATH')) {
    exit();
}
wp_nonce_field(WAM_BASENAME_FILE, self::META_NONCE_BANNER_LOCATION);
?>
<div class="form-field wam-meta-location-wrapper">
    <div>
        <label for="<?php echo self::META_KEY_BANNER_LOCATION; ?>"><?php _e('Banner location', 'wpdiscuz-ads-manager'); ?></label>
        <select id="<?php echo self::META_KEY_BANNER_LOCATION; ?>" name="<?php echo self::META_KEY_BANNER_LOCATION; ?>">
            <?php
            foreach ($this->locations as $key => $value) {
                ?>
                <option value="<?php echo $key; ?>"><?php echo $value; ?></option>
                <?php
            }
            ?>            
        </select>
        <p class="description"><?php _e('Choose a value for this field', 'wpdiscuz-ads-manager'); ?></p>
    </div>
</div>