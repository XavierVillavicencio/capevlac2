<?php

if (!defined("ABSPATH")) {
    exit();
}

class WAMTaxonomy implements WAMConstants {

    private $dbManager;
    private $capabilities;
    public $locations;

    public function __construct($dbManager) {
        $this->dbManager = $dbManager;
        $this->initCapabilites();
        $this->initLocations();
        add_action("delete_" . self::TAXONOMY_TYPE, [&$this, "deleteCache"], 10, 4);
        add_action("create_" . self::TAXONOMY_TYPE, [&$this, "saveMetas"], 10, 2);
    }

    public function taxTypeInit() {
        register_taxonomy(self::TAXONOMY_TYPE, self::POST_TYPE, $this->getTaxTypeArgs());
    }

    private function initCapabilites() {
        $this->capabilities = [
            "manage_terms" => self::CAP_MANAGE_BANNERS,
            "edit_terms" => self::CAP_EDIT_BANNERS,
            "delete_terms" => self::CAP_DELETE_BANNERS,
            "assign_terms" => self::CAP_ASSIGN_BANNERS
        ];
    }

    private function initLocations() {
        $this->locations = [
            "location_none" => __("Choose Location", "wpdiscuz-ads-manager"),
            self::LOCATION_LIST => __("Comments List", "wpdiscuz-ads-manager"),
            self::LOCATION_FORM_TOP => __("Comments Form Top", "wpdiscuz-ads-manager"),
            self::LOCATION_FORM_BOTTOM => __("Comments Form Bottom", "wpdiscuz-ads-manager"),
            self::LOCATION_BOX_TOP => __("Comments Box Top", "wpdiscuz-ads-manager"),
            self::LOCATION_BOX_BOTTOM => __("Comments Box Bottom", "wpdiscuz-ads-manager"),
        ];
    }

    public function addCaps() {
        $admins = get_role("administrator");
        $admins->add_cap(self::CAP_MANAGE_BANNERS);
        $admins->add_cap(self::CAP_EDIT_BANNERS);
        $admins->add_cap(self::CAP_DELETE_BANNERS);
        $admins->add_cap(self::CAP_ASSIGN_BANNERS);
    }

    private function getTaxTypeArgs() {
        $labels = [
            "name" => __("Banners", "wpdiscuz-ads-manager"),
            "singular_name" => __("Banner", "wpdiscuz-ads-manager"),
            "all_items" => __("All Banners", "wpdiscuz-ads-manager"),
            "edit_item" => __("Edit Banner", "wpdiscuz-ads-manager"),
            "view_item" => __("View Banner", "wpdiscuz-ads-manager"),
            "update_item" => __("Update Banner", "wpdiscuz-ads-manager"),
            "add_new_item" => __("Add New Banner", "wpdiscuz-ads-manager"),
            "new_item_name" => __("New Banner Name", "wpdiscuz-ads-manager"),
            "parent_item" => null,
            "parent_item_colon" => null,
            "search_items" => __("Search Banners", "wpdiscuz-ads-manager"),
            "popular_items" => __("Popular Banners", "wpdiscuz-ads-manager"),
            "separate_items_with_commas" => __("Separate banners with commas", "wpdiscuz-ads-manager"),
            "add_or_remove_items" => __("Add or remove banners", "wpdiscuz-ads-manager"),
            "choose_from_most_used" => __("Choose from the most used banners", "wpdiscuz-ads-manager"),
            "not_found" => __("No banners found.", "wpdiscuz-ads-manager"),
            "menu_name" => __("Banners", "wpdiscuz-ads-manager"),
        ];

        $args = [
            "public" => false,
            "show_ui" => true,
            "show_in_menu" => true,
            "show_in_nav_menus" => false,
            "show_tagcloud" => false,
            "show_in_quick_edit" => true,
            "show_admin_column" => true,
            "hierarchical" => false,
            "query_var" => true,
            "labels" => $labels,
            "update_count_callback" => "_update_post_term_count",
            "capabilities" => $this->capabilities,
        ];

        return $args;
    }

    public function wamTaxonomyAddFields() {
        include_once WAM_DIR_PATH . "/includes/metas/taxonomy/meta-add-location.php";
        include_once WAM_DIR_PATH . "/includes/metas/taxonomy/meta-add-count.php";
    }

    public function wamTaxonomyEditFields($term) {
        include_once WAM_DIR_PATH . "/includes/metas/taxonomy/meta-edit-location.php";
        include_once WAM_DIR_PATH . "/includes/metas/taxonomy/meta-edit-count.php";
    }

    public function wamTaxonomySaveFields($term_id) {
        $isValidLocationNonce = (isset($_POST[self::META_NONCE_BANNER_LOCATION]) && wp_verify_nonce($_POST[self::META_NONCE_BANNER_LOCATION], WAM_BASENAME_FILE)) ? true : false;
        $isValidAdRepeatsNonce = (isset($_POST[self::META_NONCE_BANNER_REPEATS]) && wp_verify_nonce($_POST[self::META_NONCE_BANNER_REPEATS], WAM_BASENAME_FILE)) ? true : false;

        if ($isValidLocationNonce && $isValidAdRepeatsNonce) {

            if (isset($_POST[self::META_KEY_BANNER_LOCATION]) && ($bannerLocation = trim($_POST[self::META_KEY_BANNER_LOCATION]))) {
                update_term_meta($term_id, self::META_KEY_BANNER_LOCATION, $bannerLocation);
            }

            if (isset($_POST[self::META_KEY_BANNER_REPEATS])) {
                $bannerRepeats = (($c = absint($_POST[self::META_KEY_BANNER_REPEATS])) > 0) ? $c : 3;
                update_term_meta($term_id, self::META_KEY_BANNER_REPEATS, $bannerRepeats);
            }
        }
        delete_transient(self::TRANSIENT_WAM_BANNERS);
    }

    public function wamBannerColumns($columns) {
        if (is_array($columns)) {
            $columns["wam_banner_location"] = __("Location", "wpdiscuz-ads-manager");
        }
        return $columns;
    }

    public function wamBannerCustomColumn($output, $column, $term_id) {
        if ("wam_banner_location" === $column) {
            $location = get_term_meta($term_id, self::META_KEY_BANNER_LOCATION, true);
            print $location ? $this->locations[$location] : "";
        }
    }

    public function deleteCache($termId, $termTaxonomyId, $deletedTerm, $objectIds) {
        delete_transient(self::TRANSIENT_WAM_BANNERS);
    }

    public function saveMetas($term_id, $tt_id) {
        $term = get_term($term_id, self::TAXONOMY_TYPE);

        if ($term) {

            if (!get_term_meta($term_id, self::META_KEY_BANNER_LOCATION, true)) {
                update_term_meta($term_id, self::META_KEY_BANNER_LOCATION, self::LOCATION_FORM_TOP);
            }
            
            if (!get_term_meta($term_id, self::META_KEY_BANNER_REPEATS, true)) {
                update_term_meta($term_id, self::META_KEY_BANNER_REPEATS, 3);
            }
        }
    }

}
