<?php

if (!defined("ABSPATH")) {
    exit();
}

class WAMDBManager implements WAMConstants {

    private $db;
    private $prefix;

    public function __construct() {
        global $wpdb;
        $this->db = $wpdb;
        $this->prefix = $wpdb->prefix;
    }

    public function getLocations() {
        $sql = "SELECT `meta_value` FROM `" . $this->prefix . "termmeta` WHERE `meta_key` LIKE '" . self::META_KEY_BANNER_LOCATION . "' AND `meta_value` NOT LIKE 'location_none' GROUP BY `meta_value`;";
        $data = $this->db->get_results($sql, ARRAY_N);
        return $this->matrixToArray($data);
    }

    public function getBanners($time) {
        $sql = "SELECT `t`.`term_id` AS `term_id`, `tt`.`term_taxonomy_id` AS `term_taxonomy_id`, `t`.`slug` AS `slug`, `t`.`name` AS `name`, `tt`.`description` AS `description`, `tt`.`term_taxonomy_id` AS `term_taxonomy_id`, `tm`.`meta_value` AS `location_value`, `tm1`.`meta_value` AS `repeats_value` FROM `" . $this->prefix . "terms` AS `t` INNER JOIN `" . $this->prefix . "term_taxonomy` AS `tt` ON `t`.`term_id` = `tt`.`term_id` INNER JOIN `" . $this->prefix . "termmeta` AS `tm` ON `t`.`term_id` = `tm`.`term_id` INNER JOIN `" . $this->prefix . "termmeta` AS `tm1` ON `t`.`term_id` = `tm1`.`term_id` WHERE `tt`.`taxonomy` = '" . self::TAXONOMY_TYPE . "' AND `tt`.`count` > 0 AND `tm`.`meta_key` LIKE '" . self::META_KEY_BANNER_LOCATION . "' AND `tm`.`meta_value` NOT LIKE 'location_none' AND `tm1`.`meta_key` LIKE '" . self::META_KEY_BANNER_REPEATS . "';";
        if ($time && (($data = get_transient(self::TRANSIENT_WAM_BANNERS)) === false)) {
            $data = $this->db->get_results($sql, ARRAY_A);
            set_transient(self::TRANSIENT_WAM_BANNERS, $data, absint($time));
        } else {
            $data = $this->db->get_results($sql, ARRAY_A);
        }
        return $data;
    }

    public function getAds($time, $banner, $now, $postType, $roles, $postId) {
        $rolesClause = "";
        if ($roles && is_array($roles)) {
            $rolesClause .= "AND (`mt4`.`meta_key` = '" . self::META_KEY_AD_HIDE_FOR_ROLES . "'";
            for ($i = 0; $i < count($roles); $i++) {
                $role = isset($roles[$i]) ? $roles[$i] : "";
                $rolesClause .= ($i == 0) ? " AND (NOT FIND_IN_SET('$role', `mt4`.`meta_value`)" : " AND NOT FIND_IN_SET('$role', `mt4`.`meta_value`)";
            }
            $rolesClause .= "))";
        }
        $endCondition = "AND (`mt2`.`meta_key` = '" . self::META_KEY_AD_DATE_END . "' AND (`mt2`.`meta_value` IS NULL OR `mt2`.`meta_value` = '' OR `mt2`.`meta_value` > '$now'))";
        $sql = "SELECT `p`.* FROM `" . $this->prefix . "posts` AS `p`, `" . $this->prefix . "term_relationships` AS `tr`, `" . $this->prefix . "postmeta` AS `mt1`, `" . $this->prefix . "postmeta` AS `mt2`, `" . $this->prefix . "postmeta` AS `mt3`, `" . $this->prefix . "postmeta` AS `mt4`, `" . $this->prefix . "postmeta` AS `mt5` WHERE ((`mt1`.`meta_key` = '" . self::META_KEY_AD_DATE_START . "' AND `mt1`.`meta_value` <= '$now') $endCondition AND (`mt3`.`meta_key` = '" . self::META_KEY_AD_POST_TYPES . "' AND FIND_IN_SET('$postType', `mt3`.`meta_value`)) $rolesClause AND (`mt5`.`meta_key` = '" . self::META_KEY_AD_EXCLUDE_POSTS . "' AND NOT FIND_IN_SET('$postId', `mt5`.`meta_value`))) AND `p`.`ID` = `tr`.`object_id` AND `p`.ID = `mt1`.`post_id` AND `p`.ID = `mt2`.`post_id` AND `p`.ID = `mt3`.`post_id` AND `p`.ID = `mt4`.`post_id` AND `p`.ID = `mt5`.`post_id` AND `tr`.`term_taxonomy_id` = $banner AND `p`.`post_type` = '" . self::POST_TYPE . "' AND `p`.`post_status` = 'publish' GROUP BY `p`.`ID` ORDER BY `p`.`post_date` DESC;";
        if ($time && (($data = get_transient(self::TRANSIENT_WAM_ADS)) === false)) {
            $data = $this->db->get_results($sql);
            set_transient(self::TRANSIENT_WAM_ADS, $data, absint($time));
        } else {
            $data = $this->db->get_results($sql);
        }
        return $data;
    }

    private function matrixToArray($data) {
        $res = [];
        foreach ($data as $d) {
            $res[] = $d[0];
        }
        return $res;
    }

}
