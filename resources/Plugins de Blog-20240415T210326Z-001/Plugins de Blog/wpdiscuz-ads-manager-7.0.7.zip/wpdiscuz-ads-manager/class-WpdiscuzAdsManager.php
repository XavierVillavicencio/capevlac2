<?php

/*
 * Plugin Name: wpDiscuz - Ads Manager
 * Description: A full-fledged tool-kit for advertising in comment section of your website. Separate banner and ad managment options. 
 * Version: 7.0.7
 * Author: gVectors Team
 * Author URI: https://www.gvectors.com/
 * Plugin URI: https://gvectors.com/product/wpdiscuz-ads-manager/
 * Text Domain: wpdiscuz-ads-manager
 * Domain Path: /languages/
 */
if (!defined("ABSPATH")) {
    exit();
}

define("WAM_DIR_PATH", dirname(__FILE__));
define("WAM_DIR_NAME", basename(WAM_DIR_PATH));
define("WAM_BASENAME_FILE", basename(__FILE__));

include_once WAM_DIR_PATH . "/utils/interface-WamConstants.php";
include_once WAM_DIR_PATH . "/options/class-WamOptions.php";
include_once WAM_DIR_PATH . "/includes/class-WamDBManager.php";
include_once WAM_DIR_PATH . "/includes/class-WamPost.php";
include_once WAM_DIR_PATH . "/includes/class-WamTaxonomy.php";
include_once WAM_DIR_PATH . "/includes/gvt-api-manager.php";

class WpdiscuzAdsManager implements WAMConstants {

    private $version;
    private $dbManager;
    private $options;
    private $wamPost;
    private $wamTaxonomy;
    private $adsMenuTitle;
    private $bannersMenuTitle;
    public static $WAM_ADS_URL;
    public static $WAM_BANNERS_URL;
    private $banners;
    private $ads;
    private $commentCount = 0;
	public $apimanager;

    public function __construct() {
        $this->dbManager = new WAMDBManager();
        $this->options = new WAMOptions($this->dbManager);
        $this->wamPost = new WAMPost($this->dbManager);
        $this->wamTaxonomy = new WAMTaxonomy($this->dbManager);

        register_activation_hook(__FILE__, [&$this, "rewriteRulesFlush"]);
        add_action("admin_notices", [$this, "wamRequirements"], 1);
        add_action("plugins_loaded", [$this, "wamDependencies"], 1);
    }

    public function rewriteRulesFlush() {
        $this->wamPost->postTypeInit();
        $this->wamTaxonomy->taxTypeInit();
        if (!get_option(self::OPTION_DUMMY_DATA)) {
            update_option(self::OPTION_DUMMY_DATA, 1);
            $postArgs = [
                "post_title" => "Ad Example",
                "post_name" => "wam-simple-ad-1",
                "post_content" => "<img class='alignnone size-full wp-image-60' src='" . plugins_url(WAM_DIR_NAME . "/assets/img/simple-ad.png") . "' alt='simple-ad' width='633' height='126' /><p style='font-size: 12px; line-height: 15px; color: #666; max-width: 620px; padding-top: 1px;'>This is a demo advert, you can use simple text, HTML image or any Ad Service JavaScript code. If you're inserting HTML or JS code make sure editor is switched to 'Text' mode.</p>",
                "post_status" => "publish",
                "comment_status" => "closed",
                "ping_status" => "closed",
                "post_type" => self::POST_TYPE
            ];

            if ($postId = wp_insert_post($postArgs)) {
                add_post_meta($postId, self::META_KEY_AD_POST_TYPES, "post,page");
                add_post_meta($postId, self::META_KEY_AD_HIDE_FOR_ROLES, "");
                add_post_meta($postId, self::META_KEY_AD_EXCLUDE_POSTS, "");
                add_post_meta($postId, self::META_KEY_AD_DATE_START, date("Y-m-d", current_time("timestamp")));
                add_post_meta($postId, self::META_KEY_AD_DATE_END, "");
            }

            $taxArgs = [
                "description" => "This is the place and location for displaying ads.",
                "slug" => "wam-simple-banner-1"
            ];

            $termData = wp_insert_term("Simple Banner - Comments Form Top", self::TAXONOMY_TYPE, $taxArgs);

            if (!is_wp_error($termData)) {
                add_term_meta($termData["term_id"], self::META_KEY_BANNER_LOCATION, self::LOCATION_FORM_TOP);
                add_term_meta($termData["term_id"], self::META_KEY_BANNER_REPEATS, 3);
            }

            if ($postId) {
                if (is_wp_error($termData)) {
                    $termId = isset($termData->error_data["term_exists"]) ? $termData->error_data["term_exists"] : 0;
                } else {
                    $termId = $termData["term_id"];
                }
                wp_set_post_terms($postId, [$termId], self::TAXONOMY_TYPE, true);
            }
        }
        flush_rewrite_rules();
    }

    public function wamRequirements() {
        if (current_user_can("manage_options")) {
            global $wp_version;
            if (!function_exists("wpDiscuz")) {
                echo "<div class='error'><p>" . __("wpDiscuz - Ads Manager requires wpDiscuz to be installed!", "wpdiscuz-ads-manager") . "</p></div>";
            }

            if (version_compare($wp_version, "4.4", "<")) {
                echo "<div class='error'><p>" . __("wpDiscuz - Ads Manager requires Wordpress version >= 4.4!", "wpdiscuz-ads-manager") . "</p></div>";
            }
        }
    }

    public function wamDependencies() {
        if (function_exists("wpDiscuz")) {
            $this->version = get_option(self::OPTION_VERSION);
            if (!$this->version) {
                $this->version = "1.0.0";
                update_option(self::OPTION_VERSION, $this->version);
            }
	        $this->apimanager = new GVT_API_Manager(__FILE__, "wpdiscuz_options_page", "wpdiscuz_option_page");
            $this->adsMenuTitle = __("&raquo; Ad Manager", "wpdiscuz-ads-manager");
            $this->bannersMenuTitle = __("&raquo; Ad Banners", "wpdiscuz-ads-manager");
            self::$WAM_ADS_URL = get_admin_url() . "edit.php?post_type=" . self::POST_TYPE;
            self::$WAM_BANNERS_URL = get_admin_url() . "edit-tags.php?taxonomy=" . self::TAXONOMY_TYPE . "&post_type=" . self::POST_TYPE;

            load_plugin_textdomain("wpdiscuz-ads-manager", false, WAM_DIR_NAME . "/languages/");
            add_action("admin_enqueue_scripts", [&$this, "optionsFiles"]);
            add_action("wpdiscuz_front_scripts", [&$this, "frontendFiles"]);
            add_action("admin_menu", [&$this, "addAdsMenu"], 999);
            add_action("wpdiscuz_check_version", [&$this, "version"]);

            add_filter("wpdiscuz_settings", [&$this->options, "settingsArray"], 10);
            add_action("wpdiscuz_save_options", [&$this->options, "saveOptions"]);
            add_action("wpdiscuz_reset_options", [&$this->options, "resetOptions"]);
            add_action("admin_post_wamResetCache", [&$this->options, "resetCache"]);

            // wpDiscuz ad hooks
            add_action("init", [&$this->wamPost, "postTypeInit"], 10);
            add_action("admin_init", [&$this->wamPost, "addCaps"]);
            add_action("add_meta_boxes", [&$this->wamPost, "addMetaBoxes"]);
            add_action("save_post", [&$this->wamPost, "wamSaveMeta"], 10, 2);
            add_filter("manage_" . self::POST_TYPE . "_posts_columns", [&$this->wamPost, "wamAdColumns"]);
            add_action("manage_" . self::POST_TYPE . "_posts_custom_column", [&$this->wamPost, "wamAdCustomColumn"], 10, 2);
            add_action("restrict_manage_posts", [&$this->wamPost, "restrictAds"]);

            // wpDiscuz ad banners hooks
            add_action("init", [&$this->wamTaxonomy, "taxTypeInit"], 20);
            add_action("admin_init", [&$this->wamTaxonomy, "addCaps"]);
            add_action(self::TAXONOMY_TYPE . "_add_form_fields", [&$this->wamTaxonomy, "wamTaxonomyAddFields"], 10, 2);
            add_action(self::TAXONOMY_TYPE . "_edit_form_fields", [&$this->wamTaxonomy, "wamTaxonomyEditFields"], 10, 2);
            add_action("edited_" . self::TAXONOMY_TYPE, [&$this->wamTaxonomy, "wamTaxonomySaveFields"], 10, 2);
            add_action("create_" . self::TAXONOMY_TYPE, [&$this->wamTaxonomy, "wamTaxonomySaveFields"], 10, 2);
            add_filter("manage_edit-" . self::TAXONOMY_TYPE . "_columns", [&$this->wamTaxonomy, "wamBannerColumns"]);
            add_filter("manage_" . self::TAXONOMY_TYPE . "_custom_column", [&$this->wamTaxonomy, "wamBannerCustomColumn"], 10, 3);

            add_action("wpdiscuz_before_load", [&$this, "wamVariables"], 10, 2);
            add_action("wpdiscuz_before_getcomments", [&$this, "wamVariables"], 10, 3);
        }
    }

    public function addActions() {
        // ad actions
        if ($this->ads && is_array($this->ads)) {
            if (isset($this->ads[self::LOCATION_FORM_TOP]) && $this->ads[self::LOCATION_FORM_TOP] && is_array($this->ads[self::LOCATION_FORM_TOP])) {
                add_action("wpdiscuz_comment_form_top", [&$this, "wamFormTop"], 10, 3);
                add_action("wpdiscuz_comment_form_closed", [&$this, "wamFormTop"], 10, 3);
            }
            if (isset($this->ads[self::LOCATION_FORM_BOTTOM]) && $this->ads[self::LOCATION_FORM_BOTTOM] && is_array($this->ads[self::LOCATION_FORM_BOTTOM])) {
                add_action("wpdiscuz_comment_form_after", [&$this, "wamFormBottom"], 10, 3);
            }
            if (isset($this->ads[self::LOCATION_BOX_TOP]) && $this->ads[self::LOCATION_BOX_TOP] && is_array($this->ads[self::LOCATION_BOX_TOP])) {
                add_action("wpdiscuz_before_comments", [&$this, "wamBoxTop"], 10, 3);
            }
            if (isset($this->ads[self::LOCATION_BOX_BOTTOM]) && $this->ads[self::LOCATION_BOX_BOTTOM] && is_array($this->ads[self::LOCATION_BOX_BOTTOM])) {
                add_action("wpdiscuz_after_comments", [&$this, "wamBoxBottom"], 10, 3);
            }
            if (isset($this->ads[self::LOCATION_LIST]) && $this->ads[self::LOCATION_LIST] && is_array($this->ads[self::LOCATION_LIST])) {
                if ($this->options->wamIsDisplayOnReplies) {
                    add_filter("wpdiscuz_comment_end", [&$this, "wamAddCommentBanner"], 10, 4);
                } else {
                    add_filter("wpdiscuz_thread_end", [&$this, "wamAddThreadBanner"], 10, 4);
                }
            }
        }
    }

    public function optionsFiles() {
        global $typenow;
        if ((isset($_GET["page"]) && isset($_GET["wpd_tab"]) && $_GET["page"] === WpdiscuzCore::PAGE_SETTINGS && $_GET["wpd_tab"] === $this->options->tabKey) || ($typenow == self::POST_TYPE)) {
            $vars = [];
            $vars["wamAdsMenuTitle"] = $this->adsMenuTitle;
            $vars["wamBannersMenuTitle"] = $this->bannersMenuTitle;
            $vars["wamAdsUrl"] = "?post_type=" . self::POST_TYPE;
            $vars["wamBannersUrl"] = "?taxonomy=" . self::TAXONOMY_TYPE;
            $vars["wamPostType"] = 0;
            $vars["wamStatusEnded"] = __("The end date of this ad is reached, please specify new end date.", "wpdiscuz-ads-manager");
            $vars["wamConfirm"] = __("Are you sure?", "wpdiscuz-ads-manager");
            $vars["wamLocationList"] = self::LOCATION_LIST;

            if (self::POST_TYPE == get_post_type()) {
                wp_deregister_script("autosave");
                $vars["wamPostType"] = 1;
            }

            wp_enqueue_script("jquery-ui-datepicker");
            wp_enqueue_style("jquery-ui-theme-options", plugins_url(WAM_DIR_NAME . "/assets/third-party/jquery-ui-themes/smoothness/jquery-ui.min.css"), null, $this->version);
            wp_enqueue_style("wam-options-css", plugins_url(WAM_DIR_NAME . "/assets/css/options.css"), null, $this->version);
            wp_enqueue_script("wam-options-js", plugins_url(WAM_DIR_NAME . "/assets/js/options.js"), ["jquery"], $this->version, false);
            wp_localize_script("wam-options-js", "wamDashVars", $vars);
        }
    }

    public function frontendFiles() {
        wp_register_style("wam-frontend-css", plugins_url(WAM_DIR_NAME . "/assets/css/frontend.css"), null, $this->version);
        wp_enqueue_style("wam-frontend-css");
    }

    public function version() {
        $pluginData = get_plugin_data(__FILE__);
        if (version_compare($pluginData["Version"], $this->version, ">")) {
            $options = get_option(self::OPTION_MAIN_OPTIONS);
            $this->addNewOptions($options);
            update_option(self::OPTION_VERSION, $pluginData["Version"]);
        }
    }

    /**
     * merge old and new options
     */
    private function addNewOptions($options) {
        $this->options->initOptions($options);
        $newOptions = $this->options->toArray();
        update_option(self::OPTION_MAIN_OPTIONS, $newOptions);
    }

    public function addAdsMenu() {
        global $submenu;
        if (!empty($submenu["wpdiscuz"])) {
            $submenu["wpdiscuz"]["wamAds"] = [$this->adsMenuTitle, "manage_options", self::$WAM_ADS_URL];
            $submenu["wpdiscuz"]["wamBanners"] = [$this->bannersMenuTitle, "manage_options", self::$WAM_BANNERS_URL];
        }
    }

    private function initBanners($time) {
        $this->banners = $this->dbManager->getBanners($time);
    }

    private function initAds($time, $args = null, $u = null) {
        global $post, $user_ID;
        $currentUser = get_userdata($user_ID);
        $p = ($args && !is_null($args) && is_array($args) && isset($args["post_id"]) && ($postId = intval($args["post_id"]))) ? get_post($postId) : $post;
        $u = $currentUser && $currentUser->ID ? $currentUser : $u;
        $this->_initAds($time, $p, $u);
    }

    private function _initAds($time, $post, $user) {
        if ($this->banners && is_array($this->banners) && ($post && $post->ID)) {
            $now = date("Y-m-d", current_time("timestamp"));
            $userRoles = ($user && isset($user->roles)) ? $user->roles : false;
            foreach ($this->banners as $k => $c) {
                $location = $c["location_value"];
                $repeats = $c["repeats_value"];
                $posts = $this->dbManager->getAds($time, $c["term_taxonomy_id"], $now, $post->post_type, $userRoles, $post->ID);
                if (isset($this->ads[$location]) && isset($this->ads[$location][$repeats])) {
                    $this->ads[$location][$repeats] = array_merge($this->ads[$location][$repeats], $posts);
                } else {
                    if ($location == self::LOCATION_LIST) {
                        $this->ads[$location][$repeats] = $posts;
                    } else {
                        $this->ads[$location] = $posts;
                        //$this->ads[$location][$c["term_id"]] = get_posts($args);
                    }
                }
            }
            if (isset($this->ads[self::LOCATION_LIST])) {
                ksort($this->ads[self::LOCATION_LIST], SORT_NUMERIC);
            }
        }
    }

    public function wamVariables($commentsArgs, $currentUser, $args = null) {
        $time = $this->options->wamIsCachingDisabled ? 0 : $this->options->wamCacheExpireTime;
        if (!$this->banners) {
            $this->initBanners($time);
        }
        if (!$this->ads) {
            $this->initAds($time, $commentsArgs, $currentUser);
        }
        $this->addActions();
    }

    public function wamFormTop($post, $currentUser, $commentsCount) {
        $this->wamAddBanner(self::LOCATION_FORM_TOP, $post, $currentUser, $commentsCount);
    }

    public function wamFormBottom($post, $currentUser, $commentsCount) {
        $this->wamAddBanner(self::LOCATION_FORM_BOTTOM, $post, $currentUser, $commentsCount);
    }

    public function wamBoxTop($post, $currentUser, $commentsCount) {
        $this->wamAddBanner(self::LOCATION_BOX_TOP, $post, $currentUser, $commentsCount);
    }

    public function wamBoxBottom($post, $currentUser, $commentsCount) {
        $this->wamAddBanner(self::LOCATION_BOX_BOTTOM, $post, $currentUser, $commentsCount);
    }

    private function wamAddBanner($location, $post, $currentUser, $commentsCount) {
        $index = $this->getRandomAd($this->ads[$location]);
        $ad = $this->ads[$location][$index];
        $adId = $ad->ID;
        $adContent = do_shortcode($ad->post_content);
        $output = "<div class='wam-banner wam-banner-$location wam-ad-$adId'>$adContent</div>";
        echo $output;
    }

    public function wamAddCommentBanner($output, $comment, $depth, $args) {
        $this->commentCount++;
        return $this->attachAd($output, $comment, $this->commentCount);
    }

    public function wamAddThreadBanner($output, $comment, $depth, $args) {
        if (!$comment->comment_parent) {
            $this->commentCount++;
            $output = $this->attachAd($output, $comment, $this->commentCount);
        }
        return $output;
    }

    private function attachAd($output, $comment, $commentCount) {
        foreach ($this->ads[self::LOCATION_LIST] as $k => $v) {
            if ($commentCount > 0 && ($commentCount % $k == 0) && $v && is_array($v)) {
                $index = $this->getRandomAd($v);
                $ad = isset($v[$index]) ? $v[$index] : null;
                if ($ad && isset($ad->ID)) {
                    $adId = $ad->ID;
                    $adContent = do_shortcode($ad->post_content);
                    $output .= "<div class='wam-banner wam-banner-" . self::LOCATION_LIST . "wam-banner-$k wam-ad-$adId'>$adContent</div>";
                }
            }
        }
        return $output;
    }

    public function getRandomAd($ads) {
        if (count($ads) == 1) {
            return 0;
        } else {
            return array_rand($ads, 1);
        }
    }

}

$wpdiscuzAM = new WpdiscuzAdsManager();
