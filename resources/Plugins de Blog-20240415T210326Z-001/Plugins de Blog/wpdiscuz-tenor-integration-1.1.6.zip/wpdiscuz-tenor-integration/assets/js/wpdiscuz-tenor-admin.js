/* global jQuery */
jQuery(document).ready(function ($) {
    $(document).on('click', '.wpdiscuz-tenor-preview-gif', function () {
        var el = $(this);
        el.find('.wpdiscuz-tenor-embedded-gif').prop('src', 'https://c.tenor.com/' + el.attr('data-full'));
        el.removeClass('wpdiscuz-tenor-preview-gif').addClass('wpdiscuz-tenor-full-gif');
    });

    $(document).on('click', '.wpdiscuz-tenor-full-gif', function () {
        var el = $(this);
        el.find('.wpdiscuz-tenor-embedded-gif').prop('src', 'https://c.tenor.com/' + el.attr('data-preview'));
        el.removeClass('wpdiscuz-tenor-full-gif').addClass('wpdiscuz-tenor-preview-gif');
    });
});