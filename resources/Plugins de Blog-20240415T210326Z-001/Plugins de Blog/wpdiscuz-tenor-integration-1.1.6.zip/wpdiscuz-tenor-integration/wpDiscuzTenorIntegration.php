<?php
/*
 * Plugin Name: wpDiscuz - Tenor GIFs Integration
 * Description: Adds gif animation to comments powered by Tenor GIF (tenor.com)
 * Version: 1.1.6
 * Author: gVectors Team
 * Author URI: https://www.gvectors.com/
 * Plugin URI: https://www.gvectors.com/wpdiscuz-tenor-integration/
 * Text Domain: wpdiscuz-tenor-integration
 * Domain Path: /languages/
 */
if (!defined("ABSPATH")) {
    exit();
}

define("WPD_TI_PATH", __DIR__);
define("WPD_TI_DIR_NAME", basename(WPD_TI_PATH));

include_once WPD_TI_PATH . "/includes/gvt-api-manager.php";
include WPD_TI_PATH . "/includes/wpDiscuzTIConstants.php";
include WPD_TI_PATH . "/options/wpDiscuzTIOptions.php";

class wpDiscuzTenorIntegration implements wpDiscuzTIConstants {

    private static $instance;
    private $version;
    private $options;
    private static $tenorPattern = '@\[(\[?)(wpd\-tenor)(?![\w-])([^\]\/]*(?:\/(?!\])[^\]\/]*)*?)(?:(\/)\]|\](?:([^\[]*+(?:\[(?!\/\2\])[^\[]*+)*+)\[\/\2\])?)(\]?)@isu';
    private static $attsPattern = '@([\w-]+)\s*=\s*\'([^\']*)\'(?:\s|$)|([\w-]+)\s*=\s*\'([^\']*)\'(?:\s|$)|([\w-]+)\s*=\s*([^\s\']+)(?:\s|$)|\'([^\']*)\'(?:\s|$)|\'([^\']*)\'(?:\s|$)|(\S+)(?:\s|$)@isu';
    public $apimanager;

    private function __construct() {
        add_action("plugins_loaded", [&$this, "pluginsLoaded"], 900);
    }

    public static function getInstance() {
        if (is_null(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function pluginsLoaded() {
        if (function_exists("wpDiscuz")) {
            $this->version = get_option(self::OPTION_VERSION, "1.0.0");
            $this->apimanager = new GVT_API_Manager(__FILE__, "wpdiscuz_options_page", "wpdiscuz_option_page");
            $this->options = new wpDiscuzTIOptions();
            load_plugin_textdomain("wpdiscuz-tenor-integration", false, dirname(plugin_basename(__FILE__)) . "/languages/");
            add_filter("comment_text", [$this, "displayGIFs"], 900, 3);
            add_filter("wpforo_content", [$this, "displayGIFsInPost"], 900);
            add_filter("wpforo_strip_shortcodes", [$this, "stripShortcodes"], 900);
            add_filter("get_comment_excerpt", [$this, "excerpDisplayGIFs"], 900, 3);
            $wpdiscuz = wpDiscuz();
            if ($wpdiscuz->options->form["richEditor"] === "both" || (!wp_is_mobile() && $wpdiscuz->options->form["richEditor"] === "desktop")) {
                add_filter("wpdiscuz_editor_buttons", [$this, "editorButtons"]);
            } else {
                add_filter("wpdiscuz_editor_buttons_html", [$this, "editorButtonsHtml"]);
            }
            add_action("wp_footer", [$this, "printPopup"]);
            add_action("wpdiscuz_front_scripts", [$this, "enqueueScripts"]);
            add_action("admin_enqueue_scripts", [$this, "enqueueAdminScripts"]);
            add_action("wpforo_frontend_enqueue_scripts", [$this, "enqueueWpForoScripts"]);
            add_action("admin_init", [$this, "pluginNewVersion"], 900);
        } else {
            add_action("admin_notices", [$this, "requirements"], 900);
        }
    }

    public function displayGIFs($content, $comment, $args = []) {
        if (!empty($args["is_wpdiscuz_comment"]) || is_admin()) {
            if (preg_match_all(self::$tenorPattern, $content, $matches, PREG_SET_ORDER)) {
                foreach ($matches as $key => $match) {
                    $match[3] = str_replace(["&#8217;", "&#8242;", "’", "′"], "'", $match[3]);
                    if (preg_match_all(self::$attsPattern, $match[3], $atts, PREG_SET_ORDER)) {
                        $tenorURL = 'https://media.tenor.com/';
                        if (preg_match('@/tenor\.gif$@is', $atts[0][2])) {
                            $tenorURL = 'https://media.tenor.com/images/';
                        } elseif (strpos($atts[0][2], 'https://') !== false) {
                            $tenorURL = '';
                        }
                        $gif = "<div class='wpdiscuz-tenor-embedded-gif-wrapper " . ($this->options->playOnLoad ? "wpdiscuz-tenor-full-gif" : "wpdiscuz-tenor-preview-gif") . "' data-full='" . $atts[0][2] . "' data-preview='" . $atts[1][2] . "' style='width:auto;height:auto;'>";
                        $gif .= "<div class='wpdiscuz-tenor-embedded-gif-button'><img src='" . plugins_url(WPD_TI_DIR_NAME . "/assets/img/gif.png") . "'></div>";
                        $gif .= "<div class='wpdiscuz-tenor-powered-by'><img src='" . plugins_url(WPD_TI_DIR_NAME . "/assets/img/viaTenor.png") . "' style='max-width: 100% !important;'></div>";
                        $gif .= "<img class='wpdiscuz-tenor-embedded-gif' width='" . $atts[2][2] . "' height='" . $atts[3][2] . "' src='" . $tenorURL . ($this->options->playOnLoad ? $atts[0][2] : $atts[1][2]) . "' style='width:auto;height:auto;max-width:100%;'>";
                        $gif .= "</div>";
                        $content = str_replace($match[0], $gif, $content);
                    }
                }
            }
        }
        return $content;
    }

    public function displayGIFsInPost($content) {
            if (preg_match_all(self::$tenorPattern, $content, $matches, PREG_SET_ORDER)) {
                foreach ($matches as $key => $match) {
                    $match[3] = str_replace(["&#8217;", "&#8242;", "’", "′"], "'", $match[3]);
                    if (preg_match_all(self::$attsPattern, $match[3], $atts, PREG_SET_ORDER)) {
                        $tenorURL = 'https://media.tenor.com/';
                        if (preg_match('@/tenor\.gif$@is', $atts[0][2])) {
                            $tenorURL = 'https://media.tenor.com/images/';
                        } elseif (strpos($atts[0][2], 'https://') !== false) {
                            $tenorURL = '';
                        }
                        $gif = "<div class='wpdiscuz-tenor-embedded-gif-wrapper " . ($this->options->playOnLoad ? "wpdiscuz-tenor-full-gif" : "wpdiscuz-tenor-preview-gif") . "' data-full='" . $atts[0][2] . "' data-preview='" . $atts[1][2] . "' style='width:auto;height:auto;'>";
                        $gif .= "<img class='wpdiscuz-tenor-embedded-gif' width='" . $atts[2][2] . "' height='" . $atts[3][2] . "' src='" . $tenorURL . $atts[0][2] . "' style='width:auto;height:auto;max-width:100%;'>";
                        $gif .= "</div>";
                        $content = str_replace($match[0], $gif, $content);
                    }
                }
            }
        return $content;
    }

    public function stripShortcodes($text){
        return preg_replace( '#\[wpd-tenor[^\[\]]+?]#iu', '', $text );
    }
    
    public function excerpDisplayGIFs($excerpt, $commentID, $comment) {
        if (preg_match_all(self::$tenorPattern, $excerpt, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $key => $match) {
                $match[3] = str_replace(["&#8217;", "&#8242;", "’", "′"], "'", $match[3]);
                if (preg_match_all(self::$attsPattern, $match[3], $atts, PREG_SET_ORDER)) {
                    $tenorURL = 'https://media.tenor.com/';
                    if (preg_match('@/tenor\.gif$@is', $atts[0][2])) {
                        $tenorURL = 'https://media.tenor.com/images/';
                    } elseif (strpos($atts[0][2], 'https://') !== false) {
                        $tenorURL = '';
                    }
                    $gif = "<div class='wpdiscuz-tenor-embedded-gif-wrapper " . ($this->options->playOnLoad ? "wpdiscuz-tenor-full-gif" : "wpdiscuz-tenor-preview-gif") . "' data-full='" . $atts[0][2] . "' data-preview='" . $atts[1][2] . "' style='width:auto;height:auto;'>";
                    $gif .= "<div class='wpdiscuz-tenor-embedded-gif-button'><img src='" . plugins_url(WPD_TI_DIR_NAME . "/assets/img/gif.png") . "'></div>";
                    $gif .= "<div class='wpdiscuz-tenor-powered-by'><img src='" . plugins_url(WPD_TI_DIR_NAME . "/assets/img/viaTenor.png") . "' style='max-width: 100% !important;'></div>";
                    $gif .= "<img class='wpdiscuz-tenor-embedded-gif' width='" . $atts[2][2] . "' height='" . $atts[3][2] . "' src='" . $tenorURL . ($this->options->playOnLoad ? $atts[0][2] : $atts[1][2]) . "' style='width:auto;height:auto;max-width:100%;'>";
                    $gif .= "</div>";
                    $excerpt = str_replace($match[0], $gif, $excerpt);
                }
            }
        }
        return $excerpt;
    }

    public function editorButtons($buttons) {
        if ($this->options->isAllowedFormAndUser()) {
            $buttons[] = [
                "class" => "ql-tenor",
                "value" => "",
                "name" => "tenor",
                "title" => esc_attr__("Tenor", "wpdiscuz-tenor-integration"),
                "svg" => "<svg viewBox='0 0 16 16' width='16' height='16'><path d='M.783 12.705c.4.8 1.017 1.206 1.817 1.606 0 0 1.3.594 2.5.694 1 .1 1.9.1 2.9.1s1.9 0 2.9-.1 1.679-.294 2.479-.694c.8-.4 1.157-.906 1.557-1.706.018 0 .4-1.405.5-2.505.1-1.2.1-3 0-4.3-.1-1.1-.073-1.976-.473-2.676-.4-.8-.863-1.408-1.763-1.808-.6-.3-1.2-.3-2.4-.4-1.8-.1-3.8-.1-5.7 0-1 .1-1.7.1-2.5.5s-1.417 1.1-1.817 1.9c0 0-.4 1.484-.5 2.584-.1 1.2-.1 3 0 4.3.1 1 .2 1.705.5 2.505zm10.498-8.274h2.3c.4 0 .769.196.769.696 0 .5-.247.68-.747.68l-1.793.02.022 1.412 1.252-.02c.4 0 .835.204.835.704s-.442.696-.842.696H11.82l-.045 2.139c0 .4-.194.8-.694.8-.5 0-.7-.3-.7-.8l-.031-5.631c0-.4.43-.696.93-.696zm-3.285.771c0-.5.3-.8.8-.8s.8.3.8.8l-.037 5.579c0 .4-.3.8-.8.8s-.8-.4-.8-.8l.037-5.579zm-3.192-.825c.7 0 1.307.183 1.807.683.3.3.4.7.1 1-.2.4-.7.4-1 .1-.2-.1-.5-.3-.9-.3-1 0-2.011.84-2.011 2.14 0 1.3.795 2.227 1.695 2.227.4 0 .805.073 1.105-.127V8.6c0-.4.3-.8.8-.8s.8.3.8.8v1.8c0 .2.037.071-.063.271-.7.7-1.57.991-2.47.991C2.868 11.662 1.3 10.2 1.3 8s1.704-3.623 3.504-3.623z'></path></svg>"
            ];
        }
        return $buttons;
    }

    public function editorButtonsHtml($buttons) {
        if ($this->options->isAllowedFormAndUser()) {
            $buttons .= "<span class='wpdiscuz-tenor-icon' title='" . esc_attr__("Tenor", "wpdiscuz-tenor-integration") . "'>";
            $buttons .= "<svg viewBox='0 0 16 16' width='18' height='18'><path d='M.783 12.705c.4.8 1.017 1.206 1.817 1.606 0 0 1.3.594 2.5.694 1 .1 1.9.1 2.9.1s1.9 0 2.9-.1 1.679-.294 2.479-.694c.8-.4 1.157-.906 1.557-1.706.018 0 .4-1.405.5-2.505.1-1.2.1-3 0-4.3-.1-1.1-.073-1.976-.473-2.676-.4-.8-.863-1.408-1.763-1.808-.6-.3-1.2-.3-2.4-.4-1.8-.1-3.8-.1-5.7 0-1 .1-1.7.1-2.5.5s-1.417 1.1-1.817 1.9c0 0-.4 1.484-.5 2.584-.1 1.2-.1 3 0 4.3.1 1 .2 1.705.5 2.505zm10.498-8.274h2.3c.4 0 .769.196.769.696 0 .5-.247.68-.747.68l-1.793.02.022 1.412 1.252-.02c.4 0 .835.204.835.704s-.442.696-.842.696H11.82l-.045 2.139c0 .4-.194.8-.694.8-.5 0-.7-.3-.7-.8l-.031-5.631c0-.4.43-.696.93-.696zm-3.285.771c0-.5.3-.8.8-.8s.8.3.8.8l-.037 5.579c0 .4-.3.8-.8.8s-.8-.4-.8-.8l.037-5.579zm-3.192-.825c.7 0 1.307.183 1.807.683.3.3.4.7.1 1-.2.4-.7.4-1 .1-.2-.1-.5-.3-.9-.3-1 0-2.011.84-2.011 2.14 0 1.3.795 2.227 1.695 2.227.4 0 .805.073 1.105-.127V8.6c0-.4.3-.8.8-.8s.8.3.8.8v1.8c0 .2.037.071-.063.271-.7.7-1.57.991-2.47.991C2.868 11.662 1.3 10.2 1.3 8s1.704-3.623 3.504-3.623z'></path></svg>";
            $buttons .= "</span>";
        }
        return $buttons;
    }

    public function printPopup() {
        $wpdiscuz = wpDiscuz();
        if ($wpdiscuz->isWpdiscuzLoaded && $this->options->isAllowedFormAndUser()) {
            ?>
            <div id="wpdiscuz-tenor-popup-bg"></div>
            <div id="wpdiscuz-tenor-popup">
                <div id="wpdiscuz-tenor-search-wrapper">
                    <input type="text" name="wpdiscuz-tenor-search" id="wpdiscuz-tenor-search" placeholder="<?php esc_attr_e("Search Tenor", "wpdiscuz-tenor-integration"); ?>">
                </div>
                <div id="wpdiscuz-tenor-links">
                    <a href="#" id="wpdiscuz-tenor-back-to-categories"><?php esc_html_e("&lsaquo; Back to Categories", "wpdiscuz-tenor-integration"); ?></a>
                </div>
                <div id="wpdiscuz-tenor-content"></div>
                <div id="wpdiscuz-tenor-powered-by"><img src="<?php echo plugins_url(WPD_TI_DIR_NAME); ?>/assets/img/PoweredByTenor.png"></div>
            </div>
            <?php
        }
    }

    public function enqueueScripts($options) {
        $dep = [$options->general["loadComboVersion"] ? "wpdiscuz-combo-js" : "wpdiscuz-ajax-js"];
        $suf = $options->general["loadMinVersion"] ? ".min" : "";
        wp_register_style("wpdiscuz-tenor", plugins_url(WPD_TI_DIR_NAME . "/assets/css/wpdiscuz-tenor$suf.css"), [], $this->version);
        wp_enqueue_style("wpdiscuz-tenor");
        wp_register_script("wpdiscuz-tenor", plugins_url(WPD_TI_DIR_NAME . "/assets/js/wpdiscuz-tenor$suf.js"), $dep, $this->version, true);
        wp_enqueue_script("wpdiscuz-tenor");
        wp_localize_script("wpdiscuz-tenor", "wpDiscuzTenorObj", [
            "key" => $this->options->key,
            "locale" => $this->options->locale,
            "contentfilter" => $this->options->contentfilter,
            "limit" => $this->options->limit,
            "isAllowed" => $this->options->isAllowedFormAndUser(),
            "phraseTrending" => esc_html__("Featured", "wpdiscuz-tenor-integration"),
        ]);
    }

    public function enqueueWpForoScripts() {
        if (is_wpforo_page()) {
            $options = wpDiscuz()->options;
            $suf = $options->general["loadMinVersion"] ? ".min" : "";
            wp_register_style("wpdiscuz-tenor", plugins_url(WPD_TI_DIR_NAME . "/assets/css/wpdiscuz-tenor$suf.css"), [], $this->version);
            wp_enqueue_style("wpdiscuz-tenor");
        }
    }

    public function enqueueAdminScripts() {
        global $pagenow;
        if ($pagenow === WpdiscuzCore::PAGE_COMMENTS) {
            wp_register_style("wpdiscuz-tenor-admin", plugins_url(WPD_TI_DIR_NAME . "/assets/css/wpdiscuz-tenor-admin.css"), [], $this->version);
            wp_enqueue_style("wpdiscuz-tenor-admin");
            wp_register_script("wpdiscuz-tenor-admin", plugins_url(WPD_TI_DIR_NAME . "/assets/js/wpdiscuz-tenor-admin.js"), ["jquery"], $this->version, true);
            wp_enqueue_script("wpdiscuz-tenor-admin");
        }
        wp_register_style("wpdiscuz-tenor", plugins_url(WPD_TI_DIR_NAME . "/assets/css/wpdiscuz-tenor.css"), [], $this->version);
        wp_enqueue_style("wpdiscuz-tenor");
    }

    public function requirements() {
        if (current_user_can("manage_options")) {
            echo "<div class='error'><p>" . __("wpDiscuz - Tenor GIFs Integration requires wpDiscuz to be installed!", "wpdiscuz-tenor-integration") . "</p></div>";
        }
    }

    public function pluginNewVersion() {
        $pluginData = get_plugin_data(__FILE__);
        if (version_compare($pluginData["Version"], $this->version, ">")) {
            update_option(self::OPTION_VERSION, $pluginData["Version"]);
        } else {
            add_option(self::OPTION_VERSION, "1.0.0", "", "no");
        }
    }

}

$wpDiscuzTenorIntegration = wpDiscuzTenorIntegration::getInstance();
