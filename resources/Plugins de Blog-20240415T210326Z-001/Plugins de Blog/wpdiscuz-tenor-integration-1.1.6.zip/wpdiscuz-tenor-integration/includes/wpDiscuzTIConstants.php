<?php

if (!defined("ABSPATH")) {
	exit();
}

interface wpDiscuzTIConstants {

	const OPTION_VERSION                              = "wpdiscuz_tenor_version";
	const OPTION_SLUG_OPTIONS                         = "wpdiscuz_tenor_options";

}