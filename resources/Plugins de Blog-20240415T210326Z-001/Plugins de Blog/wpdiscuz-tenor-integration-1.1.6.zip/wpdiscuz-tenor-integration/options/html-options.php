<?php
if (!defined("ABSPATH")) {
    exit();
}
?>
<div class="wpd-opt-row">
    <div class="wpd-opt-intro">
        <img class="wpd-opt-img" src="<?php echo plugins_url(WPD_TI_DIR_NAME) ?>/assets/img/tenor-logo.png" style="height: 60px; padding-top: 5px;">
        Tenor is an online GIF database. Its main product is GIF Keyboard. Tenor provides with animated GIF images that users can embed in posts, messages, and in this case in comments.
        Tenor is free. Check their terms of service and other guidelines – <a href="https://tenor.com/legal-terms" target="_blank">Terms of Service</a> and <a href="https://tenor.com/gifapi/documentation#apiterms" target="_blank">API Terms</a>
    </div>
</div>

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="key">
    <div class="wpd-opt-name">
        <label for="key"><?php echo $setting["options"]["key"]["label"] ?></label>
        <p class="wpd-desc">
            <?php echo $setting["options"]["key"]["description"] ?>.<br>
            <a href="https://wpdiscuz.com/getting-tenor-gif-api-key/" target="_blank">Get your Tenor API key &raquo;</a>
        </p>
    </div>
    <div class="wpd-opt-input">
        <input type="text" name="<?php echo $setting["values"]->tabKey; ?>[key]" value="<?php echo esc_attr($setting["values"]->key); ?>" id="key" style="margin:1px;padding:3px 5px; width:90%;"/>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="locale">
    <div class="wpd-opt-name">
        <label for="locale"><?php echo $setting["options"]["locale"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["locale"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
        <input type="text" name="<?php echo $setting["values"]->tabKey; ?>[locale]" value="<?php echo esc_attr($setting["values"]->locale); ?>" id="locale" style="margin:1px;padding:3px 5px; width:90%;"/>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="contentfilter">
    <div class="wpd-opt-name">
        <label for="contentfilter"><?php echo $setting["options"]["contentfilter"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["contentfilter"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
        <div class="wpd-radio">
            <input type="radio" value="off" <?php checked("off" === $setting["values"]->contentfilter); ?> name="<?php echo $setting["values"]->tabKey; ?>[contentfilter]" id="contentfilterOff" class="contentfilter"/>
            <label for="contentfilterOff" class="wpd-radio-circle"></label>
            <label for="contentfilterOff"><?php esc_html_e("Off - G, PG, PG-13, and R (no nudity)", "wpdiscuz-tenor-integration") ?></label>
        </div>
        <div class="wpd-radio">
            <input type="radio" value="low" <?php checked("low" === $setting["values"]->contentfilter); ?> name="<?php echo $setting["values"]->tabKey; ?>[contentfilter]" id="contentfilterLow" class="contentfilter"/>
            <label for="contentfilterLow" class="wpd-radio-circle"></label>
            <label for="contentfilterLow"><?php esc_html_e("Low - G, PG, and PG-13", "wpdiscuz-tenor-integration") ?></label>
        </div>
        <div class="wpd-radio">
            <input type="radio" value="medium" <?php checked("medium" === $setting["values"]->contentfilter); ?> name="<?php echo $setting["values"]->tabKey; ?>[contentfilter]" id="contentfilterMedium" class="contentfilter"/>
            <label for="contentfilterMedium" class="wpd-radio-circle"></label>
            <label for="contentfilterMedium"><?php esc_html_e("Medium - G and PG", "wpdiscuz-tenor-integration") ?></label>
        </div>
        <div class="wpd-radio">
            <input type="radio" value="high" <?php checked("high" === $setting["values"]->contentfilter); ?> name="<?php echo $setting["values"]->tabKey; ?>[contentfilter]" id="contentfilterHigh" class="contentfilter"/>
            <label for="contentfilterHigh" class="wpd-radio-circle"></label>
            <label for="contentfilterHigh"><?php esc_html_e("High - G", "wpdiscuz-tenor-integration") ?></label>
        </div>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="limit">
    <div class="wpd-opt-name">
        <label for="limit"><?php echo $setting["options"]["limit"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["limit"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
        <input type="number" min="10" max="50" name="<?php echo $setting["values"]->tabKey; ?>[limit]" value="<?php echo esc_attr($setting["values"]->limit); ?>" id="limit" style="margin:1px;padding:3px 5px; width:90%;"/>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="playOnLoad">
    <div class="wpd-opt-name">
        <label for="playOnLoad"><?php echo esc_html($setting["options"]["playOnLoad"]["label"]); ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["playOnLoad"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
        <div class="wpd-switcher">
            <input type="checkbox" <?php checked($setting["values"]->playOnLoad == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[playOnLoad]" id="playOnLoad">
            <label for="playOnLoad"></label>
        </div>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="allowedForms">
    <div class="wpd-opt-name">
        <label for="allowedForms"><?php echo $setting["options"]["allowedForms"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["allowedForms"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
		<?php
		$forms = get_posts(["numberposts" => -1, "post_type" => "wpdiscuz_form", "post_status" => "publish"]);
		foreach ($forms as $form) {
			?>
            <div class="wpd-mublock-inline" style="width:95%;">
                <input type="checkbox" <?php checked(in_array($form->ID, $setting["values"]->allowedForms)); ?> value="<?php echo $form->ID; ?>" name="<?php echo $setting["values"]->tabKey; ?>[allowedForms][]" id="wti-form<?php echo $form->ID; ?>" style="margin:0px; vertical-align: middle;" />
                <label for="wti-form<?php echo $form->ID; ?>" style="white-space:nowrap; font-size:13px;"><?php echo $form->post_title ? esc_html($form->post_title) : __('no title', "wpdiscuz-tenor-integration") . ' ( ID : ' . $form->ID . ' )'; ?></label>
            </div>
			<?php
		}
		?>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="allowedUserRoles">
    <div class="wpd-opt-name">
        <label for="allowedUserRoles"><?php echo $setting["options"]["allowedUserRoles"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["allowedUserRoles"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
		<?php
		foreach (get_editable_roles() as $role => $info) {
			?>
            <div class="wpd-mublock-inline" style="width: 45%;">
                <input type="checkbox" <?php checked(in_array($role, $setting["values"]->allowedUserRoles)); ?> value="<?php echo $role; ?>" name="<?php echo $setting["values"]->tabKey; ?>[allowedUserRoles][]" id="wti-<?php echo $role; ?>" style="margin:0px; vertical-align: middle;" />
                <label for="wti-<?php echo $role; ?>" style=""><?php echo $info["name"]; ?></label>
            </div>
			<?php
		}
		?>
        <div class="wpd-mublock-inline" style="width: 45%;">
            <input type="checkbox" <?php checked($setting["values"]->isGuestAllowed == 1); ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[isGuestAllowed]" id="wti-guest" style="margin:0px; vertical-align: middle;" />
            <label for="wti-guest" style=""><?php esc_html_e("Guest", "wpdiscuz-tenor-integration"); ?></label>
        </div>
    </div>
</div>
<!-- Option end -->