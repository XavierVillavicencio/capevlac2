=== wpDiscuz - Front-end Moderation ===
Contributors: gVectors Team
Requires at least: 5.0
Tested up to: 6.4
Stable tag: 7.1.0
Requires PHP: 5.4 and higher
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

wpDiscuz Frontend Moderation addon is an “All in One” powerful yet simple toolkit to
manage comments on frontend. This addon allows to approve new comments,
unapprove automatically approved bad comments, put those in spam, send an
email to comment author, move certain comment to another post, add comment
author to blacklist and trash or permanently deleted. Also this addon allows
registered users to delete their comments within comment editing time-limit.
All front-end phrases are available for quick translation in addon settings page.
And there are options to change colors and backgrounds of moderation options menu on front-end.
