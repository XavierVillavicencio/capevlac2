<?php
if (!defined("ABSPATH")) {
	exit();
}
$displayedUser = bp_get_displayed_user();
if (!empty($displayedUser->userdata->ID)) {
    $wpdiscuz = wpDiscuz();
    $reactionsCount = $this->dbmanager->getReactionsCount($displayedUser->userdata->ID);
    if ($reactionsCount) {
        $page = !empty($_GET["page"]) ? intval($_GET["page"]) : 1;
        $perPage = apply_filters("wpdiscuz_bpi_reactions_per_page", 10);
        $pagesCount = ceil($reactionsCount / $perPage);
        if ($page < 1) {
            $page = 1;
        } else if ($page > $pagesCount) {
            $page = $pagesCount;
        }
        $reactions = $this->dbmanager->getReactions($displayedUser->userdata->ID, $perPage, ($page - 1) * $perPage);
        if ($reactions) {
            foreach ($reactions as $key => $reaction) {
                $comment = get_comment($reaction->comment_id);
				$commentAuthor = get_user_by("id", $comment->user_id);
                ?>
                <div class="wpdiscuz-bpi-item wpd-bp-reactions">
                    <div class="wpdiscuz-bpi-item-icon">
                        <?php
                        if ($commentAuthor) {
                            ?>
                            <a class="wpdiscuz-bpi-avatar-wrapper" href="<?php echo esc_url_raw(bp_core_get_user_domain($comment->user_id)); ?>" target="_blank" title="<?php echo esc_attr($comment->comment_author); ?>">
                                <?php echo get_avatar(($comment->user_id ? $comment->user_id : $comment->comment_author_email), 56, "", $comment->comment_author, ["wpdiscuz_current_user" => ($commentAuthor ? $commentAuthor : ""), "wpdiscuz_gravatar_user_email" => $comment->comment_author_email]); ?>
                            </a>
                            <?php
                        } else {
                            ?>
							<?php echo get_avatar(($comment->user_id ? $comment->user_id : $comment->comment_author_email), 56, "", $comment->comment_author, ["wpdiscuz_current_user" => ($commentAuthor ? $commentAuthor : ""), "wpdiscuz_gravatar_user_email" => $comment->comment_author_email]); ?>
                            <?php
						}
						?>
                    </div>
                    <div class="wpdiscuz-bpi-item-left">
                        <div class="wpdiscuz-bpi-item-left-primary">
                            <div class="wpdiscuz-bpi-post-link-wrapper">
                                <span class="wpdiscuz-bpi-post-link" title="<?php echo esc_attr($comment->comment_author); ?>">
                                    <?php echo esc_attr($comment->comment_author); ?>
                                </span>
                            </div>
                            <div class="wpdiscuz-bpi-item-link-wrapper">
                                <a class="wpdiscuz-bpi-item-link" href="<?php echo esc_url_raw(get_comment_link($comment)); ?>" target="_blank">
                                    <?php echo wp_trim_words(apply_filters("comment_text", $comment->comment_content, $comment, ["is_wpdiscuz_comment" => true]), 15, "&hellip;"); ?>
                                </a>
                            </div>
                        </div>
                        <div class="wpdiscuz-bpi-item-left-secondary">
                            <?php
                            if ($reaction->vote_type > 0) {
                                ?>
                                <svg xmlns="https://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" color="#118b26" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-thumbs-up"><path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3"></path></svg>
                                <?php
                            } else {
                                ?>
                                <svg xmlns="https://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" color="#e8484a" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-thumbs-down"><path d="M10 15v4a3 3 0 0 0 3 3l4-9V2H5.72a2 2 0 0 0-2 1.7l-1.38 9a2 2 0 0 0 2 2.3zm7-13h2.67A2.31 2.31 0 0 1 22 4v7a2.31 2.31 0 0 1-2.33 2H17"></path></svg>
                                <?php
                            }
                            ?>
                        </div>
                    </div>
                    <div class="wpdiscuz-bpi-item-right">
                        <div class="wpdiscuz-bpi-item-date">
                            <?php echo esc_html($wpdiscuz->helper->dateDiff(date("Y-m-d H:i:s", $reaction->date))); ?>
                        </div>
                    </div>
                </div>
                <?php
            }
            include WPD_BPI_PATH . "/includes/profile-tabs/pagination.php";
        } else {
            ?>
            <div class='wpdiscuz-bpi-item'><?php esc_html_e("Has not reacted to any comment yet", "wpdiscuz-buddypress-integration"); ?></div>
            <?php
        }
    } else {
        ?>
        <div class='wpdiscuz-bpi-item'><?php esc_html_e("Has not reacted to any comment yet", "wpdiscuz-buddypress-integration"); ?></div>
        <?php
    }
} else {
	?>
	<div class='wpdiscuz-bpi-item'><?php esc_html_e("Has not reacted to any comment yet", "wpdiscuz-buddypress-integration"); ?></div>
	<?php
}