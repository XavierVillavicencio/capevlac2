<?php
if (!defined("ABSPATH")) {
	exit();
}
$displayedUser = bp_get_displayed_user();
if (!empty($displayedUser->userdata->ID)) {
    $wpdiscuz = wpDiscuz();
    $ratesCount = $this->dbmanager->getRatesCount($displayedUser->userdata->ID);
    if ($ratesCount) {
        $page = !empty($_GET["page"]) ? intval($_GET["page"]) : 1;
        $perPage = apply_filters("wpdiscuz_bpi_rates_per_page", 10);
        $pagesCount = ceil($ratesCount / $perPage);
        if ($page < 1) {
            $page = 1;
        } else if ($page > $pagesCount) {
            $page = $pagesCount;
        }
        $rates = $this->dbmanager->getRates($displayedUser->userdata->ID, $perPage, ($page - 1) * $perPage);
        if ($rates) {
            $fullStarSVG = apply_filters("wpdiscuz_full_star_svg", "<svg xmlns='https://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'><path d='M0 0h24v24H0z' fill='none'/><path class='wpd-star' d='M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z'/><path d='M0 0h24v24H0z' fill='none'/></svg>", "post", "fas fa-star");
            foreach ($rates as $key => $rate) {
                ?>
                <div class="wpdiscuz-bpi-item wpd-bp-rates">
                    <div class="wpdiscuz-bpi-item-icon">
                        <svg height="auto" viewBox="0 0 60.031 60" width="22" xmlns="http://www.w3.org/2000/svg"><defs><style>.cls-1 {fill: rgba(136, 136, 136, 0.53);fill-rule: evenodd;}</style></defs><path class="cls-1" d="M828.776,237.723l-11.4,8.657a3,3,0,0,0-.993,1.3,2.948,2.948,0,0,0-.162,1.618l3.078,17.135a3,3,0,0,1-1.275,3.011,3.161,3.161,0,0,1-3.326.147l-13.174-7.409a3.156,3.156,0,0,0-3.09,0L785.257,269.6a3.164,3.164,0,0,1-1.55.4,3.13,3.13,0,0,1-1.777-.551,3,3,0,0,1-1.274-3.011l3.076-17.135a2.929,2.929,0,0,0-.16-1.618,3,3,0,0,0-.993-1.3l-11.4-8.657a3,3,0,0,1-1.117-3.085,3.069,3.069,0,0,1,2.391-2.285l14.654-2.967a3.129,3.129,0,0,0,1.28-.577,3.02,3.02,0,0,0,.885-1.074l7.914-16.018a3.131,3.131,0,0,1,5.586,0l7.91,16.018a3.028,3.028,0,0,0,.884,1.074,3.162,3.162,0,0,0,1.281.577l14.655,2.967a3.07,3.07,0,0,1,2.394,2.285A3,3,0,0,1,828.776,237.723Zm-17.121-2.454a9.22,9.22,0,0,1-3.713-1.675,9.12,9.12,0,0,1-2.647-3.216L800,219.658v36.125a9.188,9.188,0,0,1,4.451,1.166l7.839,4.409-1.976-10.994a9.01,9.01,0,0,1,3.454-8.781l6.122-4.647Z" data-name="half rating" id="half_rating" transform="translate(-769.969 -210)"/></svg>
                    </div>
                    <div class="wpdiscuz-bpi-item-left">
                        <div class="wpdiscuz-bpi-item-left-primary">
                            <div class="wpdiscuz-bpi-item-link-wrapper">
                                <a class="wpdiscuz-bpi-item-link" href="<?php echo esc_url_raw(get_the_permalink($rate->post_id)); ?>" target="_blank">
                                    <?php echo get_the_title($rate->post_id); ?>
                                </a>
                            </div>
                        </div>
                        <div class="wpdiscuz-bpi-item-left-secondary">
                            <?php
                            for ($i = 1; $i < 6; $i++) {
                                if ($i <= $rate->rating) {
                                    echo str_replace("wpd-star", "wpd-star wpd-active", $fullStarSVG);
                                } else {
                                    echo $fullStarSVG;
                                }
                            }
                            ?>
                        </div>
                    </div>
                    <div class="wpdiscuz-bpi-item-right">
                        <div class="wpdiscuz-bpi-item-date">
                            <?php echo esc_html($wpdiscuz->helper->dateDiff(date("Y-m-d H:i:s", $rate->date))); ?>
                        </div>
                    </div>
                </div>
                <?php
            }
            include WPD_BPI_PATH . "/includes/profile-tabs/pagination.php";
        } else {
            ?>
            <div class='wpdiscuz-bpi-item'><?php esc_html_e("No rates found", "wpdiscuz-buddypress-integration"); ?></div>
            <?php
        }
    } else {
        ?>
        <div class='wpdiscuz-bpi-item'><?php esc_html_e("No rates found", "wpdiscuz-buddypress-integration"); ?></div>
        <?php
    }
} else {
	?>
	<div class='wpdiscuz-bpi-item'><?php esc_html_e("No rates found", "wpdiscuz-buddypress-integration"); ?></div>
	<?php
}