<?php
if (!defined("ABSPATH")) {
	exit();
}
$displayedUser = bp_get_displayed_user();
if (!empty($displayedUser->userdata->ID)) {
    $wpdiscuz = wpDiscuz();
    $followingCount = $this->dbmanager->getFollowsCount($displayedUser->userdata->ID);
    if ($followingCount) {
        $page = !empty($_GET["page"]) ? intval($_GET["page"]) : 1;
        $perPage = apply_filters("wpdiscuz_bpi_following_per_page", 10);
        $pagesCount = ceil($followingCount / $perPage);
        if ($page < 1) {
            $page = 1;
        } else if ($page > $pagesCount) {
            $page = $pagesCount;
        }
        $following = $this->dbmanager->getFollows($displayedUser->userdata->ID, $perPage, ($page - 1) * $perPage);
        if ($following) {
			$isMyProfile = bp_is_my_profile();
            foreach ($following as $key => $follow) {
                $followedUser = get_user_by("id", $follow->user_id);
                ?>
                <div class="wpdiscuz-bpi-item wpd-bp-following" data-wpd-bpi-follow-id="<?php echo $follow->id; ?>">
                    <div class="wpdiscuz-bpi-item-icon">
                        <?php
                        if ($followedUser) {
                            ?>
                            <a class="wpdiscuz-bpi-avatar-wrapper" href="<?php echo esc_url_raw(bp_core_get_user_domain($followedUser->ID)); ?>" target="_blank" title="<?php echo esc_attr($followedUser->display_name); ?>">
								<?php echo get_avatar($followedUser->ID, 32, "", $followedUser->display_name, ["wpdiscuz_current_user" => $followedUser, "wpdiscuz_gravatar_user_email" => $followedUser->user_email]); ?>
                            </a>
                            <?php
                        } else {
                            echo get_avatar($follow->user_email, 32, "", $follow->user_name, ["wpdiscuz_current_user" => "", "wpdiscuz_gravatar_user_email" => $follow->user_email]);
						}
                        ?>
                    </div>
                    <div class="wpdiscuz-bpi-item-left">
                        <div class="wpdiscuz-bpi-item-left-primary">
                            <div class="wpdiscuz-bpi-post-link-wrapper">
                                <?php
                                if ($followedUser) {
                                    ?>
                                    <span class="wpdiscuz-bpi-post-link" title="<?php echo esc_attr($followedUser->display_name); ?>">
                                        <?php echo esc_html($followedUser->display_name); ?>
                                    </span>
                                    <?php
                                } else {
                                    ?>
                                    <span class="wpdiscuz-bpi-post-link" title="<?php echo esc_attr($follow->user_name); ?>">
                                        <?php echo esc_html($follow->user_name); ?>
                                    </span>
                                    <?php
                                }
                                ?>
                            </div>
                        </div>
                        <div class="wpdiscuz-bpi-item-left-secondary">
                            <?php
                            if ($isMyProfile) {
                                ?>
                                <div class="wpdiscuz-bpi-unfollow">
                                    <a href="#"><?php _e("Unfollow", "wpdiscuz-buddypress-integration"); ?></a>
                                </div>
								<?php
							}
							?>
                        </div>
                    </div>
                    <div class="wpdiscuz-bpi-item-right">
                        <div class="wpdiscuz-bpi-item-date">
                            <?php echo esc_html($wpdiscuz->helper->dateDiff($follow->follow_date)); ?>
                        </div>
                    </div>
                </div>
                <?php
            }
            include WPD_BPI_PATH . "/includes/profile-tabs/pagination.php";
        } else {
            ?>
            <div class="wpdiscuz-bpi-item"><?php esc_html_e("No data found", "wpdiscuz-buddypress-integration"); ?></div>
            <?php
        }
    } else {
        ?>
        <div class="wpdiscuz-bpi-item"><?php esc_html_e("No data found", "wpdiscuz-buddypress-integration"); ?></div>
        <?php
    }
} else {
	?>
	<div class="wpdiscuz-bpi-item"><?php esc_html_e("No data found", "wpdiscuz-buddypress-integration"); ?></div>
	<?php
}