<?php
if (!defined("ABSPATH")) {
	exit();
}
$displayedUser = bp_get_displayed_user();
if (!empty($displayedUser->userdata->ID)) {
    $wpdiscuz = wpDiscuz();
    $followersCount = $this->dbmanager->getFollowersCount($displayedUser->userdata->ID);
    if ($followersCount) {
        $page = !empty($_GET["page"]) ? intval($_GET["page"]) : 1;
        $perPage = apply_filters("wpdiscuz_bpi_followers_per_page", 10);
        $pagesCount = ceil($followersCount / $perPage);
        if ($page < 1) {
            $page = 1;
        } else if ($page > $pagesCount) {
            $page = $pagesCount;
        }
        $followers = $this->dbmanager->getFollowers($displayedUser->userdata->ID, $perPage, ($page - 1) * $perPage);
        if ($followers) {
            foreach ($followers as $key => $follower) {
				$followerUser = get_user_by("id", $follower->follower_id);
                ?>
                <div class="wpdiscuz-bpi-item wpd-bp-followers">
                    <div class="wpdiscuz-bpi-item-icon">
						<?php
						if ($followerUser) {
							?>
                            <a class="wpdiscuz-bpi-avatar-wrapper" href="<?php echo esc_url_raw(bp_core_get_user_domain($followerUser->ID)); ?>" target="_blank" title="<?php echo esc_attr($followerUser->display_name); ?>">
								<?php echo get_avatar($followerUser->ID, 32, "", $followerUser->display_name, ["wpdiscuz_current_user" => $followerUser, "wpdiscuz_gravatar_user_email" => $followerUser->user_email]); ?>
                            </a>
							<?php
						} else {
							echo get_avatar($follower->follower_email, 32, "", $follower->follower_name, ["wpdiscuz_current_user" => "", "wpdiscuz_gravatar_user_email" => $follower->follower_email]);
						}
						?>
                    </div>
                    <div class="wpdiscuz-bpi-item-left">
                        <div class="wpdiscuz-bpi-item-left-primary">
                            <div class="wpdiscuz-bpi-post-link-wrapper">
								<?php
								if ($followerUser) {
									?>
                                    <span class="wpdiscuz-bpi-post-link" title="<?php echo esc_attr($followerUser->display_name); ?>">
                                        <?php echo esc_html($followerUser->display_name); ?>
                                    </span>
									<?php
								} else {
									?>
                                    <span class="wpdiscuz-bpi-post-link" title="<?php echo esc_attr($follower->follower_name); ?>">
                                        <?php echo esc_html($follower->follower_name); ?>
                                    </span>
									<?php
								}
								?>
                            </div>
                        </div>
                    </div>
                    <div class="wpdiscuz-bpi-item-right">
                        <div class="wpdiscuz-bpi-item-date">
                            <?php echo esc_html($wpdiscuz->helper->dateDiff($follower->follow_date)); ?>
                        </div>
                    </div>
                </div>
                <?php
            }
            include WPD_BPI_PATH . "/includes/profile-tabs/pagination.php";
        } else {
            ?>
            <div class='wpdiscuz-bpi-item'><?php esc_html_e("Nobody follows yet", "wpdiscuz-buddypress-integration"); ?></div>
            <?php
        }
    } else {
        ?>
        <div class='wpdiscuz-bpi-item'><?php esc_html_e("Nobody follows yet", "wpdiscuz-buddypress-integration"); ?></div>
        <?php
    }
} else {
	?>
	<div class='wpdiscuz-bpi-item'><?php esc_html_e("Nobody follows yet", "wpdiscuz-buddypress-integration"); ?></div>
	<?php
}