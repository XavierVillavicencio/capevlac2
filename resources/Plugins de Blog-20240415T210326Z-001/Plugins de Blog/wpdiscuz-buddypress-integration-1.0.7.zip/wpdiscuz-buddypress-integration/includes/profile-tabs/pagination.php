<?php
if (!defined("ABSPATH")) {
	exit();
}

if (isset($pagesCount, $page)  && $pagesCount > 1) {
	if ($page - 5 > 1) {
		$start = $page - 5;
	} else {
		$start = 1;
	}
	if ($page + 5 < $pagesCount) {
		$end = $page + 5;
	} else {
		$end = $pagesCount;
	}
	?>
	<div class='wpdiscuz-bpi-pagination'>
		<?php
		if ($page > 1) {
			?>
			<a href='?page=1' class='wpdiscuz-bpi-page-link'><?php esc_html_e("&laquo;", "wpdiscuz-buddypress-integration"); ?></a>
			<?php
		}
		for ($i = $start; $i <= $end; $i++) {
			if ($i === $page) {
				?>
				<span class='wpdiscuz-bpi-page-link wpdiscuz-bpi-current-page'><?php echo esc_html($i); ?></span>
				<?php
			} else {
				?>
				<a href='?page=<?php echo esc_attr($i); ?>' class='wpdiscuz-bpi-page-link'><?php echo esc_html($i); ?></a>
				<?php
			}
		}
		if ($page < $pagesCount) {
			?>
			<a href='?page=<?php echo esc_attr($pagesCount); ?>' class='wpdiscuz-bpi-page-link'><?php esc_html_e("&raquo;", "wpdiscuz-buddypress-integration"); ?></a>
			<?php
		}
		?>
	</div>
	<?php
}