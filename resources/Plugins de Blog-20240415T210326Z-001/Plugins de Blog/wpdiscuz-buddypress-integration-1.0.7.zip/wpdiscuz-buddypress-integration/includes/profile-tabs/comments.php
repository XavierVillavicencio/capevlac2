<?php
if ( ! defined( "ABSPATH" ) ) {
	exit();
}
$displayedUser = bp_get_displayed_user();
if ( ! empty( $displayedUser->userdata->ID ) ) {
	$wpdiscuz = wpDiscuz();
	$args     = [ "count" => true, "status" => "approve", "user_id" => $displayedUser->userdata->ID ];

	if ( $wpdiscuz->options->login["isUserByEmail"] ) {
		$args["author_email"] = $displayedUser->userdata->user_email;
	}

	if ( function_exists( 'bp_comments_pre_query' ) ) {
		remove_filter( 'comments_pre_query', 'bp_comments_pre_query', 10 );
	}

	$commentsCount = get_comments( $args );
	if ( $commentsCount ) {
		$page       = ! empty( $_GET["page"] ) ? intval( $_GET["page"] ) : 1;
		$perPage    = apply_filters( "wpdiscuz_bpi_comments_per_page", 10 );
		$pagesCount = ceil( $commentsCount / $perPage );
		if ( $page < 1 ) {
			$page = 1;
		} else if ( $page > $pagesCount ) {
			$page = $pagesCount;
		}
		$args["count"]  = false;
		$args["number"] = $perPage;
		$args["offset"] = ( $page - 1 ) * $perPage;
		$args["order"]  = "DESC";
		$comments       = get_comments( $args );
		if ( $comments ) {
			$isMyProfile = bp_is_my_profile();
			foreach ( $comments as $key => $comment ) {
				$title = get_the_title( $comment->comment_post_ID );
				?>
                <div class="wpdiscuz-bpi-item wpd-bp-com" data-wpd-bpi-delete-id="<?php echo $comment->comment_ID; ?>">
                    <div class="wpdiscuz-bpi-item-icon">
                        <svg id="Outlined" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg"><title/>
                            <g id="Fill">
                                <path d="M26,3H6A3,3,0,0,0,3,6V30.41l5.12-5.12A1.05,1.05,0,0,1,8.83,25H26a3,3,0,0,0,3-3V6A3,3,0,0,0,26,3Zm1,19a1,1,0,0,1-1,1H8.83a3,3,0,0,0-2.12.88L5,25.59V6A1,1,0,0,1,6,5H26a1,1,0,0,1,1,1Z"/>
                                <rect height="2" width="12" x="10" y="11"/>
                                <rect height="2" width="7" x="10" y="15"/>
                            </g>
                        </svg>
                    </div>
                    <div class="wpdiscuz-bpi-item-left">
                        <div class="wpdiscuz-bpi-item-left-primary">
                            <div class="wpdiscuz-bpi-post-link-wrapper">
                                <span><?php esc_html_e( "Commented to:", "wpdiscuz-buddypress-integration" ); ?></span>
                                <a class="wpdiscuz-bpi-post-link"
                                   href="<?php echo esc_url_raw( get_permalink( $comment->comment_post_ID ) ); ?>"
                                   target="_blank" title="<?php echo esc_attr( $title ); ?>">
									<?php echo esc_html( $title ); ?>
                                </a>
                            </div>
                            <div class="wpdiscuz-bpi-item-link-wrapper">
                                <a class="wpdiscuz-bpi-item-link"
                                   href="<?php echo esc_url_raw( get_comment_link( $comment ) ); ?>" target="_blank">
									<?php echo wp_trim_words( apply_filters( "comment_text", $comment->comment_content, $comment, [ "is_wpdiscuz_comment" => true ] ), 20, "&hellip;" ); ?>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="wpdiscuz-bpi-item-right">
						<?php
						if ( $isMyProfile ) {
							?>
                            <div class="wpdiscuz-bpi-delete">
                                <a href="#"><?php _e( "Delete", "wpdiscuz-buddypress-integration" ); ?></a>
                            </div>
							<?php
						}
						?>
                        <div class="wpdiscuz-bpi-item-date">
							<?php echo esc_html( $wpdiscuz->helper->getCommentDate( $comment ) ); ?>
                        </div>
                    </div>
                </div>
				<?php
			}
			include WPD_BPI_PATH . "/includes/profile-tabs/pagination.php";
		} else {
			?>
            <div class='wpdiscuz-bpi-item'><?php esc_html_e( "No comments found", "wpdiscuz-buddypress-integration" ); ?></div>
			<?php
		}
	} else {
		?>
        <div class='wpdiscuz-bpi-item'><?php esc_html_e( "No comments found", "wpdiscuz-buddypress-integration" ); ?></div>
		<?php
	}
} else {
	?>
    <div class='wpdiscuz-bpi-item'><?php esc_html_e( "No comments found", "wpdiscuz-buddypress-integration" ); ?></div>
	<?php
}

if ( function_exists( 'bp_comments_pre_query' ) ) {
	add_filter( 'comments_pre_query', 'bp_comments_pre_query', 10 );
}