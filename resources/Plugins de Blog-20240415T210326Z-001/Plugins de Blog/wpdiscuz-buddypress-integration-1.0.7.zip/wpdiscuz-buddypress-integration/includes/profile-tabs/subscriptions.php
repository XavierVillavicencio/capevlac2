<?php
if (!defined("ABSPATH")) {
	exit();
}
$displayedUser = bp_get_displayed_user();
if (!empty($displayedUser->userdata->ID)) {
    $wpdiscuz = wpDiscuz();
    $subscriptionsCount = $this->dbmanager->getSubscriptionsCount($displayedUser->userdata->user_email);
    if ($subscriptionsCount) {
        $page = !empty($_GET["page"]) ? intval($_GET["page"]) : 1;
        $perPage = apply_filters("wpdiscuz_bpi_subscriptions_per_page", 10);
        $pagesCount = ceil($subscriptionsCount / $perPage);
        if ($page < 1) {
            $page = 1;
        } else if ($page > $pagesCount) {
            $page = $pagesCount;
        }
        $subscriptions = $this->dbmanager->getSubscriptions($displayedUser->userdata->user_email, $perPage, ($page - 1) * $perPage);
        if ($subscriptions) {
            $isMyProfile = bp_is_my_profile();
            foreach ($subscriptions as $key => $subscription) {
                if ($subscription->subscribtion_type === WpdiscuzCore::SUBSCRIPTION_COMMENT) {
                    if ($comment = get_comment($subscription->subscribtion_id)) {
                        $content = wp_trim_words(apply_filters("comment_text", $comment->comment_content, $comment, ["is_wpdiscuz_comment" => true]), 20, "&hellip;");
                        ?>
                        <div class="wpdiscuz-bpi-item wpd-bp-sbs" data-wpd-bpi-subscription-id="<?php echo $subscription->id; ?>">
                            <div class="wpdiscuz-bpi-item-icon">
                                <svg style="enable-background:new 0 0 32 32;" version="1.1" viewBox="0 0 32 32" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><style type="text/css">.st0{fill:none;stroke: #888888;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:10;}  .st1{fill:none;stroke: #888888;stroke-width:2;stroke-linejoin:round;stroke-miterlimit:10;}</style><polyline class="st0" points="3,10 16,18 29,10 "/><path class="st0" d="M25,5H7C4.8,5,3,6.8,3,9v14c0,2.2,1.8,4,4,4h2v4l0,0c3.9-2.6,8.5-4,13.2-4H25c2.2,0,4-1.8,4-4V9  C29,6.8,27.2,5,25,5z"/></svg>
                            </div>
                            <div class="wpdiscuz-bpi-item-left">
                                <div class="wpdiscuz-bpi-item-left-primary">
                                    <div class="wpdiscuz-bpi-post-link-wrapper">
                                        <a class="wpdiscuz-bpi-post-link" href="<?php echo esc_url_raw(get_comment_link($subscription->subscribtion_id)); ?>" target="_blank" title="<?php echo esc_attr($content); ?>">
                                            <?php echo esc_html($content); ?>
                                        </a>
                                    </div>
                                    <div class="wpdiscuz-bpi-item-link-wrapper">
                                        <span><?php esc_html_e("subscribed to this comment", "wpdiscuz-buddypress-integration"); ?></span>
                                    </div>
                                </div>
                            </div>
                            <div class="wpdiscuz-bpi-item-right">
                                <?php
                                if ($isMyProfile) {
                                    ?>
                                    <div class="wpdiscuz-bpi-unsubscribe">
                                        <a href="#"><?php _e("Unsubscribe", "wpdiscuz-buddypress-integration"); ?></a>
                                    </div>
                                    <?php
                                }
                                ?>
                                <div class="wpdiscuz-bpi-item-date">
                                    <?php echo esc_html($wpdiscuz->helper->dateDiff($subscription->subscription_date)); ?>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                } else if ($post = get_post($subscription->subscribtion_id)) {
                    $title = get_the_title($subscription->subscribtion_id);
                    ?>
                    <div class="wpdiscuz-bpi-item wpd-bp-sbs" data-wpd-bpi-subscription-id="<?php echo $subscription->id; ?>">
                        <div class="wpdiscuz-bpi-item-icon">
                            <svg style="enable-background:new 0 0 32 32;" version="1.1" viewBox="0 0 32 32" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><style type="text/css">.st0{fill:none;stroke: #888888;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:10;}  .st1{fill:none;stroke: #888888;stroke-width:2;stroke-linejoin:round;stroke-miterlimit:10;}</style><polyline class="st0" points="3,10 16,18 29,10 "/><path class="st0" d="M25,5H7C4.8,5,3,6.8,3,9v14c0,2.2,1.8,4,4,4h2v4l0,0c3.9-2.6,8.5-4,13.2-4H25c2.2,0,4-1.8,4-4V9  C29,6.8,27.2,5,25,5z"/></svg>
                        </div>
                        <div class="wpdiscuz-bpi-item-left">
                            <div class="wpdiscuz-bpi-item-left-primary">
                                <div class="wpdiscuz-bpi-post-link-wrapper">
                                    <a class="wpdiscuz-bpi-post-link" href="<?php echo esc_url_raw(get_the_permalink($post)); ?>" target="_blank" title="<?php echo esc_attr($title); ?>">
                                        <?php echo esc_html($title); ?>
                                    </a>
                                </div>
                                <div class="wpdiscuz-bpi-item-link-wrapper">
                                    <span><?php echo $subscription->subscribtion_type === WpdiscuzCore::SUBSCRIPTION_ALL_COMMENT ? esc_html__("Subscribed to replies on comments", "wpdiscuz-buddypress-integration") : esc_html__("Subscribed to all follow-up comments of this post", "wpdiscuz-buddypress-integration"); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="wpdiscuz-bpi-item-right">
                            <?php
                            if ($isMyProfile) {
                                ?>
                                <div class="wpdiscuz-bpi-unsubscribe">
                                    <a href="#"><?php _e("Unsubscribe", "wpdiscuz-buddypress-integration") ?></a>
                                </div>
                                <?php
                                }
                            ?>
                            <div class="wpdiscuz-bpi-item-date">
                                <?php echo esc_html($wpdiscuz->helper->dateDiff($subscription->subscription_date)); ?>
                            </div>
                        </div>
                    </div>
                    <?php
                }
            }
            include WPD_BPI_PATH . "/includes/profile-tabs/pagination.php";
        } else {
            ?>
            <div class='wpdiscuz-bpi-item'><?php esc_html_e("No subscriptions found", "wpdiscuz-buddypress-integration"); ?></div>
            <?php
        }
    } else {
        ?>
        <div class='wpdiscuz-bpi-item'><?php esc_html_e("No subscriptions found", "wpdiscuz-buddypress-integration"); ?></div>
        <?php
    }
} else {
	?>
    <div class='wpdiscuz-bpi-item'><?php esc_html_e("No subscriptions found", "wpdiscuz-buddypress-integration"); ?></div>
	<?php
}