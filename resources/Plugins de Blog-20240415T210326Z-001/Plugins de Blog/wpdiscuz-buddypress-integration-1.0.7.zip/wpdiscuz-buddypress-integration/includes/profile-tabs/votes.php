<?php
if (!defined("ABSPATH")) {
	exit();
}
$displayedUser = bp_get_displayed_user();
if (!empty($displayedUser->userdata->ID)) {
    $wpdiscuz = wpDiscuz();
    $votesCount = $this->dbmanager->getVotesCount($displayedUser->userdata->ID, $wpdiscuz->options->login["isUserByEmail"] ? $displayedUser->userdata->user_email : "");
    if ($votesCount) {
        $page = !empty($_GET["page"]) ? intval($_GET["page"]) : 1;
        $perPage = apply_filters("wpdiscuz_bpi_votes_per_page", 10);
        $pagesCount = ceil($votesCount / $perPage);
        if ($page < 1) {
            $page = 1;
        } else if ($page > $pagesCount) {
            $page = $pagesCount;
        }
        $votes = $this->dbmanager->getVotes($displayedUser->userdata->ID, ($wpdiscuz->options->login["isUserByEmail"] ? $displayedUser->userdata->user_email : ""), $perPage, ($page - 1) * $perPage);
        if ($votes) {
            foreach ($votes as $key => $vote) {
                $comment = get_comment($vote->comment_id);
				$voter = get_user_by("id", $vote->user_id);
                ?>
                <div class="wpdiscuz-bpi-item wpd-bp-votes">
                    <div class="wpdiscuz-bpi-item-icon">
                        <?php
                        if ($voter) {
                            ?>
                            <a class="wpdiscuz-bpi-avatar-wrapper" href="<?php echo esc_url_raw(bp_core_get_user_domain($voter->ID)); ?>" target="_blank" title="<?php echo esc_attr($voter->display_name); ?>">
                                <?php echo get_avatar($voter->ID, 56, "", $voter->display_name, ["wpdiscuz_current_user" => $voter, "wpdiscuz_gravatar_user_email" => $voter->user_email]); ?>
                            </a>
                            <?php
                        } else {
							echo get_avatar(0, 56, "", esc_attr__($this->options->guestPhrase, "wpdiscuz-buddypress-integration"), ["wpdiscuz_current_user" => "", "wpdiscuz_gravatar_user_email" => uniqid() . "@example.com"]);
						}
						?>
                    </div>
                    <div class="wpdiscuz-bpi-item-left">
                        <div class="wpdiscuz-bpi-item-left-primary">
                            <div class="wpdiscuz-bpi-post-link-wrapper">
                                <?php
                                if ($voter) {
                                    ?>
                                    <span class="wpdiscuz-bpi-post-link" title="<?php echo esc_attr($voter->display_name); ?>">
                                        <?php echo esc_html($voter->display_name); ?>
                                    </span>
                                    <?php
                                } else {
                                    ?>
                                    <span class="wpdiscuz-bpi-post-link" title="<?php esc_attr_e($this->options->guestPhrase, "wpdiscuz-buddypress-integration"); ?>">
                                        <?php esc_attr_e($this->options->guestPhrase, "wpdiscuz-buddypress-integration"); ?>
                                    </span>
                                    <?php
                                }
                                ?>
                            </div>
                            <div class="wpdiscuz-bpi-item-link-wrapper">
                                <a class="wpdiscuz-bpi-item-link" href="<?php echo esc_url_raw(get_comment_link($comment)); ?>" target="_blank">
                                    <?php echo wp_trim_words(apply_filters("comment_text", $comment->comment_content, $comment, ["is_wpdiscuz_comment" => true]), 15, "&hellip;"); ?>
                                </a>
                            </div>
                        </div>
                        <div class="wpdiscuz-bpi-item-left-secondary">
                            <?php
                            if ($vote->vote_type > 0) {
                                ?>
                                <svg xmlns="https://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" color="#118b26" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-thumbs-up"><path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3"></path></svg>
                                <?php
                            } else {
                                ?>
                                <svg xmlns="https://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" color="#e8484a" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-thumbs-down"><path d="M10 15v4a3 3 0 0 0 3 3l4-9V2H5.72a2 2 0 0 0-2 1.7l-1.38 9a2 2 0 0 0 2 2.3zm7-13h2.67A2.31 2.31 0 0 1 22 4v7a2.31 2.31 0 0 1-2.33 2H17"></path></svg>
                                <?php
                            }
                            ?>
                        </div>
                    </div>
                    <div class="wpdiscuz-bpi-item-right">
                        <div class="wpdiscuz-bpi-item-date">
                            <?php echo esc_html($wpdiscuz->helper->dateDiff(date("Y-m-d H:i:s", $vote->date))); ?>
                        </div>
                    </div>
                </div>
                <?php
            }
            include WPD_BPI_PATH . "/includes/profile-tabs/pagination.php";
        } else {
            ?>
            <div class='wpdiscuz-bpi-item'><?php esc_html_e("Nobody has reacted yet", "wpdiscuz-buddypress-integration"); ?></div>
            <?php
        }
    } else {
        ?>
        <div class='wpdiscuz-bpi-item'><?php esc_html_e("Nobody has reacted yet", "wpdiscuz-buddypress-integration"); ?></div>
        <?php
    }
} else {
	?>
	<div class='wpdiscuz-bpi-item'><?php esc_html_e("Nobody has reacted yet", "wpdiscuz-buddypress-integration"); ?></div>
	<?php
}