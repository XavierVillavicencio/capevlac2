<?php
if (!defined("ABSPATH")) {
	exit();
}

class wpDiscuzBPINotifications implements wpDiscuzBPIConstants {

	private $options;
	private $dbmanager;

	public function __construct($options, $dbmanager) {
		$this->options = $options;
		$this->dbmanager = $dbmanager;
		/* COMMENT VOTE */
		add_action("wpdiscuz_add_vote", [$this, "addVote"], 999, 2);
		add_action("wpdiscuz_update_vote", [$this, "updateVote"], 999, 3);
		add_action("wpdiscuz_remove_vote_data", [$this, "removeVoteData"], 999);
		/* /COMMENT VOTE */
		/* FOLLOW */
		add_action("wpdiscuz_follow_added", [$this, "addFollow"], 999);
		add_action("wpdiscuz_follow_cancelled", [$this, "removeFollow"], 999);
		/* /FOLLOW */
		/* POST RATING */
		add_action("wpdiscuz_add_rating", [$this, "addRating"], 999, 2);
		add_action("wpdiscuz_clean_post_cache", [$this, "removeRatings"], 999, 2);
		add_action("deleted_post", [$this, "postDeleted"], 999);
		/* /POST RATING */
		/* APPROVED COMMENT */
		add_filter("wpdiscuz_send_email_on_approving", [$this, "approvedComment"], 999, 3);
		/* /APPROVED COMMENT */
		/* MENTION */
		add_filter("wpducm_mail_to_mentioned_user", [$this, "mention"], 999, 3);
		/* /MENTION */
		/* COMMENT POSTED */
		add_action("comment_post", [$this, "commentPosted"], 999, 3);
		/* /COMMENT POSTED */
		/* SUBSCRIPTIONS */
		add_filter("wpdiscuz_email_notification", [$this, "subscriptions"], 999, 3);
		/* /SUBSCRIPTIONS */
		/* FOLLOWS */
		add_filter("wpdiscuz_follow_email_notification", [$this, "follows"], 999, 3);
		/* /FOLLOWS */
		/* COMMON */
		add_action("deleted_user", [$this, "userDeleted"], 999, 3);
		add_action("transition_comment_status", [$this, "commentStatusChanged"], 999, 3);
		add_action("deleted_comment", [$this, "commentDeleted"], 999, 2);
		add_filter("bp_notifications_get_notifications_for_user", [$this, "bpNotifications"], 999, 8);
		add_action("bp_notification_before_delete", [$this, "deleteNotificationMeta"], 999);
		add_action("init", [$this, "markNotificationRead"]);
		add_filter("bp_notifications_get_registered_components", [$this, "addBpComponent"], 999);
		/* /COMMON */
		/* SETTINGS */
		add_action("bp_setup_nav", [&$this, "notificationSettingsTab"], 100);
		add_action("init", [&$this, "saveNotificationSettings"], 100);
		/* /SETTINGS */
	}

	/* COMMENT VOTE */
	public function addVote($voteType, $comment) {
		if ($comment->user_id) {
			$currentUser = WpdiscuzHelper::getCurrentUser();
			if ($this->options->notificationForCommentVote) {
				$notificationForCommentVote = get_user_meta($comment->user_id, self::USER_META_NOTIFICATION_FOR_COMMENT_VOTE, true);
				if (!is_numeric($notificationForCommentVote)) {
					$notificationForCommentVote = $this->options->notificationForCommentVoteForNewUsers;
				}
				if ($notificationForCommentVote) {
					$notification_id = bp_notifications_add_notification([
						"user_id" => $comment->user_id,
						"item_id" => $comment->comment_ID,
						"secondary_item_id" => $currentUser->ID,
						"component_name" => self::COMPONENT_NAME,
						"component_action" => $voteType > 0 ? self::COMPONENT_ACTION_COMMENT_UPVOTE : self::COMPONENT_ACTION_COMMENT_DOWNVOTE,
						"date_notified" => bp_core_current_time(),
						"is_new" => 1,
					]);
					if ($notification_id && !$currentUser->ID) {
						bp_notifications_add_meta($notification_id, self::NOTIFICATION_META_AUTHOR_IP, md5(WpdiscuzHelper::getRealIPAddr()), true);
					}
				}
			}
			if ($this->options->emailForCommentVote) {
				$emailForCommentVote = get_user_meta($comment->user_id, self::USER_META_EMAIL_FOR_COMMENT_VOTE, true);
				if (!is_numeric($emailForCommentVote)) {
					$emailForCommentVote = $this->options->emailForCommentVoteForNewUsers;
				}
				if ($emailForCommentVote) {
					if ($voter = get_user_by("id", $currentUser->ID)) {
						$voterName = $voter->display_name;
						$voterUrl = bp_core_get_user_domain($voter->ID);
					} else {
						$voterName = esc_html__($this->options->guestPhrase, "wpdiscuz-buddypress-integration");
						$voterUrl = "";
					}
					$blogTitle = get_option("blogname");
					$postTitle = get_the_title($comment->comment_post_ID);
					$subject = html_entity_decode(str_replace(["[VOTER_NAME]", "[POST_TITLE]", "[BLOG_TITLE]"], [$voterName, $postTitle, $blogTitle], $voteType > 0 ? $this->options->upvoteEmailSubject : $this->options->downvoteEmailSubject), ENT_QUOTES);
					$message = str_replace(["[SUBSCRIBER_NAME]", "[VOTER_NAME]", "[VOTER_URL]", "[COMMENT_URL]", "[POST_TITLE]", "[BLOG_TITLE]", "[SITE_URL]", "[NOTIFICATIONS_PAGE_URL]"], [$comment->comment_author, $voterName, $voterUrl, get_comment_link($comment), $postTitle, $blogTitle, get_site_url(), bp_get_notifications_permalink($comment->user_id) . "settings/"], $voteType > 0 ? $this->options->upvoteEmailMessage : $this->options->downvoteEmailMessage);
					wp_mail($comment->comment_author_email, $subject, $message, $this->getMailHeaders());
				}
			}
		}
	}

	public function updateVote($voteType, $isUserVoted, $comment) {
		if ($comment->user_id) {
			$currentUser = WpdiscuzHelper::getCurrentUser();
			$totalVote = $voteType + $isUserVoted;
			if ($totalVote === 0) {
				if ($currentUser->ID) {
					bp_notifications_delete_all_notifications_by_type($comment->comment_ID, self::COMPONENT_NAME, $isUserVoted > 0 ? self::COMPONENT_ACTION_COMMENT_UPVOTE : self::COMPONENT_ACTION_COMMENT_DOWNVOTE, $currentUser->ID);
				} else {
					$this->dbmanager->deleteGuestVoteNotification($comment->comment_ID, $isUserVoted > 0 ? self::COMPONENT_ACTION_COMMENT_UPVOTE : self::COMPONENT_ACTION_COMMENT_DOWNVOTE, md5(WpdiscuzHelper::getRealIPAddr()));
				}
			} else if ($this->options->notificationForCommentVote) {
				$notificationForCommentVote = get_user_meta($comment->user_id, self::USER_META_NOTIFICATION_FOR_COMMENT_VOTE, true);
				if (!is_numeric($notificationForCommentVote)) {
					$notificationForCommentVote = $this->options->notificationForCommentVoteForNewUsers;
				}
				if ($notificationForCommentVote) {
					$notification_id = bp_notifications_add_notification([
						"user_id" => $comment->user_id,
						"item_id" => $comment->comment_ID,
						"secondary_item_id" => $currentUser->ID,
						"component_name" => self::COMPONENT_NAME,
						"component_action" => $totalVote > 0 ? self::COMPONENT_ACTION_COMMENT_UPVOTE : self::COMPONENT_ACTION_COMMENT_DOWNVOTE,
						"date_notified" => bp_core_current_time(),
						"is_new" => 1,
					]);
					if ($notification_id && !$currentUser->ID) {
						bp_notifications_add_meta($notification_id, self::NOTIFICATION_META_AUTHOR_IP, md5(WpdiscuzHelper::getRealIPAddr()), true);
					}
				}
			}
			if ($this->options->emailForCommentVote && $totalVote !== 0) {
				$emailForCommentVote = get_user_meta($comment->user_id, self::USER_META_EMAIL_FOR_COMMENT_VOTE, true);
				if (!is_numeric($emailForCommentVote)) {
					$emailForCommentVote = $this->options->emailForCommentVoteForNewUsers;
				}
				if ($emailForCommentVote) {
					if ($voter = get_user_by("id", $currentUser->ID)) {
						$voterName = $voter->display_name;
						$voterUrl = bp_core_get_user_domain($voter->ID);
					} else {
						$voterName = esc_html__($this->options->guestPhrase, "wpdiscuz-buddypress-integration");
						$voterUrl = "";
					}
					$blogTitle = get_option("blogname");
					$postTitle = get_the_title($comment->comment_post_ID);
					$subject = html_entity_decode(str_replace(["[VOTER_NAME]", "[POST_TITLE]", "[BLOG_TITLE]"], [$voterName, $postTitle, $blogTitle], $totalVote > 0 ? $this->options->upvoteEmailSubject : $this->options->downvoteEmailSubject), ENT_QUOTES);
					$message = str_replace(["[SUBSCRIBER_NAME]", "[VOTER_NAME]", "[VOTER_URL]", "[COMMENT_URL]", "[POST_TITLE]", "[BLOG_TITLE]", "[SITE_URL]", "[NOTIFICATIONS_PAGE_URL]"], [$comment->comment_author, $voterName, $voterUrl, get_comment_link($comment), $postTitle, $blogTitle, get_site_url(), bp_get_notifications_permalink($comment->user_id) . "settings/"], $totalVote > 0 ? $this->options->upvoteEmailMessage : $this->options->downvoteEmailMessage);
					wp_mail($comment->comment_author_email, $subject, $message, $this->getMailHeaders());
				}
			}
		}
	}

	public function removeVoteData() {
		$this->dbmanager->deleteNotificationsByType([self::COMPONENT_ACTION_COMMENT_UPVOTE, self::COMPONENT_ACTION_COMMENT_DOWNVOTE]);
	}

	private function getCommentUpvoteNotification($action, $item_id, $secondary_item_id, $total_items, $format, $real_action, $component_name, $notification_id) {
		if ($voter = get_user_by("id", $secondary_item_id)) {
			$voterName = $voter->display_name;
			$voterUrl = bp_core_get_user_domain($voter->ID);
		} else {
			$voterName = esc_html__($this->options->guestPhrase, "wpdiscuz-buddypress-integration");
			$voterUrl = "";
		}
		$text = str_replace(["[VOTER_NAME]", "[VOTER_URL]", "[COMMENT_URL]"], [$voterName, $voterUrl, get_comment_link($item_id),], __($this->options->commentUpvoteNotificationMessage, "wpdiscuz-buddypress-integration"));
		if ("string" === $format) {
			return $text;
		} else if ($total_items === 1) {
			return [
				"text" => strip_tags($text),
				"link" => wp_nonce_url(str_replace("#comment", "?action=" . self::MARK_NOTIFICATION_READ . "&notificationid=$notification_id#comment", get_comment_link($item_id)), self::MARK_NOTIFICATION_READ . "_" . $notification_id),
			];
		} else {
			$text = sprintf(__($this->options->multipleCommentUpvoteNotificationsMessage, "wpdiscuz-buddypress-integration"), $total_items);
			return [
				"text" => strip_tags($text),
				"link" => bp_get_notifications_permalink(),
			];
		}
	}

	private function getCommentDownvoteNotification($action, $item_id, $secondary_item_id, $total_items, $format, $real_action, $component_name, $notification_id) {
		if ($voter = get_user_by("id", $secondary_item_id)) {
			$voterName = $voter->display_name;
			$voterUrl = bp_core_get_user_domain($voter->ID);
		} else {
			$voterName = esc_html__($this->options->guestPhrase, "wpdiscuz-buddypress-integration");
			$voterUrl = "";
		}
		$text = str_replace(["[VOTER_NAME]", "[VOTER_URL]", "[COMMENT_URL]"], [$voterName, $voterUrl, get_comment_link($item_id),], __($this->options->commentDownvoteNotificationMessage, "wpdiscuz-buddypress-integration"));
		if ("string" === $format) {
			return $text;
		} else if ($total_items === 1) {
			return [
				"text" => strip_tags($text),
				"link" => wp_nonce_url(str_replace("#comment", "?action=" . self::MARK_NOTIFICATION_READ . "&notificationid=$notification_id#comment", get_comment_link($item_id)), self::MARK_NOTIFICATION_READ . "_" . $notification_id),
			];
		} else {
			$text = sprintf(__($this->options->multipleCommentDownvoteNotificationsMessage, "wpdiscuz-buddypress-integration"), $total_items);
			return [
				"text" => strip_tags($text),
				"link" => bp_get_notifications_permalink(),
			];
		}
	}
	/* /COMMENT VOTE */

	/* FOLLOW */
	public function addFollow($args) {
		if (($follower = get_user_by("id", $args["follower_id"])) && ($user = get_user_by("id", $args["user_id"]))) {
			if ($this->options->notificationForFollow) {
				$notificationForFollow = get_user_meta($user->ID, self::USER_META_NOTIFICATION_FOR_FOLLOW, true);
				if (!is_numeric($notificationForFollow)) {
					$notificationForFollow = $this->options->notificationForFollowForNewUsers;
				}
				if ($notificationForFollow) {
					bp_notifications_add_notification([
						"user_id" => $user->ID,
						"item_id" => $user->ID,
						"secondary_item_id" => $follower->ID,
						"component_name" => self::COMPONENT_NAME,
						"component_action" => self::COMPONENT_ACTION_FOLLOW,
						"date_notified" => bp_core_current_time(),
						"is_new" => 1,
					]);
				}
			}
			if ($this->options->emailForFollow) {
				$emailForFollow = get_user_meta($user->ID, self::USER_META_EMAIL_FOR_FOLLOW, true);
				if (!is_numeric($emailForFollow)) {
					$emailForFollow = $this->options->emailForFollowForNewUsers;
				}
				if ($emailForFollow) {
					$blogTitle = get_option("blogname");
					$subject = html_entity_decode(str_replace(["[FOLLOWER_NAME]", "[BLOG_TITLE]"], [$follower->display_name, $blogTitle], $this->options->followEmailSubject), ENT_QUOTES);
					$message = str_replace(["[SUBSCRIBER_NAME]", "[FOLLOWER_NAME]", "[FOLLOWER_URL]", "[BLOG_TITLE]", "[SITE_URL]", "[NOTIFICATIONS_PAGE_URL]"], [$user->display_name, $follower->display_name, bp_core_get_user_domain($follower->ID), $blogTitle, get_site_url(), bp_get_notifications_permalink($user->ID) . "settings/"], $this->options->followEmailMessage);
					wp_mail($user->user_email, $subject, $message, $this->getMailHeaders());
				}
			}
		}
	}

	public function removeFollow($args) {
		if ($this->options->notificationForFollow && $args["follower_id"] && $args["user_id"]) {
			bp_notifications_delete_all_notifications_by_type($args["user_id"], self::COMPONENT_NAME, self::COMPONENT_ACTION_FOLLOW, $args["follower_id"]);
		}
	}

	private function getFollowNotification($action, $item_id, $secondary_item_id, $total_items, $format, $real_action, $component_name, $notification_id) {
		if ($follower = get_user_by("id", $secondary_item_id)) {
			$text = str_replace(["[FOLLOWER_NAME]", "[FOLLOWER_URL]"], [$follower->display_name, bp_core_get_user_domain($secondary_item_id),], __($this->options->followNotificationMessage, "wpdiscuz-buddypress-integration"));
			if ("string" === $format) {
				return $text;
			} else if ($total_items === 1) {
				return [
					"text" => strip_tags($text),
					"link" => wp_nonce_url(bp_core_get_user_domain($secondary_item_id) . "?action=" . self::MARK_NOTIFICATION_READ . "&notificationid=$notification_id", self::MARK_NOTIFICATION_READ . "_" . $notification_id),
				];
			} else {
				$text = sprintf(__($this->options->multipleFollowNotificationsMessage, "wpdiscuz-buddypress-integration"), $total_items);
				return [
					"text" => strip_tags($text),
					"link" => bp_get_notifications_permalink(),
				];
			}
		}
		return "";
	}
	/* /FOLLOW */

	/* POST RATING */
	public function addRating($rating, $post_id) {
		$post = get_post($post_id);
		$currentUser = WpdiscuzHelper::getCurrentUser();
		if ($currentUser->ID != $post->post_author) {
			if ($this->options->notificationForPostRating) {
				$notificationForPostRatingVote = get_user_meta($post->post_author, self::USER_META_NOTIFICATION_FOR_POST_RATING, true);
				if (!is_numeric($notificationForPostRatingVote)) {
					$notificationForPostRatingVote = $this->options->notificationForPostRatingForNewUsers;
				}
				if ($notificationForPostRatingVote) {
					$notification_id = bp_notifications_add_notification([
						"user_id" => $post->post_author,
						"item_id" => $post->ID,
						"secondary_item_id" => $currentUser->ID,
						"component_name" => self::COMPONENT_NAME,
						"component_action" => self::COMPONENT_ACTION_POST_RATING,
						"date_notified" => bp_core_current_time(),
						"is_new" => 1,
					]);
					bp_notifications_add_meta($notification_id, self::NOTIFICATION_META_POST_RATING, $rating, true);
					if ($notification_id && !$currentUser->ID) {
						bp_notifications_add_meta($notification_id, self::NOTIFICATION_META_AUTHOR_IP, md5(WpdiscuzHelper::getRealIPAddr()), true);
					}
				}
			}
			if ($this->options->emailForPostRating) {
				$emailForPostRating = get_user_meta($post->post_author, self::USER_META_EMAIL_FOR_POST_RATING, true);
				if (!is_numeric($emailForPostRating)) {
					$emailForPostRating = $this->options->emailForPostRatingForNewUsers;
				}
				if ($emailForPostRating) {
					if ($rater = get_user_by("id", $currentUser->ID)) {
						$raterName = $rater->display_name;
						$raterUrl = bp_core_get_user_domain($rater->ID);
					} else {
						$raterName = esc_html__($this->options->guestPhrase, "wpdiscuz-buddypress-integration");
						$raterUrl = "";
					}
					$user = get_user_by("id", $post->post_author);
					$blogTitle = get_option("blogname");
					$subject = html_entity_decode(str_replace(["[RATER_NAME]", "[RATING]", "[POST_TITLE]", "[BLOG_TITLE]"], [$raterName, $rating, $post->post_title, $blogTitle], $this->options->postRatingEmailSubject), ENT_QUOTES);
					$message = str_replace(["[SUBSCRIBER_NAME]", "[RATER_NAME]", "[RATER_URL]", "[RATING]", "[POST_TITLE]", "[POST_URL]", "[BLOG_TITLE]", "[SITE_URL]", "[NOTIFICATIONS_PAGE_URL]"], [$user->display_name, $raterName, $raterUrl, $rating, $post->post_title, get_the_permalink($post), $blogTitle, get_site_url(), bp_get_notifications_permalink($user->ID) . "settings/"], $this->options->postRatingEmailMessage);
					wp_mail($user->user_email, $subject, $message, $this->getMailHeaders());
				}
			}
		}
	}

	public function removeRatings($postId, $action) {
		if ($action === "ratings_reset") {
			$this->dbmanager->deleteNotifications($postId, [self::COMPONENT_ACTION_POST_RATING]);
		}
	}

	public function postDeleted($postId) {
		$this->dbmanager->deleteNotifications($postId, [self::COMPONENT_ACTION_POST_RATING]);
	}

	private function getPostRatingNotification($action, $item_id, $secondary_item_id, $total_items, $format, $real_action, $component_name, $notification_id) {
		if ($rater = get_user_by("id", $secondary_item_id)) {
			$raterName = $rater->display_name;
			$raterUrl = bp_core_get_user_domain($rater->ID);
		} else {
			$raterName = esc_html__($this->options->guestPhrase, "wpdiscuz-buddypress-integration");
			$raterUrl = "";
		}
		$text = str_replace(["[RATER_NAME]", "[RATER_URL]", "[POST_TITLE]", "[POST_URL]", "[RATING]"], [$raterName, $raterUrl, get_the_title($item_id), get_the_permalink($item_id), bp_notifications_get_meta($notification_id, self::NOTIFICATION_META_POST_RATING, true)], __($this->options->postRatingNotificationMessage, "wpdiscuz-buddypress-integration"));
		if ("string" === $format) {
			return $text;
		} else if ($total_items === 1) {
			$url = get_the_permalink($item_id);
			return [
				"text" => strip_tags($text),
				"link" => wp_nonce_url($url . (parse_url($url, PHP_URL_QUERY) ? "&" : "?") . "action=" . self::MARK_NOTIFICATION_READ . "&notificationid=$notification_id", self::MARK_NOTIFICATION_READ . "_" . $notification_id),
			];
		} else {
			$text = sprintf(__($this->options->multiplePostRatingNotificationsMessage, "wpdiscuz-buddypress-integration"), $total_items);
			return [
				"text" => strip_tags($text),
				"link" => bp_get_notifications_permalink(),
			];
		}
	}
	/* /POST RATING */

	/* APPROVED COMMENT */
	public function approvedComment($sendEmail, $email, $comment) {
		$currentUser = WpdiscuzHelper::getCurrentUser();
		if ($comment->user_id && $currentUser->ID != $comment->user_id) {
			$sendEmail = false;
			if ($this->options->emailForApprovedComment) {
				$emailForApprovedComment = get_user_meta($comment->user_id, self::USER_META_EMAIL_FOR_APPROVED_COMMENT, true);
				if (!is_numeric($emailForApprovedComment)) {
					$emailForApprovedComment = $this->options->emailForApprovedCommentForNewUsers;
				}
				$sendEmail = (bool) $emailForApprovedComment;
			}
		}
		return $sendEmail;
	}

	public function commentIsApproved($comment) {
		$currentUser = WpdiscuzHelper::getCurrentUser();
		if ($comment->user_id && $currentUser->ID != $comment->user_id) {
			if ($this->options->notificationForApprovedComment) {
				$notificationForApprovedComment = get_user_meta($comment->user_id, self::USER_META_NOTIFICATION_FOR_APPROVED_COMMENT, true);
				if (!is_numeric($notificationForApprovedComment)) {
					$notificationForApprovedComment = $this->options->notificationForApprovedCommentForNewUsers;
				}
				if ($notificationForApprovedComment) {
					bp_notifications_add_notification([
						"user_id" => $comment->user_id,
						"item_id" => $comment->comment_ID,
						"component_name" => self::COMPONENT_NAME,
						"component_action" => self::COMPONENT_ACTION_APPROVED_COMMENT,
						"date_notified" => bp_core_current_time(),
						"is_new" => 1,
					]);
				}
			}
		}
	}

	private function getApprovedCommentNotification($action, $item_id, $secondary_item_id, $total_items, $format, $real_action, $component_name, $notification_id) {
		$text = str_replace(["[COMMENT_URL]"], [get_comment_link($item_id)], __($this->options->approvedCommentNotificationMessage, "wpdiscuz-buddypress-integration"));
		if ("string" === $format) {
			return $text;
		} else if ($total_items === 1) {
			return [
				"text" => strip_tags($text),
				"link" => wp_nonce_url(str_replace("#comment", "?action=" . self::MARK_NOTIFICATION_READ . "&notificationid=$notification_id#comment", get_comment_link($item_id)), self::MARK_NOTIFICATION_READ . "_" . $notification_id),
			];
		} else {
			$text = sprintf(__($this->options->multipleApprovedCommentNotificationsMessage, "wpdiscuz-buddypress-integration"), $total_items);
			return [
				"text" => strip_tags($text),
				"link" => bp_get_notifications_permalink(),
			];
		}
	}
	/* /APPROVED COMMENT */

	/* MENTION */
	public function mention($sendEmail, $user, $comment) {
		if ($mentionedUser = get_user_by("id", $user["u_id"])) {
			if ($mentionedUser->ID != $comment->user_id) {
				if ($this->options->notificationForMention) {
					$notificationForMention = get_user_meta($mentionedUser->ID, self::USER_META_NOTIFICATION_FOR_MENTION, true);
					if (!is_numeric($notificationForMention)) {
						$notificationForMention = $this->options->notificationForMentionForNewUsers;
					}
					$commenter_ip = md5($comment->comment_author_IP);
					if ($notificationForMention && !$this->dbmanager->ifNotificationExists($mentionedUser->ID, $comment->comment_ID, $comment->user_id, [self::COMPONENT_ACTION_COMMENT_ON_POST, self::COMPONENT_ACTION_REPLY, self::COMPONENT_ACTION_SUBSCRIPTIONS, self::COMPONENT_ACTION_FOLLOWS], $commenter_ip)) {
						$notification_id = bp_notifications_add_notification([
							"user_id" => $mentionedUser->ID,
							"item_id" => $comment->comment_ID,
							"secondary_item_id" => $comment->user_id,
							"component_name" => self::COMPONENT_NAME,
							"component_action" => self::COMPONENT_ACTION_MENTION,
							"date_notified" => bp_core_current_time(),
							"is_new" => 1,
						]);
						if ($notification_id && !$comment->user_id) {
							bp_notifications_add_meta($notification_id, self::NOTIFICATION_META_AUTHOR_IP, $commenter_ip, true);
						}
					}
				}
				$sendEmail = false;
				if ($this->options->emailForMention) {
					$emailForMention = get_user_meta($mentionedUser->ID, self::USER_META_EMAIL_FOR_MENTION, true);
					if (!is_numeric($emailForMention)) {
						$emailForMention = $this->options->emailForMentionForNewUsers;
					}
					$sendEmail = (bool) $emailForMention;
				}
			}
		}
		return $sendEmail;
	}

	private function getMentionNotification($action, $item_id, $secondary_item_id, $total_items, $format, $real_action, $component_name, $notification_id) {
		if ($mentioner = get_user_by("id", $secondary_item_id)) {
			$mentionerName = $mentioner->display_name;
			$mentionerUrl = bp_core_get_user_domain($mentioner->ID);
		} else {
			$comment = get_comment($item_id);
			$mentionerName = $comment->comment_author;
			$mentionerUrl = $comment->comment_author_url;
		}
		$text = str_replace(["[COMMENT_URL]", "[AUTHOR_NAME]", "[AUTHOR_URL]"], [get_comment_link($item_id), $mentionerName, $mentionerUrl], __($this->options->mentionNotificationMessage, "wpdiscuz-buddypress-integration"));
		if ("string" === $format) {
			return $text;
		} else if ($total_items === 1) {
			return [
				"text" => strip_tags($text),
				"link" => wp_nonce_url(str_replace("#comment", "?action=" . self::MARK_NOTIFICATION_READ . "&notificationid=$notification_id#comment", get_comment_link($item_id)), self::MARK_NOTIFICATION_READ . "_" . $notification_id),
			];
		} else {
			$text = sprintf(__($this->options->multipleMentionNotificationsMessage, "wpdiscuz-buddypress-integration"), $total_items);
			return [
				"text" => strip_tags($text),
				"link" => bp_get_notifications_permalink(),
			];
		}
	}
	/* /MENTION */

	/* COMMENT POSTED */
	public function commentPosted($comment_ID, $comment_approved, $commentdata) {
		if ($comment_approved == 1) {
			$this->reply($comment_ID, $comment_approved, $commentdata);
			$this->commentOnPost($comment_ID, $comment_approved, $commentdata);
		}
	}

	/* REPLY */
	private function reply($comment_ID, $comment_approved, $commentdata) {
		if (($parentComment = get_comment($commentdata["comment_parent"])) && $parentComment->user_id && $parentComment->user_id != $commentdata["user_id"]) {
			if ($this->options->notificationForReply) {
				$notificationForReply = get_user_meta($parentComment->user_id, self::USER_META_NOTIFICATION_FOR_REPLY, true);
				if (!is_numeric($notificationForReply)) {
					$notificationForReply = $this->options->notificationForReplyForNewUsers;
				}
				$commenter_ip = md5($commentdata["comment_author_IP"]);
				if ($notificationForReply && !$this->dbmanager->ifNotificationExists($parentComment->user_id, $comment_ID, $commentdata["user_id"], [self::COMPONENT_ACTION_COMMENT_ON_POST, self::COMPONENT_ACTION_MENTION, self::COMPONENT_ACTION_SUBSCRIPTIONS, self::COMPONENT_ACTION_FOLLOWS], $commenter_ip)) {
					$notification_id = bp_notifications_add_notification([
						"user_id" => $parentComment->user_id,
						"item_id" => $comment_ID,
						"secondary_item_id" => $commentdata["user_id"],
						"component_name" => self::COMPONENT_NAME,
						"component_action" => self::COMPONENT_ACTION_REPLY,
						"date_notified" => bp_core_current_time(),
						"is_new" => 1,
					]);
					if ($notification_id && !$commentdata["user_id"]) {
						bp_notifications_add_meta($notification_id, self::NOTIFICATION_META_AUTHOR_IP, $commenter_ip, true);
					}
				}
			}
			if ($this->options->emailForReply) {
				$emailForReply = get_user_meta($parentComment->user_id, self::USER_META_EMAIL_FOR_REPLY, true);
				if (!is_numeric($emailForReply)) {
					$emailForReply = $this->options->emailForReplyForNewUsers;
				}
				if ($emailForReply) {
					if ($commenter = get_user_by("id", $commentdata["user_id"])) {
						$commenterName = $commenter->display_name;
						$commenterUrl = bp_core_get_user_domain($commenter->ID);
					} else {
						$commenterName = $commentdata["comment_author"];
						$commenterUrl = $commentdata["comment_author_url"];
					}
					$blogTitle = get_option("blogname");
					$postTitle = get_the_title($parentComment->comment_post_ID);
					$subject = html_entity_decode(str_replace(["[AUTHOR_NAME]", "[POST_TITLE]", "[BLOG_TITLE]"], [$commenterName, $postTitle, $blogTitle], $this->options->replyEmailSubject), ENT_QUOTES);
					$message = str_replace(["[SUBSCRIBER_NAME]", "[AUTHOR_NAME]", "[AUTHOR_URL]", "[COMMENT_URL]", "[POST_TITLE]", "[POST_URL]", "[BLOG_TITLE]", "[SITE_URL]", "[NOTIFICATIONS_PAGE_URL]"], [$parentComment->comment_author, $commenterName, $commenterUrl, get_comment_link($comment_ID), $postTitle, get_the_permalink($parentComment->comment_post_ID), $blogTitle, get_site_url(), bp_get_notifications_permalink($parentComment->user_id) . "settings/"], $this->options->replyEmailMessage);
					wp_mail($parentComment->comment_author_email, $subject, $message, $this->getMailHeaders());
				}
			}
		}
	}

	private function getReplyNotification($action, $item_id, $secondary_item_id, $total_items, $format, $real_action, $component_name, $notification_id) {
		$comment = get_comment($item_id);
		if ($commenter = get_user_by("id", $secondary_item_id)) {
			$commenterName = $commenter->display_name;
			$commenterUrl = bp_core_get_user_domain($commenter->ID);
		} else {
			$commenterName = $comment->comment_author;
			$commenterUrl = $comment->comment_author_url;
		}
		$text = str_replace(["[COMMENT_URL]", "[AUTHOR_NAME]", "[AUTHOR_URL]", "[POST_TITLE]", "[POST_URL]"], [get_comment_link($item_id), $commenterName, $commenterUrl, get_the_title($comment->comment_post_ID), get_the_permalink($comment->comment_post_ID)], __($this->options->replyNotificationMessage, "wpdiscuz-buddypress-integration"));
		if ("string" === $format) {
			return $text;
		} else if ($total_items === 1) {
			return [
				"text" => strip_tags($text),
				"link" => wp_nonce_url(str_replace("#comment", "?action=" . self::MARK_NOTIFICATION_READ . "&notificationid=$notification_id#comment", get_comment_link($item_id)), self::MARK_NOTIFICATION_READ . "_" . $notification_id),
			];
		} else {
			$text = sprintf(__($this->options->multipleReplyNotificationsMessage, "wpdiscuz-buddypress-integration"), $total_items);
			return [
				"text" => strip_tags($text),
				"link" => bp_get_notifications_permalink(),
			];
		}
	}
	/* /REPLY */

	/* COMMENT ON POST (for post authors) */
	private function commentOnPost($comment_ID, $comment_approved, $commentdata) {
		if (($post = get_post($commentdata["comment_post_ID"])) && $post->post_author != $commentdata["user_id"]) {
			if ($this->options->notificationForCommentOnPost) {
				$notificationForCommentOnPost = get_user_meta($post->post_author, self::USER_META_NOTIFICATION_FOR_COMMENT_ON_POST, true);
				if (!is_numeric($notificationForCommentOnPost)) {
					$notificationForCommentOnPost = $this->options->notificationForCommentOnPostForNewUsers;
				}
				$commenter_ip = md5($commentdata["comment_author_IP"]);
				if ($notificationForCommentOnPost && !$this->dbmanager->ifNotificationExists($post->post_author, $comment_ID, $commentdata["user_id"], [self::COMPONENT_ACTION_MENTION, self::COMPONENT_ACTION_REPLY, self::COMPONENT_ACTION_SUBSCRIPTIONS, self::COMPONENT_ACTION_FOLLOWS], $commenter_ip)) {
					$notification_id = bp_notifications_add_notification([
						"user_id" => $post->post_author,
						"item_id" => $comment_ID,
						"secondary_item_id" => $commentdata["user_id"],
						"component_name" => self::COMPONENT_NAME,
						"component_action" => self::COMPONENT_ACTION_COMMENT_ON_POST,
						"date_notified" => bp_core_current_time(),
						"is_new" => 1,
					]);
					if ($notification_id && !$commentdata["user_id"]) {
						bp_notifications_add_meta($notification_id, self::NOTIFICATION_META_AUTHOR_IP, $commenter_ip, true);
					}
				}
			}
			if ($this->options->emailForCommentOnPost) {
				$emailForCommentOnPost = get_user_meta($post->post_author, self::USER_META_EMAIL_FOR_COMMENT_ON_POST, true);
				if (!is_numeric($emailForCommentOnPost)) {
					$emailForCommentOnPost = $this->options->emailForCommentOnPostForNewUsers;
				}
				if ($emailForCommentOnPost) {
					if ($commenter = get_user_by("id", $commentdata["user_id"])) {
						$commenterName = $commenter->display_name;
						$commenterUrl = bp_core_get_user_domain($commenter->ID);
					} else {
						$commenterName = $commentdata["comment_author"];
						$commenterUrl = $commentdata["comment_author_url"];
					}
					$user = get_user_by("id", $post->post_author);
					$blogTitle = get_option("blogname");
					$subject = html_entity_decode(str_replace(["[AUTHOR_NAME]", "[POST_TITLE]", "[BLOG_TITLE]"], [$commenterName, $post->post_title, $blogTitle], $this->options->commentOnPostEmailSubject), ENT_QUOTES);
					$message = str_replace(["[SUBSCRIBER_NAME]", "[AUTHOR_NAME]", "[AUTHOR_URL]", "[COMMENT_URL]", "[POST_TITLE]", "[POST_URL]", "[BLOG_TITLE]", "[SITE_URL]", "[NOTIFICATIONS_PAGE_URL]"], [$user->display_name, $commenterName, $commenterUrl, get_comment_link($comment_ID), $post->post_title, get_the_permalink($post), $blogTitle, get_site_url(), bp_get_notifications_permalink($user->ID) . "settings/"], $this->options->commentOnPostEmailMessage);
					wp_mail($user->user_email, $subject, $message, $this->getMailHeaders());
				}
			}
		}
	}

	private function getCommentOnPostNotification($action, $item_id, $secondary_item_id, $total_items, $format, $real_action, $component_name, $notification_id) {
		$comment = get_comment($item_id);
		if (!$comment || !($comment instanceof  WP_Comment)) {
			return;
		}

		if ($commenter = get_user_by("id", $secondary_item_id)) {
			$commenterName = $commenter->display_name;
			$commenterUrl = bp_core_get_user_domain($commenter->ID);
		} else {
			$commenterName = $comment->comment_author;
			$commenterUrl = $comment->comment_author_url;
		}
		$text = str_replace(["[COMMENT_URL]", "[AUTHOR_NAME]", "[AUTHOR_URL]", "[POST_TITLE]", "[POST_URL]"], [get_comment_link($item_id), $commenterName, $commenterUrl, get_the_title($comment->comment_post_ID), get_the_permalink($comment->comment_post_ID)], __($this->options->commentOnPostNotificationMessage, "wpdiscuz-buddypress-integration"));
		if ("string" === $format) {
			return $text;
		} else if ($total_items === 1) {
			return [
				"text" => strip_tags($text),
				"link" => wp_nonce_url(str_replace("#comment", "?action=" . self::MARK_NOTIFICATION_READ . "&notificationid=$notification_id#comment", get_comment_link($item_id)), self::MARK_NOTIFICATION_READ . "_" . $notification_id),
			];
		} else {
			$text = sprintf(__($this->options->multipleCommentOnPostNotificationsMessage, "wpdiscuz-buddypress-integration"), $total_items);
			return [
				"text" => strip_tags($text),
				"link" => bp_get_notifications_permalink(),
			];
		}
	}
	/* /COMMENT ON POST (for post authors) */

	/* /COMMENT POSTED */

	/* SUBSCRIPTIONS */
	public function subscriptions($sendEmail, $emailData, $comment) {
		if (($subscriber = get_user_by("email", $emailData["email"]))) {
			if ($this->options->notificationForSubscriptions) {
				$notificationForSubscriptions = get_user_meta($subscriber->ID, self::USER_META_NOTIFICATION_FOR_SUBSCRIPTIONS, true);
				if (!is_numeric($notificationForSubscriptions)) {
					$notificationForSubscriptions = $this->options->notificationForSubscriptionsForNewUsers;
				}
				$commenter_ip = md5($comment->comment_author_IP);
				if ($notificationForSubscriptions && !$this->dbmanager->ifNotificationExists($subscriber->ID, $comment->comment_ID, $comment->user_id, [self::COMPONENT_ACTION_MENTION, self::COMPONENT_ACTION_REPLY, self::COMPONENT_ACTION_COMMENT_ON_POST, self::COMPONENT_ACTION_FOLLOWS], $commenter_ip)) {
					$notification_id = bp_notifications_add_notification([
						"user_id" => $subscriber->ID,
						"item_id" => $comment->comment_ID,
						"secondary_item_id" => $comment->user_id,
						"component_name" => self::COMPONENT_NAME,
						"component_action" => self::COMPONENT_ACTION_SUBSCRIPTIONS,
						"date_notified" => bp_core_current_time(),
						"is_new" => 1,
					]);
					if ($notification_id && !$comment->user_id) {
						bp_notifications_add_meta($notification_id, self::NOTIFICATION_META_AUTHOR_IP, $commenter_ip, true);
					}
				}
			}
			$sendEmail = false;
			if ($this->options->emailForSubscriptions) {
				$emailForSubscriptions = get_user_meta($subscriber->ID, self::USER_META_EMAIL_FOR_SUBSCRIPTIONS, true);
				if (!is_numeric($emailForSubscriptions)) {
					$emailForSubscriptions = $this->options->emailForSubscriptionsForNewUsers;
				}
				$sendEmail = (bool) $emailForSubscriptions;
			}
		}
		return $sendEmail;
	}

	private function getSubscriptionsNotification($action, $item_id, $secondary_item_id, $total_items, $format, $real_action, $component_name, $notification_id) {
		$comment = get_comment($item_id);
		if ($commenter = get_user_by("id", $secondary_item_id)) {
			$commenterName = $commenter->display_name;
			$commenterUrl = bp_core_get_user_domain($commenter->ID);
		} else {
			$commenterName = $comment->comment_author;
			$commenterUrl = $comment->comment_author_url;
		}
		$text = str_replace(["[COMMENT_URL]", "[AUTHOR_NAME]", "[AUTHOR_URL]", "[POST_TITLE]", "[POST_URL]"], [get_comment_link($item_id), $commenterName, $commenterUrl, get_the_title($comment->comment_post_ID), get_the_permalink($comment->comment_post_ID)], __($this->options->subscriptionsNotificationMessage, "wpdiscuz-buddypress-integration"));
		if ("string" === $format) {
			return $text;
		} else if ($total_items === 1) {
			return [
				"text" => strip_tags($text),
				"link" => wp_nonce_url(str_replace("#comment", "?action=" . self::MARK_NOTIFICATION_READ . "&notificationid=$notification_id#comment", get_comment_link($item_id)), self::MARK_NOTIFICATION_READ . "_" . $notification_id),
			];
		} else {
			$text = sprintf(__($this->options->multipleSubscriptionsNotificationsMessage, "wpdiscuz-buddypress-integration"), $total_items);
			return [
				"text" => strip_tags($text),
				"link" => bp_get_notifications_permalink(),
			];
		}
	}
	/* /SUBSCRIPTIONS */

	/* FOLLOWS */
	public function follows($sendEmail, $followerData, $comment) {
		if (($follower = get_user_by("id", $followerData["follower_id"]))) {
			if ($this->options->notificationForFollows) {
				$notificationForFollows = get_user_meta($follower->ID, self::USER_META_NOTIFICATION_FOR_FOLLOWS, true);
				if (!is_numeric($notificationForFollows)) {
					$notificationForFollows = $this->options->notificationForFollowsForNewUsers;
				}
				$commenter_ip = md5($comment->comment_author_IP);
				if ($notificationForFollows && !$this->dbmanager->ifNotificationExists($follower->ID, $comment->comment_ID, $comment->user_id, [self::COMPONENT_ACTION_MENTION, self::COMPONENT_ACTION_REPLY, self::COMPONENT_ACTION_COMMENT_ON_POST, self::COMPONENT_ACTION_SUBSCRIPTIONS], $commenter_ip)) {
					$notification_id = bp_notifications_add_notification([
						"user_id" => $follower->ID,
						"item_id" => $comment->comment_ID,
						"secondary_item_id" => $comment->user_id,
						"component_name" => self::COMPONENT_NAME,
						"component_action" => self::COMPONENT_ACTION_FOLLOWS,
						"date_notified" => bp_core_current_time(),
						"is_new" => 1,
					]);
					if ($notification_id && !$comment->user_id) {
						bp_notifications_add_meta($notification_id, self::NOTIFICATION_META_AUTHOR_IP, $commenter_ip, true);
					}
				}
			}
			$sendEmail = false;
			if ($this->options->emailForFollows) {
				$emailForFollows = get_user_meta($follower->ID, self::USER_META_EMAIL_FOR_FOLLOWS, true);
				if (!is_numeric($emailForFollows)) {
					$emailForFollows = $this->options->emailForFollowsForNewUsers;
				}
				$sendEmail = (bool) $emailForFollows;
			}
		}
		return $sendEmail;
	}

	private function getFollowsNotification($action, $item_id, $secondary_item_id, $total_items, $format, $real_action, $component_name, $notification_id) {
		$comment = get_comment($item_id);
		if ($commenter = get_user_by("id", $secondary_item_id)) {
			$commenterName = $commenter->display_name;
			$commenterUrl = bp_core_get_user_domain($commenter->ID);
		} else {
			$commenterName = $comment->comment_author;
			$commenterUrl = $comment->comment_author_url;
		}
		$text = str_replace(["[COMMENT_URL]", "[AUTHOR_NAME]", "[AUTHOR_URL]", "[POST_TITLE]", "[POST_URL]"], [get_comment_link($item_id), $commenterName, $commenterUrl, get_the_title($comment->comment_post_ID), get_the_permalink($comment->comment_post_ID)], __($this->options->followsNotificationMessage, "wpdiscuz-buddypress-integration"));
		if ("string" === $format) {
			return $text;
		} else if ($total_items === 1) {
			return [
				"text" => strip_tags($text),
				"link" => wp_nonce_url(str_replace("#comment", "?action=" . self::MARK_NOTIFICATION_READ . "&notificationid=$notification_id#comment", get_comment_link($item_id)), self::MARK_NOTIFICATION_READ . "_" . $notification_id),
			];
		} else {
			$text = sprintf(__($this->options->multipleFollowsNotificationsMessage, "wpdiscuz-buddypress-integration"), $total_items);
			return [
				"text" => strip_tags($text),
				"link" => bp_get_notifications_permalink(),
			];
		}
	}
	/* /FOLLOWS */

	/* COMMON */
	public function userDeleted($user_id, $reassign, $user) {
		$this->dbmanager->deleteNotificationsBySecondaryId($user_id, [self::COMPONENT_ACTION_APPROVED_COMMENT, self::COMPONENT_ACTION_MENTION, self::COMPONENT_ACTION_REPLY, self::COMPONENT_ACTION_COMMENT_ON_POST, self::COMPONENT_ACTION_SUBSCRIPTIONS, self::COMPONENT_ACTION_FOLLOWS]);
	}

	public function commentStatusChanged($new_status, $old_status, $comment) {
		if ($new_status === "approved") {
			$this->commentIsApproved($comment);
			$this->reply($comment->comment_ID, $comment->comment_approved, (array) $comment);
			$this->commentOnPost($comment->comment_ID, $comment->comment_approved, (array) $comment);
		} else {
			$this->dbmanager->deleteNotifications($comment->comment_ID, [self::COMPONENT_ACTION_APPROVED_COMMENT, self::COMPONENT_ACTION_MENTION, self::COMPONENT_ACTION_REPLY, self::COMPONENT_ACTION_COMMENT_ON_POST, self::COMPONENT_ACTION_SUBSCRIPTIONS, self::COMPONENT_ACTION_FOLLOWS]);
		}
	}

	public function commentDeleted($comment_ID, $comment) {
		$this->dbmanager->deleteNotifications($comment_ID, [self::COMPONENT_ACTION_APPROVED_COMMENT, self::COMPONENT_ACTION_MENTION, self::COMPONENT_ACTION_REPLY, self::COMPONENT_ACTION_COMMENT_ON_POST, self::COMPONENT_ACTION_SUBSCRIPTIONS, self::COMPONENT_ACTION_FOLLOWS, self::COMPONENT_ACTION_COMMENT_UPVOTE, self::COMPONENT_ACTION_COMMENT_DOWNVOTE]);
	}

	public function bpNotifications($action, $item_id, $secondary_item_id, $total_items, $format, $real_action, $component_name, $notification_id) {
		$return = $action;
		$total_items = intval($total_items);
		if (self::COMPONENT_ACTION_COMMENT_UPVOTE === $real_action) {
			$return = $this->getCommentUpvoteNotification($action, $item_id, $secondary_item_id, $total_items, $format, $real_action, $component_name, $notification_id);
		} else if (self::COMPONENT_ACTION_COMMENT_DOWNVOTE === $real_action) {
			$return = $this->getCommentDownvoteNotification($action, $item_id, $secondary_item_id, $total_items, $format, $real_action, $component_name, $notification_id);
		} else if (self::COMPONENT_ACTION_FOLLOW === $real_action) {
			$return = $this->getFollowNotification($action, $item_id, $secondary_item_id, $total_items, $format, $real_action, $component_name, $notification_id);
		} else if (self::COMPONENT_ACTION_POST_RATING === $real_action) {
			$return = $this->getPostRatingNotification($action, $item_id, $secondary_item_id, $total_items, $format, $real_action, $component_name, $notification_id);
		} else if (self::COMPONENT_ACTION_APPROVED_COMMENT === $real_action) {
			$return = $this->getApprovedCommentNotification($action, $item_id, $secondary_item_id, $total_items, $format, $real_action, $component_name, $notification_id);
		} else if (self::COMPONENT_ACTION_MENTION === $real_action) {
			$return = $this->getMentionNotification($action, $item_id, $secondary_item_id, $total_items, $format, $real_action, $component_name, $notification_id);
		} else if (self::COMPONENT_ACTION_REPLY === $real_action) {
			$return = $this->getReplyNotification($action, $item_id, $secondary_item_id, $total_items, $format, $real_action, $component_name, $notification_id);
		} else if (self::COMPONENT_ACTION_COMMENT_ON_POST === $real_action) {
			$return = $this->getCommentOnPostNotification($action, $item_id, $secondary_item_id, $total_items, $format, $real_action, $component_name, $notification_id);
		} else if (self::COMPONENT_ACTION_SUBSCRIPTIONS === $real_action) {
			$return = $this->getSubscriptionsNotification($action, $item_id, $secondary_item_id, $total_items, $format, $real_action, $component_name, $notification_id);
		} else if (self::COMPONENT_ACTION_FOLLOWS === $real_action) {
			$return = $this->getFollowsNotification($action, $item_id, $secondary_item_id, $total_items, $format, $real_action, $component_name, $notification_id);
		}
		return $return;
	}

	public function deleteNotificationMeta($args) {
		if (!empty($args["id"]) && ($notification = bp_notifications_get_notification($args["id"])) && $notification->component_name === self::COMPONENT_NAME && $this->isBPIComponentAction($notification->component_action)) {
			$this->dbmanager->deleteNotificationMetaByNotificationId($notification->id);
		}
	}

	public function markNotificationRead() {
		if (empty($_GET["notificationid"]) || empty($_GET["action"]) || empty($_GET["_wpnonce"])) {
			return;
		}
		if ($notification_id = intval($_GET["notificationid"])) {
			if (self::MARK_NOTIFICATION_READ !== $_GET["action"] || !wp_verify_nonce($_GET["_wpnonce"], self::MARK_NOTIFICATION_READ . "_" . $notification_id)) {
				return;
			}
			if ($notification = bp_notifications_get_notification($notification_id)) {
				$this->dbmanager->markNotificationRead($notification_id);
				if ($this->isCommentComponentAction($notification->component_action)) {
					wp_safe_redirect(get_comment_link($notification->item_id));
					die;
				} else if ($notification->component_action === self::COMPONENT_ACTION_FOLLOW) {
					wp_safe_redirect(bp_core_get_user_domain($notification->secondary_item_id));
					die;
				} else if ($notification->component_action === self::COMPONENT_ACTION_POST_RATING) {
					wp_safe_redirect(get_the_permalink($notification->item_id) . "#wpd-post-rating");
					die;
				}
			}
		}
	}

	private function isBPIComponentAction($action) {
		return in_array($action, [self::COMPONENT_ACTION_COMMENT_UPVOTE, self::COMPONENT_ACTION_COMMENT_DOWNVOTE, self::COMPONENT_ACTION_FOLLOW, self::COMPONENT_ACTION_POST_RATING, self::COMPONENT_ACTION_APPROVED_COMMENT, self::COMPONENT_ACTION_MENTION, self::COMPONENT_ACTION_REPLY, self::COMPONENT_ACTION_COMMENT_ON_POST, self::COMPONENT_ACTION_SUBSCRIPTIONS, self::COMPONENT_ACTION_FOLLOWS], true);
	}

	private function isCommentComponentAction($action) {
		return in_array($action, [self::COMPONENT_ACTION_COMMENT_UPVOTE, self::COMPONENT_ACTION_COMMENT_DOWNVOTE, self::COMPONENT_ACTION_APPROVED_COMMENT, self::COMPONENT_ACTION_MENTION, self::COMPONENT_ACTION_REPLY, self::COMPONENT_ACTION_COMMENT_ON_POST, self::COMPONENT_ACTION_SUBSCRIPTIONS, self::COMPONENT_ACTION_FOLLOWS], true);
	}

	public function addBpComponent($component_names) {
		if (!is_array($component_names)) {
			$component_names = [];
		}
		$component_names[] = self::COMPONENT_NAME;
		return $component_names;
	}

	private function getMailHeaders() {
		$siteUrl = get_site_url();
		$parsedUrl = parse_url($siteUrl);
		$domain = isset($parsedUrl["host"]) ? WpdiscuzHelper::fixEmailFrom($parsedUrl["host"]) : "";
		$fromEmail = "no-reply@" . $domain;
		$blogTitle = get_option("blogname");
		$fromName = html_entity_decode($blogTitle, ENT_QUOTES);
		$headers = [];
		$headers[] = "Content-Type:  text/html; charset=UTF-8";
		$headers[] = "From: " . $fromName . " <" . $fromEmail . "> \r\n";
		return $headers;
	}
	/* /COMMON */

	/* SETTINGS */
	public function notificationSettingsTab() {
		bp_core_new_subnav_item([
			"name" => __($this->options->notificationSettingsTabTitle, "wpdiscuz-buddypress-integration"),
			"slug" => "settings",
			"parent_url" => trailingslashit(bp_displayed_user_domain() . "notifications"),
			"parent_slug" => "notifications",
			"screen_function" => [$this, "screenFunction"],
			"position" => 100,
			"user_has_access" => bp_is_my_profile()
		]);
	}

	public function screenFunction() {
		add_action("bp_template_content", [$this, "screenContent"]);
		bp_core_load_template(apply_filters("bp_core_template_plugin", "members/single/plugins"));
	}

	public function screenContent() {
		include_once WPD_BPI_PATH . "/options/html-notification-settings.php";
	}

	public function saveNotificationSettings() {
		if (isset($_POST[$this->options->tabKey]["save"])) {
			$currentUser = WpdiscuzHelper::getCurrentUser();
			if (!empty($currentUser->ID)) {
				$notificationForCommentVote = !empty($_POST[$this->options->tabKey]["notificationForCommentVote"]) ? intval($_POST[$this->options->tabKey]["notificationForCommentVote"]) : 0;
				$notificationForFollow = !empty($_POST[$this->options->tabKey]["notificationForFollow"]) ? intval($_POST[$this->options->tabKey]["notificationForFollow"]) : 0;
				$notificationForPostRating = !empty($_POST[$this->options->tabKey]["notificationForPostRating"]) ? intval($_POST[$this->options->tabKey]["notificationForPostRating"]) : 0;
				$notificationForApprovedComment = !empty($_POST[$this->options->tabKey]["notificationForApprovedComment"]) ? intval($_POST[$this->options->tabKey]["notificationForApprovedComment"]) : 0;
				$notificationForReply = !empty($_POST[$this->options->tabKey]["notificationForReply"]) ? intval($_POST[$this->options->tabKey]["notificationForReply"]) : 0;
				$notificationForCommentOnPost = !empty($_POST[$this->options->tabKey]["notificationForCommentOnPost"]) ? intval($_POST[$this->options->tabKey]["notificationForCommentOnPost"]) : 0;
				$notificationForMention = !empty($_POST[$this->options->tabKey]["notificationForMention"]) ? intval($_POST[$this->options->tabKey]["notificationForMention"]) : 0;
				$notificationForSubscriptions = !empty($_POST[$this->options->tabKey]["notificationForSubscriptions"]) ? intval($_POST[$this->options->tabKey]["notificationForSubscriptions"]) : 0;
				$notificationForFollows = !empty($_POST[$this->options->tabKey]["notificationForFollows"]) ? intval($_POST[$this->options->tabKey]["notificationForFollows"]) : 0;
				$emailForCommentVote = !empty($_POST[$this->options->tabKey]["emailForCommentVote"]) ? intval($_POST[$this->options->tabKey]["emailForCommentVote"]) : 0;
				$emailForFollow = !empty($_POST[$this->options->tabKey]["emailForFollow"]) ? intval($_POST[$this->options->tabKey]["emailForFollow"]) : 0;
				$emailForPostRating = !empty($_POST[$this->options->tabKey]["emailForPostRating"]) ? intval($_POST[$this->options->tabKey]["emailForPostRating"]) : 0;
				$emailForApprovedComment = !empty($_POST[$this->options->tabKey]["emailForApprovedComment"]) ? intval($_POST[$this->options->tabKey]["emailForApprovedComment"]) : 0;
				$emailForReply = !empty($_POST[$this->options->tabKey]["emailForReply"]) ? intval($_POST[$this->options->tabKey]["emailForReply"]) : 0;
				$emailForCommentOnPost = !empty($_POST[$this->options->tabKey]["emailForCommentOnPost"]) ? intval($_POST[$this->options->tabKey]["emailForCommentOnPost"]) : 0;
				$emailForMention = !empty($_POST[$this->options->tabKey]["emailForMention"]) ? intval($_POST[$this->options->tabKey]["emailForMention"]) : 0;
				$emailForSubscriptions = !empty($_POST[$this->options->tabKey]["emailForSubscriptions"]) ? intval($_POST[$this->options->tabKey]["emailForSubscriptions"]) : 0;
				$emailForFollows = !empty($_POST[$this->options->tabKey]["emailForFollows"]) ? intval($_POST[$this->options->tabKey]["emailForFollows"]) : 0;
				update_user_meta($currentUser->ID, self::USER_META_NOTIFICATION_FOR_COMMENT_VOTE, $notificationForCommentVote);
				update_user_meta($currentUser->ID, self::USER_META_NOTIFICATION_FOR_FOLLOW, $notificationForFollow);
				update_user_meta($currentUser->ID, self::USER_META_NOTIFICATION_FOR_POST_RATING, $notificationForPostRating);
				update_user_meta($currentUser->ID, self::USER_META_NOTIFICATION_FOR_APPROVED_COMMENT, $notificationForApprovedComment);
				update_user_meta($currentUser->ID, self::USER_META_NOTIFICATION_FOR_REPLY, $notificationForReply);
				update_user_meta($currentUser->ID, self::USER_META_NOTIFICATION_FOR_COMMENT_ON_POST, $notificationForCommentOnPost);
				update_user_meta($currentUser->ID, self::USER_META_NOTIFICATION_FOR_MENTION, $notificationForMention);
				update_user_meta($currentUser->ID, self::USER_META_NOTIFICATION_FOR_SUBSCRIPTIONS, $notificationForSubscriptions);
				update_user_meta($currentUser->ID, self::USER_META_NOTIFICATION_FOR_FOLLOWS, $notificationForFollows);
				update_user_meta($currentUser->ID, self::USER_META_EMAIL_FOR_COMMENT_VOTE, $emailForCommentVote);
				update_user_meta($currentUser->ID, self::USER_META_EMAIL_FOR_FOLLOW, $emailForFollow);
				update_user_meta($currentUser->ID, self::USER_META_EMAIL_FOR_POST_RATING, $emailForPostRating);
				update_user_meta($currentUser->ID, self::USER_META_EMAIL_FOR_APPROVED_COMMENT, $emailForApprovedComment);
				update_user_meta($currentUser->ID, self::USER_META_EMAIL_FOR_REPLY, $emailForReply);
				update_user_meta($currentUser->ID, self::USER_META_EMAIL_FOR_COMMENT_ON_POST, $emailForCommentOnPost);
				update_user_meta($currentUser->ID, self::USER_META_EMAIL_FOR_MENTION, $emailForMention);
				update_user_meta($currentUser->ID, self::USER_META_EMAIL_FOR_SUBSCRIPTIONS, $emailForSubscriptions);
				update_user_meta($currentUser->ID, self::USER_META_EMAIL_FOR_FOLLOWS, $emailForFollows);
				wp_safe_redirect(trailingslashit( bp_displayed_user_domain() . "notifications/settings"));
				die;
			}
		}
	}
	/* /SETTINGS */

}