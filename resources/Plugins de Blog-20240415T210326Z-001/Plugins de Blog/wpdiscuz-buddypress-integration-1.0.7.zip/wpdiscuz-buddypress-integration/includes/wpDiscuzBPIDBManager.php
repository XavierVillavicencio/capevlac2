<?php
if (!defined("ABSPATH")) {
	exit();
}

class wpDiscuzBPIDBManager implements wpDiscuzBPIConstants {

	private $db;

	public function __construct() {
		global $wpdb;
		$this->db = $wpdb;
	}

	/* Notifications */
	public function ifNotificationExists($user_id, $item_id, $secondary_item_id, $component_actions, $commenter_ip = "") {
		$join = "";
		if (!$secondary_item_id) {
			$join = $this->db->prepare("INNER JOIN `" . buddypress()->notifications->table_name_meta . "` AS `nm` ON `nm`.`notification_id` = `n`.`id` AND `nm`.`meta_key` = %s AND `nm`.`meta_value` = %s ", self::NOTIFICATION_META_AUTHOR_IP, $commenter_ip);
		}
		$sql = $this->db->prepare("SELECT `n`.`id` FROM `" . buddypress()->notifications->table_name . "` AS `n`$join WHERE `n`.`component_name` = %s AND `n`.`component_action` IN('" . implode("','", $component_actions) . "') AND `n`.`user_id` = %d AND `n`.`item_id` = %d AND `n`.`secondary_item_id` = %d", self::COMPONENT_NAME, $user_id, $item_id, $secondary_item_id);
		return intval($this->db->get_var($sql));
	}

	public function deleteGuestVoteNotification($item_id, $component_action, $voter_ip) {
		$sql = $this->db->prepare("SELECT `n`.`id` FROM `" . buddypress()->notifications->table_name . "` AS `n` INNER JOIN `" . buddypress()->notifications->table_name_meta . "` AS `nm` ON `nm`.`notification_id` = `n`.`id` AND `nm`.`meta_key` = %s AND `nm`.`meta_value` = %s WHERE `n`.`component_name` = %s AND `n`.`component_action` = %s AND `n`.`item_id` = %d AND `n`.`secondary_item_id` = 0", self::NOTIFICATION_META_AUTHOR_IP, $voter_ip, self::COMPONENT_NAME, $component_action, $item_id);
		$notification_id = $this->db->get_var($sql);
		if ($notification_id) {
			$deleteSql = $this->db->prepare("DELETE FROM `" . buddypress()->notifications->table_name . "` WHERE `id` = %d", $notification_id);
			$this->db->query($deleteSql);
			$this->deleteNotificationMetaByNotificationId($notification_id);
		}
	}

	public function deleteNotificationMetaByNotificationId($notification_id) {
		if (is_array($notification_id)) {
			$where = "`notification_id` IN(" . implode(",", $notification_id) . ")";
		} else {
			$where = "`notification_id` = " . $notification_id;
		}
		$sql = "DELETE FROM `" . buddypress()->notifications->table_name_meta . "` WHERE $where";
		$this->db->query($sql);
	}

	public function markNotificationRead($notification_id) {
		$sql = $this->db->prepare("UPDATE `" . buddypress()->notifications->table_name . "` SET `is_new` = 0 WHERE `id` = %d", $notification_id);
		$this->db->query($sql);
	}

	public function deleteNotifications($item_id, $component_actions) {
		$sql = $this->db->prepare("SELECT `id` FROM `" . buddypress()->notifications->table_name . "` WHERE `component_name` = %s AND `component_action` IN('" . implode("','", $component_actions) . "') AND `item_id` = %d", self::COMPONENT_NAME, $item_id);
		if ($results = $this->db->get_col($sql)) {
			$sql = "DELETE FROM `" . buddypress()->notifications->table_name . "` WHERE `id` IN(" . implode(",", $results) . ")";
			$this->db->query($sql);
			$this->deleteNotificationMetaByNotificationId($results);
		}
	}

	public function deleteNotificationsBySecondaryId($secondary_item_id, $component_actions) {
		$sql = $this->db->prepare("SELECT `id` FROM `" . buddypress()->notifications->table_name . "` WHERE `component_name` = %s AND `component_action` IN('" . implode("','", $component_actions) . "') AND `secondary_item_id` = %d", self::COMPONENT_NAME, $secondary_item_id);
		if ($results = $this->db->get_col($sql)) {
			$sql = "DELETE FROM `" . buddypress()->notifications->table_name . "` WHERE `id` IN(" . implode(",", $results) . ")";
			$this->db->query($sql);
			$this->deleteNotificationMetaByNotificationId($results);
		}
	}

	public function deleteNotificationsByType($component_actions) {
		$sql = $this->db->prepare("SELECT `id` FROM `" . buddypress()->notifications->table_name . "` WHERE `component_name` = %s AND `component_action` IN('" . implode("','", $component_actions) . "')", self::COMPONENT_NAME);
		if ($results = $this->db->get_col($sql)) {
			$sql = "DELETE FROM `" . buddypress()->notifications->table_name . "` WHERE `id` IN(" . implode(",", $results) . ")";
			$this->db->query($sql);
			$this->deleteNotificationMetaByNotificationId($results);
		}
	}
	/* /Notifications */

	/* Activity */
	public function deleteActivities($item_id, $types) {
		$sql = $this->db->prepare("DELETE FROM `" . buddypress()->activity->table_name . "` WHERE `component` = %s AND `type` IN('" . implode("','", $types) . "') AND `item_id` = %d", self::COMPONENT_NAME, $item_id);
		$this->db->query($sql);
	}

	public function deleteActivitiesByType($types) {
		$sql = $this->db->prepare("DELETE FROM `" . buddypress()->activity->table_name . "` WHERE `component` = %s AND `type` IN('" . implode("','", $types) . "')", self::COMPONENT_NAME);
		$this->db->query($sql);
	}
	/* /Activity */

	/* Tools */
	/* Comments */
	public function getCommentsCountToImport() {
		$sql = $this->db->prepare("SELECT COUNT(*) FROM `" . $this->db->prefix . "comments` WHERE `user_id` != 0 AND `comment_approved` = '1' AND `comment_ID` NOT IN (SELECT `secondary_item_id` FROM `" . buddypress()->activity->table_name . "` WHERE `component` = %s AND `type` = %s AND `item_id` = %d)", "blogs", "new_blog_comment", get_current_blog_id());
		return intval($this->db->get_var($sql));
	}

	public function checkCommentsCount($startDate, $endDate) {
		$start = "";
		$end = "";
		if ($startDate) {
			$start = "AND `comment_date_gmt` >= '" . $startDate . " 00:00:00'";
		}
		if ($endDate) {
			$end = "AND `comment_date_gmt` <= '" . $endDate . " 23:59:59'";
		}
		$sql = $this->db->prepare("SELECT COUNT(*) FROM `" . $this->db->prefix . "comments` WHERE `user_id` != 0 AND `comment_approved` = '1' $start $end AND `comment_ID` NOT IN (SELECT `secondary_item_id` FROM `" . buddypress()->activity->table_name . "` WHERE `component` = %s AND `type` = %s AND `item_id` = %d)", "blogs", "new_blog_comment", get_current_blog_id());
		return intval($this->db->get_var($sql));
	}

	public function getImportComments($startId, $limit, $startDate, $endDate) {
		$start = "";
		$end = "";
		if ($startDate) {
			$start = "AND `comment_date_gmt` >= '" . $startDate . " 00:00:00'";
		}
		if ($endDate) {
			$end = "AND `comment_date_gmt` <= '" . $endDate . " 23:59:59'";
		}
		$sql = $this->db->prepare("SELECT `comment_ID` FROM `" . $this->db->prefix . "comments` WHERE `user_id` != 0 AND `comment_approved` = '1' $start $end AND `comment_ID` NOT IN (SELECT `secondary_item_id` FROM `" . buddypress()->activity->table_name . "` WHERE `component` = %s AND `type` = %s AND `item_id` = %d) AND `comment_ID` > %d ORDER BY `comment_ID` ASC LIMIT %d", "blogs", "new_blog_comment", get_current_blog_id(), $startId, $limit);
		return $this->db->get_col($sql);
	}
	/* /Comments */

	/* Votes */
	public function getVotesCountToImport() {
		$sql = $this->db->prepare("SELECT COUNT(*) FROM `" . $this->db->prefix . "wc_users_voted` WHERE `is_guest` = 0 AND `vote_type` != 0 AND CONCAT(`user_id`, '-', `comment_id`) NOT IN (SELECT CONCAT(`user_id`, '-', `item_id`) FROM `" . buddypress()->activity->table_name . "` WHERE `component` = '%s' AND `type` IN (%s, %s))", self::COMPONENT_NAME, self::ACTIVITY_TYPE_COMMENT_UPVOTE, self::ACTIVITY_TYPE_COMMENT_DOWNVOTE);
		return intval($this->db->get_var($sql));
	}

	public function checkCommentsVotesCount($startDate, $endDate) {
		$start = "";
		$end = "";
		if ($startDate) {
			$start = "AND `date` >= '" . strtotime($startDate) . " 00:00:00'";
		}
		if ($endDate) {
			$end = "AND `date` <= '" . strtotime($endDate) . " 23:59:59'";
		}
		$sql = $this->db->prepare("SELECT COUNT(*) FROM `" . $this->db->prefix . "wc_users_voted` WHERE `is_guest` = 0 AND `vote_type` != 0 $start $end AND CONCAT(`user_id`, '-', `comment_id`) NOT IN (SELECT CONCAT(`user_id`, '-', `item_id`) FROM `" . buddypress()->activity->table_name . "` WHERE `component` = '%s' AND `type` IN (%s, %s))", self::COMPONENT_NAME, self::ACTIVITY_TYPE_COMMENT_UPVOTE, self::ACTIVITY_TYPE_COMMENT_DOWNVOTE);
		return intval($this->db->get_var($sql));
	}

	public function getImportCommentVotes($startId, $limit, $startDate, $endDate) {
		$start = "";
		$end = "";
		if ($startDate) {
			$start = "AND `date` >= '" . strtotime($startDate) . " 00:00:00'";
		}
		if ($endDate) {
			$end = "AND `date` <= '" . strtotime($endDate) . " 23:59:59'";
		}
		$sql = $this->db->prepare("SELECT * FROM `" . $this->db->prefix . "wc_users_voted` WHERE `is_guest` = 0 AND `vote_type` != 0 $start $end AND CONCAT(`user_id`, '-', `comment_id`) NOT IN (SELECT CONCAT(`user_id`, '-', `item_id`) FROM `" . buddypress()->activity->table_name . "` WHERE `component` = '%s' AND `type` IN (%s, %s)) AND `id` > %d ORDER BY `id` ASC LIMIT %d", self::COMPONENT_NAME, self::ACTIVITY_TYPE_COMMENT_UPVOTE, self::ACTIVITY_TYPE_COMMENT_DOWNVOTE, $startId, $limit);
		return $this->db->get_results($sql);
	}
	/* /Votes */

	/* Ratings */
	public function getRatingsCountToImport() {
		$sql = $this->db->prepare("SELECT COUNT(*) FROM `" . $this->db->prefix . "wc_users_rated` WHERE `user_id` != 0 AND CONCAT(`user_id`, '-', `post_id`) NOT IN (SELECT CONCAT(`user_id`, '-', `item_id`) FROM `" . buddypress()->activity->table_name . "` WHERE `component` = '%s' AND `type` = %s)", self::COMPONENT_NAME, self::ACTIVITY_TYPE_POST_RATING, self::ACTIVITY_TYPE_COMMENT_DOWNVOTE);
		return intval($this->db->get_var($sql));
	}

	public function checkPostRatingsCount($startDate, $endDate) {
		$start = "";
		$end = "";
		if ($startDate) {
			$start = "AND `date` >= '" . strtotime($startDate) . " 00:00:00'";
		}
		if ($endDate) {
			$end = "AND `date` <= '" . strtotime($endDate) . " 23:59:59'";
		}
		$sql = $this->db->prepare("SELECT COUNT(*) FROM `" . $this->db->prefix . "wc_users_rated` WHERE `user_id` != 0 $start $end AND CONCAT(`user_id`, '-', `post_id`) NOT IN (SELECT CONCAT(`user_id`, '-', `item_id`) FROM `" . buddypress()->activity->table_name . "` WHERE `component` = '%s' AND `type` = %s)", self::COMPONENT_NAME, self::ACTIVITY_TYPE_POST_RATING, self::ACTIVITY_TYPE_COMMENT_DOWNVOTE);
		return intval($this->db->get_var($sql));
	}

	public function getImportPostRatings($startId, $limit, $startDate, $endDate) {
		$start = "";
		$end = "";
		if ($startDate) {
			$start = "AND `date` >= '" . strtotime($startDate) . " 00:00:00'";
		}
		if ($endDate) {
			$end = "AND `date` <= '" . strtotime($endDate) . " 23:59:59'";
		}
		$sql = $this->db->prepare("SELECT * FROM `" . $this->db->prefix . "wc_users_rated` WHERE `user_id` != 0 $start $end AND CONCAT(`user_id`, '-', `post_id`) NOT IN (SELECT CONCAT(`user_id`, '-', `item_id`) FROM `" . buddypress()->activity->table_name . "` WHERE `component` = '%s' AND `type` = %s) AND `id` > %d ORDER BY `id` ASC LIMIT %d", self::COMPONENT_NAME, self::ACTIVITY_TYPE_POST_RATING, $startId, $limit);
		return $this->db->get_results($sql);
	}
	/* /Votes */
	/* /Tools */

	/* Profile Tabs */
	/* Subscriptions */
	public function getSubscriptionsCount($email) {
		$sql = $this->db->prepare("SELECT COUNT(*) FROM `" . $this->db->prefix . "wc_comments_subscription` WHERE `email` = %s AND `confirm` = 1", $email);
		return intval($this->db->get_var($sql));
	}

	public function getSubscriptions($email, $limit, $offset) {
		$sql = $this->db->prepare("SELECT * FROM `" . $this->db->prefix . "wc_comments_subscription` WHERE `email` = %s AND `confirm` = 1 ORDER BY `id` DESC LIMIT %d OFFSET %d", $email, $limit, $offset);
		return $this->db->get_results($sql);
	}
	/* /Subscriptions */

	/* Reactions */
	public function getReactionsCount($user_id) {
		$sql = $this->db->prepare("SELECT COUNT(*) FROM `" . $this->db->prefix . "wc_users_voted` WHERE `user_id` = %d AND `vote_type` != 0", $user_id);
		return intval($this->db->get_var($sql));
	}

	public function getReactions($user_id, $limit, $offset) {
		$sql = $this->db->prepare("SELECT * FROM `" . $this->db->prefix . "wc_users_voted` WHERE `user_id` = %d AND `vote_type` != 0 ORDER BY `id` DESC LIMIT %d OFFSET %d", $user_id, $limit, $offset);
		return $this->db->get_results($sql);
	}
	/* /Reactions */

	/* Rates */
	public function getRatesCount($user_id) {
		$sql = $this->db->prepare("SELECT COUNT(*) FROM `" . $this->db->prefix . "wc_users_rated` WHERE `user_id` = %d", $user_id);
		return intval($this->db->get_var($sql));
	}

	public function getRates($user_id, $limit, $offset) {
		$sql = $this->db->prepare("SELECT * FROM `" . $this->db->prefix . "wc_users_rated` WHERE `user_id` = %d ORDER BY `id` DESC LIMIT %d OFFSET %d", $user_id, $limit, $offset);
		return $this->db->get_results($sql);
	}
	/* /Rates */

	/* Votes */
	public function getVotesCount($user_id, $user_email = "") {
		if ($user_email) {
			$user = $this->db->prepare("(`c`.`user_id` = %d OR `c`.`comment_author_email` = %s)", $user_id, $user_email);
		} else {
			$user = $this->db->prepare("`c`.`user_id` = %d", $user_id);
		}
		$sql = "SELECT COUNT(*) FROM `" . $this->db->prefix . "wc_users_voted` AS `v` INNER JOIN `" . $this->db->prefix . "comments` AS `c` ON `c`.`comment_ID` = `v`.`comment_id` AND $user AND `c`.`comment_approved` = '1' WHERE `v`.`vote_type` != 0";
		return intval($this->db->get_var($sql));
	}

	public function getVotes($user_id, $user_email, $limit, $offset) {
		if ($user_email) {
			$user = $this->db->prepare("(`c`.`user_id` = %d OR `c`.`comment_author_email` = %s)", $user_id, $user_email);
		} else {
			$user = $this->db->prepare("`c`.`user_id` = %d", $user_id);
		}
		$sql = $this->db->prepare("SELECT `v`.* FROM `" . $this->db->prefix . "wc_users_voted` AS `v` INNER JOIN `" . $this->db->prefix . "comments` AS `c` ON `c`.`comment_ID` = `v`.`comment_id` AND $user AND `c`.`comment_approved` = '1' WHERE `v`.`vote_type` != 0 ORDER BY `v`.`id` DESC LIMIT %d OFFSET %d", $limit, $offset);
		return $this->db->get_results($sql);
	}
	/* /Votes */

	/* Following */
	public function getFollowsCount($user_id) {
		$sql = $this->db->prepare("SELECT COUNT(*) FROM `" . $this->db->prefix . "wc_follow_users` WHERE `follower_id` = %d AND `confirm` = 1", $user_id);
		return intval($this->db->get_var($sql));
	}

	public function getFollows($user_id, $limit, $offset) {
		$sql = $this->db->prepare("SELECT * FROM `" . $this->db->prefix . "wc_follow_users` WHERE `follower_id` = %d AND `confirm` = 1 ORDER BY `id` DESC LIMIT %d OFFSET %d", $user_id, $limit, $offset);
		return $this->db->get_results($sql);
	}
	/* /Following */

	/* Followers */
	public function getFollowersCount($user_id) {
		$sql = $this->db->prepare("SELECT COUNT(*) FROM `" . $this->db->prefix . "wc_follow_users` WHERE `user_id` = %d AND `confirm` = 1", $user_id);
		return intval($this->db->get_var($sql));
	}

	public function getFollowers($user_id, $limit, $offset) {
		$sql = $this->db->prepare("SELECT * FROM `" . $this->db->prefix . "wc_follow_users` WHERE `user_id` = %d AND `confirm` = 1 ORDER BY `id` DESC LIMIT %d OFFSET %d", $user_id, $limit, $offset);
		return $this->db->get_results($sql);
	}
	/* /Followers */
	/* /Profile Tabs */

}