<?php

if (!defined("ABSPATH")) {
	exit();
}

interface wpDiscuzBPIConstants {

	/* Option Keys */
	const OPTION_VERSION                              = "wpdiscuz_bpi_version";
	const OPTION_SLUG_OPTIONS                         = "wpdiscuz_bpi_options";
	/* BP Components */
	const COMPONENT_NAME                              = "wpdiscuz_bpi";
	const COMPONENT_ACTION_COMMENT_UPVOTE             = "wpdiscuz_bpi_comment_upvote";
	const COMPONENT_ACTION_COMMENT_DOWNVOTE           = "wpdiscuz_bpi_comment_downvote";
	const COMPONENT_ACTION_FOLLOW                     = "wpdiscuz_bpi_follow";
	const COMPONENT_ACTION_POST_RATING                = "wpdiscuz_bpi_post_rating";
	const COMPONENT_ACTION_APPROVED_COMMENT           = "wpdiscuz_bpi_approved_comment";
	const COMPONENT_ACTION_MENTION                    = "wpdiscuz_bpi_mention";
	const COMPONENT_ACTION_REPLY                      = "wpdiscuz_bpi_reply";
	const COMPONENT_ACTION_COMMENT_ON_POST            = "wpdiscuz_bpi_comment_on_post";
	const COMPONENT_ACTION_SUBSCRIPTIONS              = "wpdiscuz_bpi_subscriptions";
	const COMPONENT_ACTION_FOLLOWS                    = "wpdiscuz_bpi_follows";
	const ACTIVITY_TYPE_COMMENT_UPVOTE                = "wpdiscuz_bpi_comment_upvote";
	const ACTIVITY_TYPE_COMMENT_DOWNVOTE              = "wpdiscuz_bpi_comment_downvote";
	const ACTIVITY_TYPE_POST_RATING                   = "wpdiscuz_bpi_post_rating";
	const MARK_NOTIFICATION_READ                      = "wpdiscuz_bpi_mark_read";
	/* BP Meta Keys */
	const NOTIFICATION_META_AUTHOR_IP                 = "wpdiscuz_bpi_notification_author_ip";
	const NOTIFICATION_META_POST_RATING               = "wpdiscuz_bpi_notification_post_rating";
	/* User Meta Keys */
	const USER_META_NOTIFICATION_FOR_COMMENT_VOTE     = "wpdiscuz_bpi_notification_for_comment_vote";
	const USER_META_NOTIFICATION_FOR_FOLLOW           = "wpdiscuz_bpi_notification_for_follow";
	const USER_META_NOTIFICATION_FOR_POST_RATING      = "wpdiscuz_bpi_notification_for_post_rating";
	const USER_META_NOTIFICATION_FOR_APPROVED_COMMENT = "wpdiscuz_bpi_notification_for_post_rating";
	const USER_META_NOTIFICATION_FOR_MENTION          = "wpdiscuz_bpi_notification_for_mention";
	const USER_META_NOTIFICATION_FOR_REPLY            = "wpdiscuz_bpi_notification_for_reply";
	const USER_META_NOTIFICATION_FOR_COMMENT_ON_POST  = "wpdiscuz_bpi_notification_for_comment_on_post";
	const USER_META_NOTIFICATION_FOR_SUBSCRIPTIONS    = "wpdiscuz_bpi_notification_for_subscriptions";
	const USER_META_NOTIFICATION_FOR_FOLLOWS          = "wpdiscuz_bpi_notification_for_follows";
	const USER_META_EMAIL_FOR_COMMENT_VOTE            = "wpdiscuz_bpi_email_for_comment_vote";
	const USER_META_EMAIL_FOR_FOLLOW                  = "wpdiscuz_bpi_email_for_follow";
	const USER_META_EMAIL_FOR_POST_RATING             = "wpdiscuz_bpi_email_for_post_rating";
	const USER_META_EMAIL_FOR_APPROVED_COMMENT        = "wpdiscuz_bpi_email_for_post_rating";
	const USER_META_EMAIL_FOR_MENTION                 = "wpdiscuz_bpi_email_for_mention";
	const USER_META_EMAIL_FOR_REPLY                   = "wpdiscuz_bpi_email_for_reply";
	const USER_META_EMAIL_FOR_COMMENT_ON_POST         = "wpdiscuz_bpi_email_for_comment_on_post";
	const USER_META_EMAIL_FOR_SUBSCRIPTIONS           = "wpdiscuz_bpi_email_for_subscriptions";
	const USER_META_EMAIL_FOR_FOLLOWS                 = "wpdiscuz_bpi_email_for_follows";

}