<?php
if (!defined("ABSPATH")) {
	exit();
}

class wpDiscuzBPIProfileTabs implements wpDiscuzBPIConstants {

	private $options;
	private $dbmanager;

	public function __construct($options, $dbmanager) {
		$this->options = $options;
		$this->dbmanager = $dbmanager;
		add_action("bp_setup_nav", [&$this, "profileTabs"], 100);
		add_action("wp_enqueue_scripts", [&$this, "enqueueScripts"], 100);
		/* Delete Comment */
		add_action("wp_ajax_wpdBPIDelete", [$this, "delete"]);
		/* /Delete Comment */
		/* Unsubscribe */
		add_action("wp_ajax_wpdBPIUnsubscribe", [$this, "unsubscribe"]);
		/* /Unsubscribe */
		/* Unfollow */
		add_action("wp_ajax_wpdBPIUnfollow", [$this, "unfollow"]);
		/* /Unfollow */
	}

	public function profileTabs() {
		bp_core_new_nav_item([
			"name" => esc_html__($this->options->profileDiscussionsTabTitle, "wpdiscuz-buddypress-integration"),
			"slug" => "discussions",
			"component_id" => self::COMPONENT_NAME,
			"default_subnav_slug" => $this->getDefaultSubnavSlug(),
			"position" => apply_filters("wpdiscuz_bpi_discussions_tab_position", 100),
			"show_for_displayed_user" => apply_filters("wpdiscuz_bpi_user_has_access_to_discussions_tab", true),
		]);
		$parent_url = trailingslashit(bp_displayed_user_domain() . "discussions");
		if ($this->options->enableProfileCommentsTab) {
			bp_core_new_subnav_item([
				"name" => esc_html__($this->options->profileCommentsTabTitle, "wpdiscuz-buddypress-integration"),
				"slug" => "comments",
				"parent_url" => $parent_url,
				"parent_slug" => "discussions",
				"screen_function" => [$this, "commentsScreenFunction"],
				"position" => apply_filters("wpdiscuz_bpi_comments_tab_position", 1),
				"user_has_access" => apply_filters("wpdiscuz_bpi_user_has_access_to_comments_tab", true),
			]);
		}
        if ($this->options->enableProfileReactionsTab) {
            bp_core_new_subnav_item([
                "name" => esc_html__($this->options->profileReactionsTabTitle, "wpdiscuz-buddypress-integration"),
                "slug" => "reactions",
                "parent_url" => $parent_url,
                "parent_slug" => "discussions",
                "screen_function" => [$this, "reactionsScreenFunction"],
                "position" => apply_filters("wpdiscuz_bpi_reactions_tab_position", 2),
                "user_has_access" => apply_filters("wpdiscuz_bpi_user_has_access_to_reactions_tab", bp_is_my_profile()),
            ]);
        }
        if ($this->options->enableProfileRatesTab) {
            bp_core_new_subnav_item([
                "name" => esc_html__($this->options->profileRatesTabTitle, "wpdiscuz-buddypress-integration"),
                "slug" => "rates",
                "parent_url" => $parent_url,
                "parent_slug" => "discussions",
                "screen_function" => [$this, "ratesScreenFunction"],
                "position" => apply_filters("wpdiscuz_bpi_rates_tab_position", 3),
                "user_has_access" => apply_filters("wpdiscuz_bpi_user_has_access_to_rates_tab", bp_is_my_profile()),
            ]);
        }
		if ($this->options->enableProfileSubscriptionsTab) {
			bp_core_new_subnav_item([
				"name" => esc_html__($this->options->profileSubscriptionsTabTitle, "wpdiscuz-buddypress-integration"),
				"slug" => "subscriptions",
				"parent_url" => $parent_url,
				"parent_slug" => "discussions",
				"screen_function" => [$this, "subscriptionsScreenFunction"],
				"position" => apply_filters("wpdiscuz_bpi_subscriptions_tab_position", 4),
				"user_has_access" => apply_filters("wpdiscuz_bpi_user_has_access_to_subscriptions_tab", bp_is_my_profile()),
			]);
		}
		if ($this->options->enableProfileVotesTab) {
			bp_core_new_subnav_item([
				"name" => esc_html__($this->options->profileVotesTabTitle, "wpdiscuz-buddypress-integration"),
				"slug" => "votes",
				"parent_url" => $parent_url,
				"parent_slug" => "discussions",
				"screen_function" => [$this, "votesScreenFunction"],
				"position" => apply_filters("wpdiscuz_bpi_votes_tab_position", 5),
				"user_has_access" => apply_filters("wpdiscuz_bpi_user_has_access_to_votes_tab", bp_is_my_profile()),
			]);
		}
		if ($this->options->enableProfileFollowingTab) {
			bp_core_new_subnav_item([
				"name" => esc_html__($this->options->profileFollowingTabTitle, "wpdiscuz-buddypress-integration"),
				"slug" => "following",
				"parent_url" => $parent_url,
				"parent_slug" => "discussions",
				"screen_function" => [$this, "followingScreenFunction"],
				"position" => apply_filters("wpdiscuz_bpi_following_tab_position", 6),
				"user_has_access" => apply_filters("wpdiscuz_bpi_user_has_access_to_following_tab", bp_is_my_profile()),
			]);
		}
		if ($this->options->enableProfileFollowersTab) {
			bp_core_new_subnav_item([
				"name" => esc_html__($this->options->profileFollowersTabTitle, "wpdiscuz-buddypress-integration"),
				"slug" => "followers",
				"parent_url" => $parent_url,
				"parent_slug" => "discussions",
				"screen_function" => [$this, "followersScreenFunction"],
				"position" => apply_filters("wpdiscuz_bpi_followers_tab_position", 7),
				"user_has_access" => apply_filters("wpdiscuz_bpi_user_has_access_to_followers_tab", bp_is_my_profile()),
			]);
		}
	}

	public function commentsScreenFunction() {
		add_action("bp_template_content", [$this, "commentsScreenContent"]);
		bp_core_load_template(apply_filters("bp_core_template_plugin", "members/single/plugins"));
	}

	public function commentsScreenContent() {
		include_once WPD_BPI_PATH . "/includes/profile-tabs/comments.php";
	}

	public function subscriptionsScreenFunction() {
		add_action("bp_template_content", [$this, "subscriptionsScreenContent"]);
		bp_core_load_template(apply_filters("bp_core_template_plugin", "members/single/plugins"));
	}

	public function subscriptionsScreenContent() {
		include_once WPD_BPI_PATH . "/includes/profile-tabs/subscriptions.php";
	}

	public function reactionsScreenFunction() {
		add_action("bp_template_content", [$this, "reactionsScreenContent"]);
		bp_core_load_template(apply_filters("bp_core_template_plugin", "members/single/plugins"));
	}

	public function reactionsScreenContent() {
		include_once WPD_BPI_PATH . "/includes/profile-tabs/reactions.php";
	}

	public function ratesScreenFunction() {
		add_action("bp_template_content", [$this, "ratesScreenContent"]);
		bp_core_load_template(apply_filters("bp_core_template_plugin", "members/single/plugins"));
	}

	public function ratesScreenContent() {
		include_once WPD_BPI_PATH . "/includes/profile-tabs/rates.php";
	}

	public function votesScreenFunction() {
		add_action("bp_template_content", [$this, "votesScreenContent"]);
		bp_core_load_template(apply_filters("bp_core_template_plugin", "members/single/plugins"));
	}

	public function votesScreenContent() {
		include_once WPD_BPI_PATH . "/includes/profile-tabs/votes.php";
	}

	public function followingScreenFunction() {
		add_action("bp_template_content", [$this, "followingScreenContent"]);
		bp_core_load_template(apply_filters("bp_core_template_plugin", "members/single/plugins"));
	}

	public function followingScreenContent() {
		include_once WPD_BPI_PATH . "/includes/profile-tabs/following.php";
	}

	public function followersScreenFunction() {
		add_action("bp_template_content", [$this, "followersScreenContent"]);
		bp_core_load_template(apply_filters("bp_core_template_plugin", "members/single/plugins"));
	}

	public function followersScreenContent() {
		include_once WPD_BPI_PATH . "/includes/profile-tabs/followers.php";
	}

	public function enqueueScripts() {
		if (bp_is_user()) {
			if (is_rtl()) {
				wp_register_style("wpdiscuz-bpi-rtl", plugins_url(WPD_BPI_DIR_NAME . "/assets/css/wpdiscuz-bpi-rtl.css"));
				wp_enqueue_style("wpdiscuz-bpi-rtl");
			} else {
				wp_register_style("wpdiscuz-bpi", plugins_url(WPD_BPI_DIR_NAME . "/assets/css/wpdiscuz-bpi.css"));
				wp_enqueue_style("wpdiscuz-bpi");
			}
			wp_register_script("wpdiscuz-bpi", plugins_url(WPD_BPI_DIR_NAME . "/assets/js/wpdiscuz-bpi.js"), ["jquery"], "1.0.0", true);
			wp_enqueue_script("wpdiscuz-bpi");
			wp_localize_script("wpdiscuz-bpi", "wpDiscuzBPIObj", [
				"url" => admin_url("admin-ajax.php"),
				"confirmDelete" => esc_html__("Are you sure you want to delete this comment?", "wpdiscuz-buddypress-integration"),
				"confirmUnsubscribe" => esc_html__("Are you sure you want to cancel this subscription?", "wpdiscuz-buddypress-integration"),
				"confirmUnfollow" => esc_html__("Are you sure you want to cancel this follow?", "wpdiscuz-buddypress-integration"),
			]);
		}
	}

	/* Delete Comment */
	public function delete() {
		$commentId = isset($_POST["id"]) ? intval($_POST["id"]) : 0;
		$currentUser = WpdiscuzHelper::getCurrentUser();
		if ($commentId && !empty($currentUser->ID) && $this->options->enableProfileCommentsTab && ($comment = get_comment($commentId)) && intval($currentUser->ID) === intval($comment->user_id)) {
			wp_delete_comment($commentId, true);
			wp_send_json_success();
		}
		wp_send_json_error();
	}
	/* /Delete Comment */

	/* Unsubscribe */
	public function unsubscribe() {
		$subscriptionId = isset($_POST["id"]) ? intval($_POST["id"]) : 0;
		$currentUser = WpdiscuzHelper::getCurrentUser();
		$wpdiscuz = wpDiscuz();
		if ($subscriptionId && !empty($currentUser->ID) && $this->options->enableProfileSubscriptionsTab && ($subscription = $wpdiscuz->dbManager->getSubscriptionById($subscriptionId)) && $currentUser->user_email === $subscription->email) {
			$wpdiscuz->dbManager->unsubscribeById($subscriptionId);
			wp_send_json_success();
		}
		wp_send_json_error();
	}
	/* /Unsubscribe */

	/* Unfollow */
	public function unfollow() {
		$followId = isset($_POST["id"]) ? intval($_POST["id"]) : 0;
		$currentUser = WpdiscuzHelper::getCurrentUser();
		$wpdiscuz = wpDiscuz();
		if ($followId && !empty($currentUser->ID) && $this->options->enableProfileFollowingTab && ($follow = $wpdiscuz->dbManager->getFollowById($followId)) && $currentUser->ID === intval($follow->follower_id)) {
			$wpdiscuz->dbManager->unfollowById($followId);
			wp_send_json_success();
		}
		wp_send_json_error();
	}
	/* /Unfollow */

	private function getDefaultSubnavSlug() {
		if ($this->options->enableProfileCommentsTab) {
			return "comments";
		} else if ($this->options->enableProfileSubscriptionsTab) {
			return "subscriptions";
		} else if ($this->options->enableProfileReactionsTab) {
			return "reactions";
		} else if ($this->options->enableProfileRatesTab) {
			return "rates";
		} else if ($this->options->enableProfileVotesTab) {
			return "votes";
		} else if ($this->options->enableProfileFollowingTab) {
			return "following";
		} else if ($this->options->enableProfileFollowersTab) {
			return "followers";
		}
		return "";
	}

}