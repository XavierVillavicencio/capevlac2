<?php
if (!defined("ABSPATH")) {
	exit();
}

class wpDiscuzBPIActivity implements wpDiscuzBPIConstants {

	private $options;
	private $dbmanager;

	public function __construct($options, $dbmanager) {
		$this->options = $options;
		$this->dbmanager = $dbmanager;
		/* COMMENT VOTE */
		add_action("wpdiscuz_add_vote", [$this, "addVote"], 999, 2);
		add_action("wpdiscuz_update_vote", [$this, "updateVote"], 999, 3);
		add_action("wpdiscuz_remove_vote_data", [$this, "removeVoteData"], 999);
		add_action("deleted_comment", [$this, "commentDeleted"], 999, 2);
		/* /COMMENT VOTE */
		/* POST RATING */
		add_action("wpdiscuz_add_rating", [$this, "addRating"], 999, 2);
		add_action("wpdiscuz_clean_post_cache", [$this, "removeRatings"], 999, 2);
		add_action("deleted_post", [$this, "postDeleted"], 999);
		/* /POST RATING */
		/* TOOLS */
		add_filter("wpdiscuz_dashboard_tools", [$this, "addTools"]);
		add_action("wp_ajax_wpdBPICheckCommentsCount", [&$this, "checkCommentsCount"]);
		add_action("wp_ajax_wpdBPIImportComments", [&$this, "importComments"]);
		add_action("wp_ajax_wpdBPICheckCommentsVotesCount", [&$this, "checkCommentsVotesCount"]);
		add_action("wp_ajax_wpdBPIImportCommentVotes", [&$this, "importCommentVotes"]);
		add_action("wp_ajax_wpdBPICheckPostRatingsCount", [&$this, "checkPostRatingsCount"]);
		add_action("wp_ajax_wpdBPIImportPostRatings", [&$this, "importPostRatings"]);
		add_action("admin_enqueue_scripts", [$this, "enqueueScripts"]);
		/* /TOOLS */
		/* COMMON */
		add_action("bp_register_activity_actions", [$this, "registerActivityActions"], 999);
		add_filter("bp_activity_mini_activity_types", [$this, "miniActivityTypes"], 999);
		add_filter("buddyx_bp_get_activity_css_first_class", [$this, "cssFirstClass"], 999);
		add_filter("bp_get_activity_content_body", [$this, "applyCommentTextFilter"], 999, 2);
		/* /COMMON */
	}

	/* COMMENT VOTE */
	public function addVote($voteType, $comment) {
		if ($this->options->activityForCommentVote) {
			$currentUser = WpdiscuzHelper::getCurrentUser();
			if ($currentUser->ID) {
				if ($commenter = get_user_by("id", $comment->user_id)) {
					$commenterName = $commenter->display_name;
					$commenterUrl = bp_core_get_user_domain($commenter->ID);
				} else {
					$commenterName = $comment->comment_author;
					$commenterUrl = $comment->comment_author_url;
				}
				$commentLink = get_comment_link($comment);
				$action = str_replace(["[VOTER_NAME]", "[VOTER_URL]", "[COMMENT_AUTHOR_NAME]", "[COMMENT_AUTHOR_URL]", "[COMMENT_URL]", "[POST_TITLE]", "[POST_URL]"], [$currentUser->display_name, bp_core_get_user_domain($currentUser->ID), $commenterName, $commenterUrl, $commentLink, get_the_title($comment->comment_post_ID), get_the_permalink($comment->comment_post_ID)], $voteType > 0 ? $this->options->commentUpvoteActivityMessage : $this->options->commentDownvoteActivityMessage);
				bp_activity_add([
					"action"            => $action,
					"content"           => "",
					"component"         => self::COMPONENT_NAME,
					"type"              => $voteType > 0 ? self::ACTIVITY_TYPE_COMMENT_UPVOTE : self::ACTIVITY_TYPE_COMMENT_DOWNVOTE,
					"primary_link"      => $commentLink,
					"user_id"           => $currentUser->ID,
					"item_id"           => $comment->comment_ID,
					"secondary_item_id" => $comment->user_id,
					"recorded_time"     => bp_core_current_time(),
				]);
			}
		}
	}

	public function updateVote($voteType, $isUserVoted, $comment) {
		$currentUser = WpdiscuzHelper::getCurrentUser();
		if ($currentUser->ID) {
			$totalVote = $voteType + $isUserVoted;
			$commentLink = get_comment_link($comment);
			if ($totalVote === 0) {
				bp_activity_delete([
					"content" => "",
					"component" => self::COMPONENT_NAME,
					"type" => $isUserVoted > 0 ? self::ACTIVITY_TYPE_COMMENT_UPVOTE : self::ACTIVITY_TYPE_COMMENT_DOWNVOTE,
					"primary_link" => $commentLink,
					"user_id" => $currentUser->ID,
					"item_id" => $comment->comment_ID,
					"secondary_item_id" => $comment->user_id,
				]);
			} else if ($this->options->activityForCommentVote) {
				if ($commenter = get_user_by("id", $comment->user_id)) {
					$commenterName = $commenter->display_name;
					$commenterUrl = bp_core_get_user_domain($commenter->ID);
				} else {
					$commenterName = $comment->comment_author;
					$commenterUrl = $comment->comment_author_url;
				}
				$action = str_replace(["[VOTER_NAME]", "[VOTER_URL]", "[COMMENT_AUTHOR_NAME]", "[COMMENT_AUTHOR_URL]", "[COMMENT_URL]", "[POST_TITLE]", "[POST_URL]"], [$currentUser->display_name, bp_core_get_user_domain($currentUser->ID), $commenterName, $commenterUrl, $commentLink, get_the_title($comment->comment_post_ID), get_the_permalink($comment->comment_post_ID)], $totalVote > 0 ? $this->options->commentUpvoteActivityMessage : $this->options->commentDownvoteActivityMessage);
				bp_activity_add([
					"action"            => $action,
					"content"           => "",
					"component"         => self::COMPONENT_NAME,
					"type"              => $voteType > 0 ? self::ACTIVITY_TYPE_COMMENT_UPVOTE : self::ACTIVITY_TYPE_COMMENT_DOWNVOTE,
					"primary_link"      => $commentLink,
					"user_id"           => $currentUser->ID,
					"item_id"           => $comment->comment_ID,
					"secondary_item_id" => $comment->user_id,
					"recorded_time"     => bp_core_current_time(),
				]);
			}
		}
	}

	public function removeVoteData() {
		$this->dbmanager->deleteActivitiesByType([self::ACTIVITY_TYPE_COMMENT_UPVOTE, self::ACTIVITY_TYPE_COMMENT_DOWNVOTE]);
	}

	public function commentDeleted($comment_ID, $comment) {
		$this->dbmanager->deleteActivities($comment_ID, [self::ACTIVITY_TYPE_COMMENT_UPVOTE, self::ACTIVITY_TYPE_COMMENT_DOWNVOTE]);
	}
	/* /COMMENT VOTE */

	/* POST RATING */
	public function addRating($rating, $post_id) {
		if ($this->options->activityForPostRating) {
			$post = get_post($post_id);
			$currentUser = WpdiscuzHelper::getCurrentUser();
			if ($currentUser->ID != $post->post_author) {
				$postAuthor = get_user_by("id", $post->post_author);
				$postUrl = get_the_permalink($post);
				$action = str_replace(["[RATER_NAME]", "[RATER_URL]", "[POST_AUTHOR_NAME]", "[POST_AUTHOR_URL]", "[RATING]", "[POST_TITLE]", "[POST_URL]"], [$currentUser->display_name, bp_core_get_user_domain($currentUser->ID), $postAuthor->display_name, bp_core_get_user_domain($postAuthor->ID), $rating, get_the_title($post), $postUrl], $this->options->postRatingActivityMessage);
				bp_activity_add([
					"action"            => $action,
					"content"           => "",
					"component"         => self::COMPONENT_NAME,
					"type"              => self::ACTIVITY_TYPE_POST_RATING,
					"primary_link"      => $postUrl,
					"user_id"           => $currentUser->ID,
					"item_id"           => $post->ID,
					"secondary_item_id" => $post->post_author,
					"recorded_time"     => bp_core_current_time(),
				]);
			}
		}
	}

	public function removeRatings($postId, $action) {
		if ($action === "ratings_reset") {
			$this->dbmanager->deleteActivities($postId, [self::ACTIVITY_TYPE_POST_RATING]);
		}
	}

	public function postDeleted($postId) {
		$this->dbmanager->deleteActivities($postId, [self::ACTIVITY_TYPE_POST_RATING]);
	}
	/* /POST RATING */

	/* TOOLS */
	public function addTools($tools) {
		$tools[] = ["selector" => "bpi-import-activity", "file" => WPD_BPI_PATH . "/options/tool-import-activity.php", "object" => $this->dbmanager];
		return $tools;
	}

	/* COMMENTS */
	public function checkCommentsCount() {
		$response = ["count" => 0];
		$importComments = isset($_POST["importComments"]) ? $_POST["importComments"] : "";
		if ($importComments) {
			parse_str($importComments, $data);
			$startDate = isset($data["import-comments-to-activity-start-date"]) ? trim($data["import-comments-to-activity-start-date"]) : "";
			$endDate = isset($data["import-comments-to-activity-end-date"]) ? trim($data["import-comments-to-activity-end-date"]) : "";
			$nonce = isset($data["wpdiscuz-bpi-import-comments"]) ? trim($data["wpdiscuz-bpi-import-comments"]) : "";
			if (wp_verify_nonce($nonce, "wc_tools_form")) {
				$response["count"] = $this->dbmanager->checkCommentsCount($startDate, $endDate);
			}
		}
		wp_die(json_encode($response));
	}

	public function importComments() {
		$response = ["progress" => 0];
		$importComments = isset($_POST["importComments"]) ? $_POST["importComments"] : "";
		if ($importComments) {
			parse_str($importComments, $data);
			$limit = !empty($data["import-comments-to-activity-limit"]) ? intval($data["import-comments-to-activity-limit"]) : 50;
			$step = isset($data["import-comments-to-activity-step"]) ? intval($data["import-comments-to-activity-step"]) : 0;
			$startDate = isset($data["import-comments-to-activity-start-date"]) ? trim($data["import-comments-to-activity-start-date"]) : "";
			$endDate = isset($data["import-comments-to-activity-end-date"]) ? trim($data["import-comments-to-activity-end-date"]) : "";
			$importCommentsCount = isset($data["import-comments-to-activity-count"]) ? intval($data["import-comments-to-activity-count"]) : 0;
			$importCommentsStartId = isset($data["import-comments-to-activity-start-id"]) ? intval($data["import-comments-to-activity-start-id"]) : 0;
			$nonce = isset($data["wpdiscuz-bpi-import-comments"]) ? trim($data["wpdiscuz-bpi-import-comments"]) : "";
			if (wp_verify_nonce($nonce, "wc_tools_form") && $importCommentsCount && $importCommentsStartId >= 0 && $limit) {
				$importCommentsData = $this->dbmanager->getImportComments($importCommentsStartId, $limit, $startDate, $endDate);
				if ($importCommentsData) {
					$this->importCommentsToActivity($importCommentsData);
					++$step;
					$progress = $step * $limit * 100 / $importCommentsCount;
					$response["progress"] = ($p = intval($progress)) > 100 ? 100 : $p;
					$response["startId"] = $importCommentsData[count($importCommentsData) - 1];
				} else {
					$response["progress"] = 100;
					$response["startId"] = 0;
				}
				$response["step"] = $step;
			}
		}
		wp_die(json_encode($response));
	}

	public function importCommentsToActivity($results) {
		$blog_id = get_current_blog_id();
		$blog_url = get_home_url( $blog_id );
		$blog_name = get_blog_option($blog_id, "blogname");
		foreach ($results as $k => $result) {
			if ($comment = get_comment($result)) {
				$post_url = get_the_permalink($comment->comment_post_ID);
				$post_title = get_the_title($comment->comment_post_ID);
				$args = [
					"component" => "blogs",
					"type" => "new_blog_comment",
					"primary_link" => get_comment_link($comment),
					"user_id" => $comment->user_id,
					"item_id" => get_current_blog_id(),
					"secondary_item_id" => $comment->comment_ID,
					"recorded_time" => $comment->comment_date_gmt,
				];
				$args["content"] = bp_activity_create_summary($comment->comment_content, $args);
				if (is_multisite()) {
					$args["action"] = sprintf(
						esc_html_x('%1$s commented on the post, %2$s, on the site %3$s', "`new_blog_comment` activity action", "buddypress"),
						bp_core_get_userlink($comment->user_id),
						"<a href='" . esc_url($post_url) . "'>" . esc_html($post_title) . "</a>",
						"<a href='" . esc_url($blog_url) . "'>" . esc_html($blog_name) . "</a>"
					);
				} else {
					$args["action"] = sprintf(
						esc_html_x('%1$s commented on the post, %2$s', "`new_blog_comment` activity action", "buddypress"),
						bp_core_get_userlink($comment->user_id),
						"<a href='" . esc_url($post_url) . "'>" . esc_html($post_title) . "</a>"
					);
				}
				$activity_id = bp_activity_add($args);
				bp_activity_update_meta($activity_id, "post_title", $post_title);
				bp_activity_update_meta($activity_id, "post_url",   esc_url_raw($post_url));
			}
		}
	}
	/* /COMMENTS */

	/* VOTES */
	public function checkCommentsVotesCount() {
		$response = ["count" => 0];
		$importCommentVotes = isset($_POST["importCommentVotes"]) ? $_POST["importCommentVotes"] : "";
		if ($importCommentVotes) {
			parse_str($importCommentVotes, $data);
			$startDate = isset($data["import-votes-to-activity-start-date"]) ? trim($data["import-votes-to-activity-start-date"]) : "";
			$endDate = isset($data["import-votes-to-activity-end-date"]) ? trim($data["import-votes-to-activity-end-date"]) : "";
			$nonce = isset($data["wpdiscuz-bpi-import-votes"]) ? trim($data["wpdiscuz-bpi-import-votes"]) : "";
			if (wp_verify_nonce($nonce, "wc_tools_form")) {
				$response["count"] = $this->dbmanager->checkCommentsVotesCount($startDate, $endDate);
			}
		}
		wp_die(json_encode($response));
	}

	public function importCommentVotes() {
		$response = ["progress" => 0];
		$importCommentVotes = isset($_POST["importCommentVotes"]) ? $_POST["importCommentVotes"] : "";
		if ($importCommentVotes) {
			parse_str($importCommentVotes, $data);
			$limit = !empty($data["import-votes-to-activity-limit"]) ? intval($data["import-votes-to-activity-limit"]) : 50;
			$step = isset($data["import-votes-to-activity-step"]) ? intval($data["import-votes-to-activity-step"]) : 0;
			$startDate = isset($data["import-votes-to-activity-start-date"]) ? trim($data["import-votes-to-activity-start-date"]) : "";
			$endDate = isset($data["import-votes-to-activity-end-date"]) ? trim($data["import-votes-to-activity-end-date"]) : "";
			$importCommentVotesCount = isset($data["import-votes-to-activity-count"]) ? intval($data["import-votes-to-activity-count"]) : 0;
			$importCommentVotesStartId = isset($data["import-votes-to-activity-start-id"]) ? intval($data["import-votes-to-activity-start-id"]) : 0;
			$nonce = isset($data["wpdiscuz-bpi-import-votes"]) ? trim($data["wpdiscuz-bpi-import-votes"]) : "";
			if (wp_verify_nonce($nonce, "wc_tools_form") && $importCommentVotesCount && $importCommentVotesStartId >= 0 && $limit) {
				$importCommentVotesData = $this->dbmanager->getImportCommentVotes($importCommentVotesStartId, $limit, $startDate, $endDate);
				if ($importCommentVotesData) {
					$this->importCommentVotesToActivity($importCommentVotesData);
					++$step;
					$progress = $step * $limit * 100 / $importCommentVotesCount;
					$response["progress"] = ($p = intval($progress)) > 100 ? 100 : $p;
					$response["startId"] = $importCommentVotesData[count($importCommentVotesData) - 1]->id;
				} else {
					$response["progress"] = 100;
					$response["startId"] = 0;
				}
				$response["step"] = $step;
			}
		}
		wp_die(json_encode($response));
	}

	public function importCommentVotesToActivity($results) {
		foreach ($results as $k => $result) {
			$user = get_user_by("id", $result->user_id);
			$comment = get_comment($result->comment_id);
			if ($user->ID && $comment) {
				if ($commenter = get_user_by("id", $comment->user_id)) {
					$commenterName = $commenter->display_name;
					$commenterUrl = bp_core_get_user_domain($commenter->ID);
				} else {
					$commenterName = $comment->comment_author;
					$commenterUrl = $comment->comment_author_url;
				}
				$commentLink = get_comment_link($comment);
				$action = str_replace(["[VOTER_NAME]", "[VOTER_URL]", "[COMMENT_AUTHOR_NAME]", "[COMMENT_AUTHOR_URL]", "[COMMENT_URL]", "[POST_TITLE]", "[POST_URL]"], [$user->display_name, bp_core_get_user_domain($user->ID), $commenterName, $commenterUrl, $commentLink, get_the_title($comment->comment_post_ID), get_the_permalink($comment->comment_post_ID)], $result->vote_type > 0 ? $this->options->commentUpvoteActivityMessage : $this->options->commentDownvoteActivityMessage);
				bp_activity_add([
					"action"            => $action,
					"content"           => "",
					"component"         => self::COMPONENT_NAME,
					"type"              => $result->vote_type > 0 ? self::ACTIVITY_TYPE_COMMENT_UPVOTE : self::ACTIVITY_TYPE_COMMENT_DOWNVOTE,
					"primary_link"      => $commentLink,
					"user_id"           => $user->ID,
					"item_id"           => $comment->comment_ID,
					"secondary_item_id" => $comment->user_id,
					"recorded_time"     => date("Y-m-d H:i:s", $result->date),
				]);
			}
		}
	}
	/* /VOTES */

	/* RATINGS */
	public function checkPostRatingsCount() {
		$response = ["count" => 0];
		$importPostRatings = isset($_POST["importPostRatings"]) ? $_POST["importPostRatings"] : "";
		if ($importPostRatings) {
			parse_str($importPostRatings, $data);
			$startDate = isset($data["import-ratings-to-activity-start-date"]) ? trim($data["import-ratings-to-activity-start-date"]) : "";
			$endDate = isset($data["import-ratings-to-activity-end-date"]) ? trim($data["import-ratings-to-activity-end-date"]) : "";
			$nonce = isset($data["wpdiscuz-bpi-import-ratings"]) ? trim($data["wpdiscuz-bpi-import-ratings"]) : "";
			if (wp_verify_nonce($nonce, "wc_tools_form")) {
				$response["count"] = $this->dbmanager->checkPostRatingsCount($startDate, $endDate);
			}
		}
		wp_die(json_encode($response));
	}

	public function importPostRatings() {
		$response = ["progress" => 0];
		$importPostRatings = isset($_POST["importPostRatings"]) ? $_POST["importPostRatings"] : "";
		if ($importPostRatings) {
			parse_str($importPostRatings, $data);
			$limit = !empty($data["import-ratings-to-activity-limit"]) ? intval($data["import-ratings-to-activity-limit"]) : 50;
			$step = isset($data["import-ratings-to-activity-step"]) ? intval($data["import-ratings-to-activity-step"]) : 0;
			$startDate = isset($data["import-ratings-to-activity-start-date"]) ? trim($data["import-ratings-to-activity-start-date"]) : "";
			$endDate = isset($data["import-ratings-to-activity-end-date"]) ? trim($data["import-ratings-to-activity-end-date"]) : "";
			$importPostRatingsCount = isset($data["import-ratings-to-activity-count"]) ? intval($data["import-ratings-to-activity-count"]) : 0;
			$importPostRatingsStartId = isset($data["import-ratings-to-activity-start-id"]) ? intval($data["import-ratings-to-activity-start-id"]) : 0;
			$nonce = isset($data["wpdiscuz-bpi-import-ratings"]) ? trim($data["wpdiscuz-bpi-import-ratings"]) : "";
			if (wp_verify_nonce($nonce, "wc_tools_form") && $importPostRatingsCount && $importPostRatingsStartId >= 0 && $limit) {
				$importPostRatingsData = $this->dbmanager->getImportPostRatings($importPostRatingsStartId, $limit, $startDate, $endDate);
				if ($importPostRatingsData) {
					$this->importPostRatingsToActivity($importPostRatingsData);
					++$step;
					$progress = $step * $limit * 100 / $importPostRatingsCount;
					$response["progress"] = ($p = intval($progress)) > 100 ? 100 : $p;
					$response["startId"] = $importPostRatingsData[count($importPostRatingsData) - 1]->id;
				} else {
					$response["progress"] = 100;
					$response["startId"] = 0;
				}
				$response["step"] = $step;
			}
		}
		wp_die(json_encode($response));
	}

	public function importPostRatingsToActivity($results) {
		foreach ($results as $k => $result) {
			$post = get_post($result->post_id);
			$user = get_user_by("id", $result->user_id);
			if ($user->ID != $post->post_author) {
				$postAuthor = get_user_by("id", $post->post_author);
				$postUrl = get_the_permalink($post);
				$action = str_replace(["[RATER_NAME]", "[RATER_URL]", "[POST_AUTHOR_NAME]", "[POST_AUTHOR_URL]", "[RATING]", "[POST_TITLE]", "[POST_URL]"], [$user->display_name, bp_core_get_user_domain($user->ID), $postAuthor->display_name, bp_core_get_user_domain($postAuthor->ID), $result->rating, get_the_title($post), $postUrl], $this->options->postRatingActivityMessage);
				bp_activity_add([
					"action"            => $action,
					"content"           => "",
					"component"         => self::COMPONENT_NAME,
					"type"              => self::ACTIVITY_TYPE_POST_RATING,
					"primary_link"      => $postUrl,
					"user_id"           => $user->ID,
					"item_id"           => $post->ID,
					"secondary_item_id" => $post->post_author,
					"recorded_time"     => date("Y-m-d H:i:s", $result->date),
				]);
			}
		}
	}
	/* /RATINGS */

	public function enqueueScripts() {
		global $pagenow;
		if (isset($_GET["page"]) && $pagenow === "admin.php" && $_GET["page"] === WpdiscuzCore::PAGE_TOOLS) {
			wp_enqueue_script("jquery-ui-datepicker");
			wp_enqueue_style("jquery-ui-datepicker-css", "http://ajax.googleapis.com/ajax/libs/jqueryui/1.9.0/themes/base/jquery-ui.css");
			wp_enqueue_style("jquery-ui-datepicker");
			wp_register_script("wpdiscuz-bpi", plugins_url(basename(WPD_BPI_PATH) . "/assets/js/wpdiscuz-bpi-options.js"), ["jquery"]);
			wp_enqueue_script("wpdiscuz-bpi");
		}
	}
	/* /TOOLS */

	/* COMMON */
	public function registerActivityActions() {
		bp_activity_set_action(self::COMPONENT_NAME, self::ACTIVITY_TYPE_COMMENT_UPVOTE, __("Comment upvote", "wpdiscuz-buddypress-integration"));
		bp_activity_set_action(self::COMPONENT_NAME, self::ACTIVITY_TYPE_COMMENT_DOWNVOTE, __("Comment downvote", "wpdiscuz-buddypress-integration"));
		bp_activity_set_action(self::COMPONENT_NAME, self::ACTIVITY_TYPE_POST_RATING, __("Post rating", "wpdiscuz-buddypress-integration"));
	}

	public function miniActivityTypes($types) {
		$types[] = self::ACTIVITY_TYPE_COMMENT_UPVOTE;
		$types[] = self::ACTIVITY_TYPE_COMMENT_DOWNVOTE;
		$types[] = self::ACTIVITY_TYPE_POST_RATING;
		return $types;
	}

	public function cssFirstClass($type) {
		if ($type === self::COMPONENT_NAME) {
			$type = "blogs";
		}
		return $type;
	}

	public function applyCommentTextFilter($content, $activity = null) {
		if ($activity && $activity->component === "blogs" && $activity->type === "new_blog_comment" && ($comment = get_comment($activity->secondary_item_id))) {
			$content = apply_filters("comment_text", $content, $comment, ["is_wpdiscuz_comment" => true]);
		}
		return $content;
	}
	/* /COMMON */

}