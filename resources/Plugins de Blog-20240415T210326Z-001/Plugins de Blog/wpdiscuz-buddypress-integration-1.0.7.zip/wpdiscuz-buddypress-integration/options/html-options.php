<?php
if (!defined("ABSPATH")) {
    exit();
}

if (!bp_is_active("activity")) {
    ?>
    <div style="margin: 15px 0 10px 0; padding-bottom: 5px; background: #f9f3e4; border: 1px dashed #dd767d; padding: 15px;">
        <p style="margin: 0; font-weight: bold; font-size: 15px;"><?php esc_html_e("BuddyPress Activity is disabled!", "wpdiscuz-buddypress-integration"); ?></p>
        <p style="margin: 0;"><?php esc_html_e("Please enable BuddyPress Activity in the Settings > BuddyPress admin page if you want to use the wpDiscuz activity integration features.", "wpdiscuz-buddypress-integration"); ?></p>
    </div>
	<?php
}
if (!bp_is_active("notifications")) {
    ?>
    <div style="margin: 15px 0 10px 0; padding-bottom: 5px; background: #f9f3e4; border: 1px dashed #dd767d; padding: 15px;">
        <p style="margin: 0; font-weight: bold; font-size: 15px;"><?php esc_html_e("BuddyPress Notification is disabled!", "wpdiscuz-buddypress-integration"); ?></p>
        <p style="margin: 0;"><?php esc_html_e("Please enable BuddyPress Notification in the Settings > BuddyPress admin page if you want to use the wpDiscuz notification integration features.", "wpdiscuz-buddypress-integration"); ?></p>
    </div>
    <?php
}
?>

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="changeUserSettingsButton" style="border-bottom: none;">
    <div class="wpd-opt-name">
        <label for="changeUserSettingsButton"><?php echo esc_html($setting["options"]["changeUserSettingsButton"]["label"]) ?></label>
        <p class="wpd-desc">
            <?php echo $setting["options"]["changeUserSettingsButton"]["description"] ?><br><br>
            <img src ='<?php echo plugins_url(WPD_BPI_DIR_NAME) ?>/assets/img/my-settings-btn.png' style='max-width:615px;' />
        </p>
    </div>
    <div class="wpd-opt-input">
        <div class="wpd-switcher">
            <input type="checkbox" <?php checked($setting["values"]->changeUserSettingsButton == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[changeUserSettingsButton]" id="changeUserSettingsButton">
            <label for="changeUserSettingsButton"></label>
        </div>
    </div>
</div>
<!-- Option end -->

<div class="wpd-subtitle">
    <?php esc_html_e("Profile Tabs", "wpdiscuz-buddypress-integration") ?>
</div>

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="enabledProfileTabs">
    <div class="wpd-opt-name">
        <label for="enabledProfileTabs"><?php echo esc_html($setting["options"]["enabledProfileTabs"]["label"]) ?></label>
        <p class="wpd-desc">
            <?php echo $setting["options"]["enabledProfileTabs"]["description"] ?><br><br>
            <img src ='<?php echo plugins_url(WPD_BPI_DIR_NAME) ?>/assets/img/profile-discussions-settings-tab.png' style='max-width: 100%;' />
        </p>
    </div>
    <div class="wpd-opt-input">
        <div>
            <input type="checkbox" <?php checked($setting["values"]->enableProfileCommentsTab == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[enableProfileCommentsTab]" id="enableProfileCommentsTab" style="margin:0px; vertical-align: middle;" />
            <label for="enableProfileCommentsTab"><?php esc_html_e("Comments", "wpdiscuz-buddypress-integration"); ?></label>
        </div>
        <div>
            <input type="checkbox" <?php checked($setting["values"]->enableProfileSubscriptionsTab == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[enableProfileSubscriptionsTab]" id="enableProfileSubscriptionsTab" style="margin:0px; vertical-align: middle;" />
            <label for="enableProfileSubscriptionsTab"><?php esc_html_e("Subscriptions", "wpdiscuz-buddypress-integration"); ?></label>
        </div>
        <div>
            <input type="checkbox" <?php checked($setting["values"]->enableProfileReactionsTab == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[enableProfileReactionsTab]" id="enableProfileReactionsTab" style="margin:0px; vertical-align: middle;" />
            <label for="enableProfileReactionsTab"><?php esc_html_e("Reactions", "wpdiscuz-buddypress-integration"); ?></label>
        </div>
        <div>
            <input type="checkbox" <?php checked($setting["values"]->enableProfileRatesTab == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[enableProfileRatesTab]" id="enableProfileRatesTab" style="margin:0px; vertical-align: middle;" />
            <label for="enableProfileRatesTab"><?php esc_html_e("Rates", "wpdiscuz-buddypress-integration"); ?></label>
        </div>
        <div>
            <input type="checkbox" <?php checked($setting["values"]->enableProfileVotesTab == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[enableProfileVotesTab]" id="enableProfileVotesTab" style="margin:0px; vertical-align: middle;" />
            <label for="enableProfileVotesTab"><?php esc_html_e("Votes", "wpdiscuz-buddypress-integration"); ?></label>
        </div>
        <div>
            <input type="checkbox" <?php checked($setting["values"]->enableProfileFollowingTab == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[enableProfileFollowingTab]" id="enableProfileFollowingTab" style="margin:0px; vertical-align: middle;" />
            <label for="enableProfileFollowingTab"><?php esc_html_e("Following", "wpdiscuz-buddypress-integration"); ?></label>
        </div>
        <div>
            <input type="checkbox" <?php checked($setting["values"]->enableProfileFollowersTab == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[enableProfileFollowersTab]" id="enableProfileFollowersTab" style="margin:0px; vertical-align: middle;" />
            <label for="enableProfileFollowersTab"><?php esc_html_e("Followers", "wpdiscuz-buddypress-integration"); ?></label>
        </div>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="profileDiscussionsTabTitle">
    <div class="wpd-opt-name">
        <label for="profileDiscussionsTabTitle"><?php echo $setting["options"]["profileDiscussionsTabTitle"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["profileDiscussionsTabTitle"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
        <input type="text" name="<?php echo $setting["values"]->tabKey; ?>[profileDiscussionsTabTitle]" value="<?php echo esc_attr($setting["values"]->profileDiscussionsTabTitle); ?>" id="profileDiscussionsTabTitle" style="margin:1px;padding:3px 5px; width:90%;"/>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="profileCommentsTabTitle">
    <div class="wpd-opt-name">
        <label for="profileCommentsTabTitle"><?php echo $setting["options"]["profileCommentsTabTitle"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["profileCommentsTabTitle"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
        <input type="text" name="<?php echo $setting["values"]->tabKey; ?>[profileCommentsTabTitle]" value="<?php echo esc_attr($setting["values"]->profileCommentsTabTitle); ?>" id="profileCommentsTabTitle" style="margin:1px;padding:3px 5px; width:90%;"/>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="profileSubscriptionsTabTitle">
    <div class="wpd-opt-name">
        <label for="profileSubscriptionsTabTitle"><?php echo $setting["options"]["profileSubscriptionsTabTitle"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["profileSubscriptionsTabTitle"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
        <input type="text" name="<?php echo $setting["values"]->tabKey; ?>[profileSubscriptionsTabTitle]" value="<?php echo esc_attr($setting["values"]->profileSubscriptionsTabTitle); ?>" id="profileSubscriptionsTabTitle" style="margin:1px;padding:3px 5px; width:90%;"/>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="profileReactionsTabTitle">
    <div class="wpd-opt-name">
        <label for="profileReactionsTabTitle"><?php echo $setting["options"]["profileReactionsTabTitle"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["profileReactionsTabTitle"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
        <input type="text" name="<?php echo $setting["values"]->tabKey; ?>[profileReactionsTabTitle]" value="<?php echo esc_attr($setting["values"]->profileReactionsTabTitle); ?>" id="profileReactionsTabTitle" style="margin:1px;padding:3px 5px; width:90%;"/>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="profileRatesTabTitle">
    <div class="wpd-opt-name">
        <label for="profileRatesTabTitle"><?php echo $setting["options"]["profileRatesTabTitle"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["profileRatesTabTitle"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
        <input type="text" name="<?php echo $setting["values"]->tabKey; ?>[profileRatesTabTitle]" value="<?php echo esc_attr($setting["values"]->profileRatesTabTitle); ?>" id="profileRatesTabTitle" style="margin:1px;padding:3px 5px; width:90%;"/>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="profileVotesTabTitle">
    <div class="wpd-opt-name">
        <label for="profileVotesTabTitle"><?php echo $setting["options"]["profileVotesTabTitle"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["profileVotesTabTitle"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
        <input type="text" name="<?php echo $setting["values"]->tabKey; ?>[profileVotesTabTitle]" value="<?php echo esc_attr($setting["values"]->profileVotesTabTitle); ?>" id="profileVotesTabTitle" style="margin:1px;padding:3px 5px; width:90%;"/>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="profileFollowingTabTitle">
    <div class="wpd-opt-name">
        <label for="profileFollowingTabTitle"><?php echo $setting["options"]["profileFollowingTabTitle"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["profileFollowingTabTitle"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
        <input type="text" name="<?php echo $setting["values"]->tabKey; ?>[profileFollowingTabTitle]" value="<?php echo esc_attr($setting["values"]->profileFollowingTabTitle); ?>" id="profileFollowingTabTitle" style="margin:1px;padding:3px 5px; width:90%;"/>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="profileFollowersTabTitle">
    <div class="wpd-opt-name">
        <label for="profileFollowersTabTitle"><?php echo $setting["options"]["profileFollowersTabTitle"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["profileFollowersTabTitle"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
        <input type="text" name="<?php echo $setting["values"]->tabKey; ?>[profileFollowersTabTitle]" value="<?php echo esc_attr($setting["values"]->profileFollowersTabTitle); ?>" id="profileFollowersTabTitle" style="margin:1px;padding:3px 5px; width:90%;"/>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="guestPhrase">
    <div class="wpd-opt-name">
        <label for="guestPhrase"><?php echo $setting["options"]["guestPhrase"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["guestPhrase"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
        <input type="text" name="<?php echo $setting["values"]->tabKey; ?>[guestPhrase]" value="<?php echo esc_attr($setting["values"]->guestPhrase); ?>" id="guestPhrase" style="margin:1px;padding:3px 5px; width:90%;"/>
    </div>
</div>
<!-- Option end -->

<div class="wpd-subtitle" style="margin-top: 20px;">
    <?php esc_html_e("Activity", "wpdiscuz-buddypress-integration") ?>
</div>

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="enabledActivities">
    <div class="wpd-opt-name">
        <label for="enabledActivities"><?php echo esc_html($setting["options"]["enabledActivities"]["label"]) ?></label>
        <p class="wpd-desc">
            <?php echo $setting["options"]["enabledActivities"]["description"] ?><br><br>
            <img src ='<?php echo plugins_url(WPD_BPI_DIR_NAME) ?>/assets/img/profile-activities-tab.png' style='max-width: 100%;' />
        </p>
    </div>
    <div class="wpd-opt-input">
        <div style="padding-bottom: 3px;">
            <input type="checkbox" <?php checked($setting["values"]->activityForCommentVote == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[activityForCommentVote]" id="activityForCommentVote" style="margin:0px; vertical-align: middle;" />
            <label for="activityForCommentVote"><?php esc_html_e("Voting a comment", "wpdiscuz-buddypress-integration"); ?></label>
        </div>
        <div>
            <input type="checkbox" <?php checked($setting["values"]->activityForPostRating == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[activityForPostRating]" id="activityForPostRating" style="margin:0px; vertical-align: middle;" />
            <label for="activityForPostRating"><?php esc_html_e("Rating a post", "wpdiscuz-buddypress-integration"); ?></label>
        </div>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="commentUpvoteActivityMessage">
    <div class="wpd-opt-name">
        <label for="commentUpvoteActivityMessage"><?php echo $setting["options"]["commentUpvoteActivityMessage"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["commentUpvoteActivityMessage"]["description"] ?></p>
        <p class="wpd-desc"><?php esc_html_e("Available shortcodes", "wpdiscuz-buddypress-integration"); ?>:
        <p class="wpd-desc">
            <span class="wc_available_variable">[AUTHOR_NAME]</span><br>
            <span class="wc_available_variable">[AUTHOR_URL]</span><br>
            <span class="wc_available_variable">[COMMENT_AUTHOR_NAME]</span><br>
            <span class="wc_available_variable">[COMMENT_AUTHOR_URL]</span><br>
            <span class="wc_available_variable">[COMMENT_URL]</span><br>
            <span class="wc_available_variable">[POST_TITLE]</span><br>
            <span class="wc_available_variable">[POST_URL]</span>
        </p>
    </div>
    <div class="wpd-opt-input">
        <?php wp_editor($setting["values"]->commentUpvoteActivityMessage, "commentUpvoteActivityMessage", ["textarea_name" => $setting["values"]->tabKey . "[commentUpvoteActivityMessage]", "textarea_rows" => 4, "teeny" => true]); ?>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="commentDownvoteActivityMessage">
    <div class="wpd-opt-name">
        <label for="commentDownvoteActivityMessage"><?php echo $setting["options"]["commentDownvoteActivityMessage"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["commentDownvoteActivityMessage"]["description"] ?></p>
        <p class="wpd-desc"><?php esc_html_e("Available shortcodes", "wpdiscuz-buddypress-integration"); ?>:
        <p class="wpd-desc">
            <span class="wc_available_variable">[VOTER_NAME]</span><br>
            <span class="wc_available_variable">[VOTER_URL]</span><br>
            <span class="wc_available_variable">[COMMENT_AUTHOR_NAME]</span><br>
            <span class="wc_available_variable">[COMMENT_AUTHOR_URL]</span><br>
            <span class="wc_available_variable">[COMMENT_URL]</span><br>
            <span class="wc_available_variable">[POST_TITLE]</span><br>
            <span class="wc_available_variable">[POST_URL]</span>
        </p>
    </div>
    <div class="wpd-opt-input">
        <?php wp_editor($setting["values"]->commentDownvoteActivityMessage, "commentDownvoteActivityMessage", ["textarea_name" => $setting["values"]->tabKey . "[commentDownvoteActivityMessage]", "textarea_rows" => 4, "teeny" => true]); ?>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="postRatingActivityMessage" style="border-bottom: none;">
    <div class="wpd-opt-name">
        <label for="postRatingActivityMessage"><?php echo $setting["options"]["postRatingActivityMessage"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["postRatingActivityMessage"]["description"] ?></p>
        <p class="wpd-desc"><?php esc_html_e("Available shortcodes", "wpdiscuz-buddypress-integration"); ?>:
        <p class="wpd-desc">
            <span class="wc_available_variable">[RATER_NAME]</span><br>
            <span class="wc_available_variable">[RATER_URL]</span><br>
            <span class="wc_available_variable">[POST_AUTHOR_NAME]</span><br>
            <span class="wc_available_variable">[POST_AUTHOR_URL]</span><br>
            <span class="wc_available_variable">[RATING]</span><br>
            <span class="wc_available_variable">[POST_TITLE]</span><br>
            <span class="wc_available_variable">[POST_URL]</span>
        </p>
    </div>
    <div class="wpd-opt-input">
        <?php wp_editor($setting["values"]->postRatingActivityMessage, "postRatingActivityMessage", ["textarea_name" => $setting["values"]->tabKey . "[postRatingActivityMessage]", "textarea_rows" => 4, "teeny" => true]); ?>
    </div>
</div>
<!-- Option end -->


<div class="wpd-subtitle" style="margin-top: 20px;">
	<?php esc_html_e("Notifications", "wpdiscuz-buddypress-integration") ?>
</div>

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="notificationSettingsTabTitle">
    <div class="wpd-opt-name">
        <label for="notificationSettingsTabTitle"><?php echo $setting["options"]["notificationSettingsTabTitle"]["label"] ?></label>
        <p class="wpd-desc">
            <?php echo $setting["options"]["notificationSettingsTabTitle"]["description"] ?><br><br>
            <img src ='<?php echo plugins_url(WPD_BPI_DIR_NAME) ?>/assets/img/profile-notifications-settings-tab.png' style='max-width: 100%;' />
        </p>
    </div>
    <div class="wpd-opt-input">
        <input type="text" name="<?php echo $setting["values"]->tabKey; ?>[notificationSettingsTabTitle]" value="<?php echo esc_attr($setting["values"]->notificationSettingsTabTitle); ?>" id="notificationSettingsTabTitle" style="margin:1px;padding:3px 5px; width:90%;"/>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="enabledNotifications">
	<div class="wpd-opt-name">
		<label for="enabledNotifications"><?php echo esc_html($setting["options"]["enabledNotifications"]["label"]) ?></label>
		<p class="wpd-desc"><?php echo $setting["options"]["enabledNotifications"]["description"] ?></p>
	</div>
	<div class="wpd-opt-input">
		<div>
			<input type="checkbox" <?php checked($setting["values"]->notificationForCommentVote == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[notificationForCommentVote]" id="notificationForCommentVote" style="margin:0px; vertical-align: middle;" />
			<label for="notificationForCommentVote"><?php esc_html_e("Someone votes on my comment", "wpdiscuz-buddypress-integration"); ?></label>
		</div>
		<div>
			<input type="checkbox" <?php checked($setting["values"]->notificationForFollow == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[notificationForFollow]" id="notificationForFollow" style="margin:0px; vertical-align: middle;" />
			<label for="notificationForFollow"><?php esc_html_e("Someone follows me", "wpdiscuz-buddypress-integration"); ?></label>
		</div>
		<div>
			<input type="checkbox" <?php checked($setting["values"]->notificationForPostRating == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[notificationForPostRating]" id="notificationForPostRating" style="margin:0px; vertical-align: middle;" />
			<label for="notificationForPostRating"><?php esc_html_e("Someone rated my post", "wpdiscuz-buddypress-integration"); ?></label>
		</div>
		<div>
			<input type="checkbox" <?php checked($setting["values"]->notificationForApprovedComment == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[notificationForApprovedComment]" id="notificationForApprovedComment" style="margin:0px; vertical-align: middle;" />
			<label for="notificationForApprovedComment"><?php esc_html_e("My comment is approved", "wpdiscuz-buddypress-integration"); ?></label>
		</div>
		<div>
			<input type="checkbox" <?php checked($setting["values"]->notificationForReply == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[notificationForReply]" id="notificationForReply" style="margin:0px; vertical-align: middle;" />
			<label for="notificationForReply"><?php esc_html_e("Someone replied to my comment", "wpdiscuz-buddypress-integration"); ?></label>
		</div>
		<div>
			<input type="checkbox" <?php checked($setting["values"]->notificationForCommentOnPost == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[notificationForCommentOnPost]" id="notificationForCommentOnPost" style="margin:0px; vertical-align: middle;" />
			<label for="notificationForCommentOnPost"><?php esc_html_e("Someone commented on my post", "wpdiscuz-buddypress-integration"); ?></label>
		</div>
        <div>
            <input type="checkbox" <?php checked($setting["values"]->notificationForMention == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[notificationForMention]" id="notificationForMention" style="margin:0px; vertical-align: middle;" />
            <label for="notificationForMention"><?php esc_html_e("Someone mentioned me", "wpdiscuz-buddypress-integration"); ?></label>
        </div>
		<div>
			<input type="checkbox" <?php checked($setting["values"]->notificationForSubscriptions == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[notificationForSubscriptions]" id="notificationForSubscriptions" style="margin:0px; vertical-align: middle;" />
			<label for="notificationForSubscriptions"><?php esc_html_e("New comment on subscribed post", "wpdiscuz-buddypress-integration"); ?></label>
		</div>
		<div>
			<input type="checkbox" <?php checked($setting["values"]->notificationForFollows == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[notificationForFollows]" id="notificationForFollows" style="margin:0px; vertical-align: middle;" />
			<label for="notificationForFollows"><?php esc_html_e("New comment by followed user", "wpdiscuz-buddypress-integration"); ?></label>
		</div>
	</div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="defaultNotifications">
	<div class="wpd-opt-name">
		<label for="defaultNotifications"><?php echo esc_html($setting["options"]["defaultNotifications"]["label"]) ?></label>
		<p class="wpd-desc"><?php echo $setting["options"]["defaultNotifications"]["description"] ?></p>
	</div>
	<div class="wpd-opt-input">
		<?php
		if ($setting["values"]->notificationForCommentVote) {
			?>
			<div>
				<input type="checkbox" <?php checked($setting["values"]->notificationForCommentVoteForNewUsers == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[notificationForCommentVoteForNewUsers]" id="notificationForCommentVoteForNewUsers" style="margin:0px; vertical-align: middle;" />
				<label for="notificationForCommentVoteForNewUsers"><?php esc_html_e("Someone votes on my comment", "wpdiscuz-buddypress-integration"); ?></label>
			</div>
			<?php
		}
		if ($setting["values"]->notificationForFollow) {
			?>
			<div>
				<input type="checkbox" <?php checked($setting["values"]->notificationForFollowForNewUsers == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[notificationForFollowForNewUsers]" id="notificationForFollowForNewUsers" style="margin:0px; vertical-align: middle;" />
				<label for="notificationForFollowForNewUsers"><?php esc_html_e("Someone follows me", "wpdiscuz-buddypress-integration"); ?></label>
			</div>
			<?php
		}
		if ($setting["values"]->notificationForPostRating) {
			?>
			<div>
				<input type="checkbox" <?php checked($setting["values"]->notificationForPostRatingForNewUsers == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[notificationForPostRatingForNewUsers]" id="notificationForPostRatingForNewUsers" style="margin:0px; vertical-align: middle;" />
				<label for="notificationForPostRatingForNewUsers"><?php esc_html_e("Someone rated my post", "wpdiscuz-buddypress-integration"); ?></label>
			</div>
			<?php
		}
		if ($setting["values"]->notificationForApprovedComment) {
			?>
			<div>
				<input type="checkbox" <?php checked($setting["values"]->notificationForApprovedCommentForNewUsers == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[notificationForApprovedCommentForNewUsers]" id="notificationForApprovedCommentForNewUsers" style="margin:0px; vertical-align: middle;" />
				<label for="notificationForApprovedCommentForNewUsers"><?php esc_html_e("My comment is approved", "wpdiscuz-buddypress-integration"); ?></label>
			</div>
			<?php
		}
		if ($setting["values"]->notificationForReply) {
			?>
			<div>
				<input type="checkbox" <?php checked($setting["values"]->notificationForReplyForNewUsers == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[notificationForReplyForNewUsers]" id="notificationForReplyForNewUsers" style="margin:0px; vertical-align: middle;" />
				<label for="notificationForReplyForNewUsers"><?php esc_html_e("Someone replied to my comment", "wpdiscuz-buddypress-integration"); ?></label>
			</div>
			<?php
		}
		if ($setting["values"]->notificationForCommentOnPost) {
			?>
			<div>
				<input type="checkbox" <?php checked($setting["values"]->notificationForCommentOnPostForNewUsers == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[notificationForCommentOnPostForNewUsers]" id="notificationForCommentOnPostForNewUsers" style="margin:0px; vertical-align: middle;" />
				<label for="notificationForCommentOnPostForNewUsers"><?php esc_html_e("Someone commented on my post", "wpdiscuz-buddypress-integration"); ?></label>
			</div>
			<?php
		}
		if ($setting["values"]->notificationForMention) {
			?>
            <div>
                <input type="checkbox" <?php checked($setting["values"]->notificationForMentionForNewUsers == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[notificationForMentionForNewUsers]" id="notificationForMentionForNewUsers" style="margin:0px; vertical-align: middle;" />
                <label for="notificationForMentionForNewUsers"><?php esc_html_e("Someone mentioned me", "wpdiscuz-buddypress-integration"); ?></label>
            </div>
			<?php
		}
		if ($setting["values"]->notificationForSubscriptions) {
			?>
			<div>
				<input type="checkbox" <?php checked($setting["values"]->notificationForSubscriptionsForNewUsers == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[notificationForSubscriptionsForNewUsers]" id="notificationForSubscriptionsForNewUsers" style="margin:0px; vertical-align: middle;" />
				<label for="notificationForSubscriptionsForNewUsers"><?php esc_html_e("New comment on subscribed post", "wpdiscuz-buddypress-integration"); ?></label>
			</div>
			<?php
		}
		if ($setting["values"]->notificationForFollows) {
			?>
			<div>
				<input type="checkbox" <?php checked($setting["values"]->notificationForFollowsForNewUsers == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[notificationForFollowsForNewUsers]" id="notificationForFollowsForNewUsers" style="margin:0px; vertical-align: middle;" />
				<label for="notificationForFollowsForNewUsers"><?php esc_html_e("New comment by followed user", "wpdiscuz-buddypress-integration"); ?></label>
			</div>
			<?php
		}
		?>
	</div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="enabledEmailNotifications">
    <div class="wpd-opt-name">
        <label for="enabledEmailNotifications"><?php echo esc_html($setting["options"]["enabledEmailNotifications"]["label"]) ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["enabledEmailNotifications"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
        <div>
            <input type="checkbox" <?php checked($setting["values"]->emailForCommentVote == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[emailForCommentVote]" id="emailForCommentVote" style="margin:0px; vertical-align: middle;" />
            <label for="emailForCommentVote"><?php esc_html_e("Someone votes on my comment", "wpdiscuz-buddypress-integration"); ?></label>
        </div>
        <div>
            <input type="checkbox" <?php checked($setting["values"]->emailForFollow == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[emailForFollow]" id="emailForFollow" style="margin:0px; vertical-align: middle;" />
            <label for="emailForFollow"><?php esc_html_e("Someone follows me", "wpdiscuz-buddypress-integration"); ?></label>
        </div>
        <div>
            <input type="checkbox" <?php checked($setting["values"]->emailForPostRating == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[emailForPostRating]" id="emailForPostRating" style="margin:0px; vertical-align: middle;" />
            <label for="emailForPostRating"><?php esc_html_e("Someone rated my post", "wpdiscuz-buddypress-integration"); ?></label>
        </div>
        <div>
            <input type="checkbox" <?php checked($setting["values"]->emailForApprovedComment == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[emailForApprovedComment]" id="emailForApprovedComment" style="margin:0px; vertical-align: middle;" />
            <label for="emailForApprovedComment"><?php esc_html_e("My comment is approved", "wpdiscuz-buddypress-integration"); ?></label>
        </div>
        <div>
            <input type="checkbox" <?php checked($setting["values"]->emailForReply == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[emailForReply]" id="emailForReply" style="margin:0px; vertical-align: middle;" />
            <label for="emailForReply"><?php esc_html_e("Someone replied to my comment", "wpdiscuz-buddypress-integration"); ?></label>
        </div>
        <div>
            <input type="checkbox" <?php checked($setting["values"]->emailForCommentOnPost == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[emailForCommentOnPost]" id="emailForCommentOnPost" style="margin:0px; vertical-align: middle;" />
            <label for="emailForCommentOnPost"><?php esc_html_e("Someone commented on my post", "wpdiscuz-buddypress-integration"); ?></label>
        </div>
        <div>
            <input type="checkbox" <?php checked($setting["values"]->emailForMention == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[emailForMention]" id="emailForMention" style="margin:0px; vertical-align: middle;" />
            <label for="emailForMention"><?php esc_html_e("Someone mentioned me", "wpdiscuz-buddypress-integration"); ?></label>
        </div>
        <div>
            <input type="checkbox" <?php checked($setting["values"]->emailForSubscriptions == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[emailForSubscriptions]" id="emailForSubscriptions" style="margin:0px; vertical-align: middle;" />
            <label for="emailForSubscriptions"><?php esc_html_e("New comment on subscribed post", "wpdiscuz-buddypress-integration"); ?></label>
        </div>
        <div>
            <input type="checkbox" <?php checked($setting["values"]->emailForFollows == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[emailForFollows]" id="emailForFollows" style="margin:0px; vertical-align: middle;" />
            <label for="emailForFollows"><?php esc_html_e("New comment by followed user", "wpdiscuz-buddypress-integration"); ?></label>
        </div>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="defaultEmailNotifications">
    <div class="wpd-opt-name">
        <label for="defaultEmailNotifications"><?php echo esc_html($setting["options"]["defaultEmailNotifications"]["label"]) ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["defaultEmailNotifications"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
		<?php
		if ($setting["values"]->emailForCommentVote) {
			?>
            <div>
                <input type="checkbox" <?php checked($setting["values"]->emailForCommentVoteForNewUsers == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[emailForCommentVoteForNewUsers]" id="emailForCommentVoteForNewUsers" style="margin:0px; vertical-align: middle;" />
                <label for="emailForCommentVoteForNewUsers"><?php esc_html_e("Someone votes on my comment", "wpdiscuz-buddypress-integration"); ?></label>
            </div>
			<?php
		}
		if ($setting["values"]->emailForFollow) {
			?>
            <div>
                <input type="checkbox" <?php checked($setting["values"]->emailForFollowForNewUsers == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[emailForFollowForNewUsers]" id="emailForFollowForNewUsers" style="margin:0px; vertical-align: middle;" />
                <label for="emailForFollowForNewUsers"><?php esc_html_e("Someone follows me", "wpdiscuz-buddypress-integration"); ?></label>
            </div>
			<?php
		}
		if ($setting["values"]->emailForPostRating) {
			?>
            <div>
                <input type="checkbox" <?php checked($setting["values"]->emailForPostRatingForNewUsers == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[emailForPostRatingForNewUsers]" id="emailForPostRatingForNewUsers" style="margin:0px; vertical-align: middle;" />
                <label for="emailForPostRatingForNewUsers"><?php esc_html_e("Someone rated my post", "wpdiscuz-buddypress-integration"); ?></label>
            </div>
			<?php
		}
		if ($setting["values"]->emailForApprovedComment) {
			?>
            <div>
                <input type="checkbox" <?php checked($setting["values"]->emailForApprovedCommentForNewUsers == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[emailForApprovedCommentForNewUsers]" id="emailForApprovedCommentForNewUsers" style="margin:0px; vertical-align: middle;" />
                <label for="emailForApprovedCommentForNewUsers"><?php esc_html_e("My comment is approved", "wpdiscuz-buddypress-integration"); ?></label>
            </div>
			<?php
		}
		if ($setting["values"]->emailForReply) {
			?>
            <div>
                <input type="checkbox" <?php checked($setting["values"]->emailForReplyForNewUsers == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[emailForReplyForNewUsers]" id="emailForReplyForNewUsers" style="margin:0px; vertical-align: middle;" />
                <label for="emailForReplyForNewUsers"><?php esc_html_e("Someone replied to my comment", "wpdiscuz-buddypress-integration"); ?></label>
            </div>
			<?php
		}
		if ($setting["values"]->emailForCommentOnPost) {
			?>
            <div>
                <input type="checkbox" <?php checked($setting["values"]->emailForCommentOnPostForNewUsers == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[emailForCommentOnPostForNewUsers]" id="emailForCommentOnPostForNewUsers" style="margin:0px; vertical-align: middle;" />
                <label for="emailForCommentOnPostForNewUsers"><?php esc_html_e("Someone commented on my post", "wpdiscuz-buddypress-integration"); ?></label>
            </div>
			<?php
		}
		if ($setting["values"]->emailForMention) {
			?>
            <div>
                <input type="checkbox" <?php checked($setting["values"]->emailForMentionForNewUsers == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[emailForMentionForNewUsers]" id="emailForMentionForNewUsers" style="margin:0px; vertical-align: middle;" />
                <label for="emailForMentionForNewUsers"><?php esc_html_e("Someone mentioned me", "wpdiscuz-buddypress-integration"); ?></label>
            </div>
			<?php
		}
		if ($setting["values"]->emailForSubscriptions) {
			?>
            <div>
                <input type="checkbox" <?php checked($setting["values"]->emailForSubscriptionsForNewUsers == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[emailForSubscriptionsForNewUsers]" id="emailForSubscriptionsForNewUsers" style="margin:0px; vertical-align: middle;" />
                <label for="emailForSubscriptionsForNewUsers"><?php esc_html_e("New comment on subscribed post", "wpdiscuz-buddypress-integration"); ?></label>
            </div>
			<?php
		}
		if ($setting["values"]->emailForFollows) {
			?>
            <div>
                <input type="checkbox" <?php checked($setting["values"]->emailForFollowsForNewUsers == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[emailForFollowsForNewUsers]" id="emailForFollowsForNewUsers" style="margin:0px; vertical-align: middle;" />
                <label for="emailForFollowsForNewUsers"><?php esc_html_e("New comment by followed user", "wpdiscuz-buddypress-integration"); ?></label>
            </div>
			<?php
		}
		?>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="commentUpvoteNotificationMessage">
	<div class="wpd-opt-name">
		<label for="commentUpvoteNotificationMessage"><?php echo $setting["options"]["commentUpvoteNotificationMessage"]["label"] ?></label>
		<p class="wpd-desc"><?php echo $setting["options"]["commentUpvoteNotificationMessage"]["description"] ?></p>
		<p class="wpd-desc"><?php esc_html_e("Available shortcodes", "wpdiscuz-buddypress-integration"); ?>:
		<p class="wpd-desc">
			<span class="wc_available_variable">[VOTER_NAME]</span><br>
			<span class="wc_available_variable">[VOTER_URL]</span><br>
			<span class="wc_available_variable">[COMMENT_URL]</span>
		</p>
	</div>
	<div class="wpd-opt-input">
		<?php wp_editor($setting["values"]->commentUpvoteNotificationMessage, "commentUpvoteNotificationMessage", ["textarea_name" => $setting["values"]->tabKey . "[commentUpvoteNotificationMessage]", "textarea_rows" => 4, "teeny" => true]); ?>
	</div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="multipleCommentUpvoteNotificationsMessage">
    <div class="wpd-opt-name">
        <label for="multipleCommentUpvoteNotificationsMessage"><?php echo $setting["options"]["multipleCommentUpvoteNotificationsMessage"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["multipleCommentUpvoteNotificationsMessage"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
        <input type="text" name="<?php echo $setting["values"]->tabKey; ?>[multipleCommentUpvoteNotificationsMessage]" value="<?php echo esc_attr($setting["values"]->multipleCommentUpvoteNotificationsMessage); ?>" id="multipleCommentUpvoteNotificationsMessage" style="margin:1px;padding:3px 5px; width:90%;"/>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="commentDownvoteNotificationMessage">
	<div class="wpd-opt-name">
		<label for="commentDownvoteNotificationMessage"><?php echo $setting["options"]["commentDownvoteNotificationMessage"]["label"] ?></label>
		<p class="wpd-desc"><?php echo $setting["options"]["commentDownvoteNotificationMessage"]["description"] ?></p>
		<p class="wpd-desc"><?php esc_html_e("Available shortcodes", "wpdiscuz-buddypress-integration"); ?>:
		<p class="wpd-desc">
			<span class="wc_available_variable">[VOTER_NAME]</span><br>
			<span class="wc_available_variable">[VOTER_URL]</span><br>
			<span class="wc_available_variable">[COMMENT_URL]</span>
		</p>
	</div>
	<div class="wpd-opt-input">
		<?php wp_editor($setting["values"]->commentDownvoteNotificationMessage, "commentDownvoteNotificationMessage", ["textarea_name" => $setting["values"]->tabKey . "[commentDownvoteNotificationMessage]", "textarea_rows" => 4, "teeny" => true]); ?>
	</div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="multipleCommentDownvoteNotificationsMessage">
    <div class="wpd-opt-name">
        <label for="multipleCommentDownvoteNotificationsMessage"><?php echo $setting["options"]["multipleCommentDownvoteNotificationsMessage"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["multipleCommentDownvoteNotificationsMessage"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
        <input type="text" name="<?php echo $setting["values"]->tabKey; ?>[multipleCommentDownvoteNotificationsMessage]" value="<?php echo esc_attr($setting["values"]->multipleCommentDownvoteNotificationsMessage); ?>" id="multipleCommentDownvoteNotificationsMessage" style="margin:1px;padding:3px 5px; width:90%;"/>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="followNotificationMessage">
	<div class="wpd-opt-name">
		<label for="followNotificationMessage"><?php echo $setting["options"]["followNotificationMessage"]["label"] ?></label>
		<p class="wpd-desc"><?php echo $setting["options"]["followNotificationMessage"]["description"] ?></p>
		<p class="wpd-desc"><?php esc_html_e("Available shortcodes", "wpdiscuz-buddypress-integration"); ?>:
		<p class="wpd-desc">
			<span class="wc_available_variable">[FOLLOWER_NAME]</span><br>
			<span class="wc_available_variable">[FOLLOWER_URL]</span>
		</p>
	</div>
	<div class="wpd-opt-input">
		<?php wp_editor($setting["values"]->followNotificationMessage, "followNotificationMessage", ["textarea_name" => $setting["values"]->tabKey . "[followNotificationMessage]", "textarea_rows" => 4, "teeny" => true]); ?>
	</div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="multipleFollowNotificationsMessage">
    <div class="wpd-opt-name">
        <label for="multipleFollowNotificationsMessage"><?php echo $setting["options"]["multipleFollowNotificationsMessage"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["multipleFollowNotificationsMessage"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
        <input type="text" name="<?php echo $setting["values"]->tabKey; ?>[multipleFollowNotificationsMessage]" value="<?php echo esc_attr($setting["values"]->multipleFollowNotificationsMessage); ?>" id="multipleFollowNotificationsMessage" style="margin:1px;padding:3px 5px; width:90%;"/>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="postRatingNotificationMessage">
	<div class="wpd-opt-name">
		<label for="postRatingNotificationMessage"><?php echo $setting["options"]["postRatingNotificationMessage"]["label"] ?></label>
		<p class="wpd-desc"><?php echo $setting["options"]["postRatingNotificationMessage"]["description"] ?></p>
		<p class="wpd-desc"><?php esc_html_e("Available shortcodes", "wpdiscuz-buddypress-integration"); ?>:
		<p class="wpd-desc">
			<span class="wc_available_variable">[RATER_NAME]</span><br>
			<span class="wc_available_variable">[RATER_URL]</span><br>
			<span class="wc_available_variable">[POST_TITLE]</span><br>
			<span class="wc_available_variable">[POST_URL]</span><br>
			<span class="wc_available_variable">[RATING]</span>
		</p>
	</div>
	<div class="wpd-opt-input">
		<?php wp_editor($setting["values"]->postRatingNotificationMessage, "postRatingNotificationMessage", ["textarea_name" => $setting["values"]->tabKey . "[postRatingNotificationMessage]", "textarea_rows" => 4, "teeny" => true]); ?>
	</div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="multiplePostRatingNotificationsMessage">
    <div class="wpd-opt-name">
        <label for="multiplePostRatingNotificationsMessage"><?php echo $setting["options"]["multiplePostRatingNotificationsMessage"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["multiplePostRatingNotificationsMessage"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
        <input type="text" name="<?php echo $setting["values"]->tabKey; ?>[multiplePostRatingNotificationsMessage]" value="<?php echo esc_attr($setting["values"]->multiplePostRatingNotificationsMessage); ?>" id="multiplePostRatingNotificationsMessage" style="margin:1px;padding:3px 5px; width:90%;"/>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="approvedCommentNotificationMessage">
	<div class="wpd-opt-name">
		<label for="approvedCommentNotificationMessage"><?php echo $setting["options"]["approvedCommentNotificationMessage"]["label"] ?></label>
		<p class="wpd-desc"><?php echo $setting["options"]["approvedCommentNotificationMessage"]["description"] ?></p>
		<p class="wpd-desc"><?php esc_html_e("Available shortcodes", "wpdiscuz-buddypress-integration"); ?>:
		<p class="wpd-desc">
			<span class="wc_available_variable">[COMMENT_URL]</span>
		</p>
	</div>
	<div class="wpd-opt-input">
		<?php wp_editor($setting["values"]->approvedCommentNotificationMessage, "approvedCommentNotificationMessage", ["textarea_name" => $setting["values"]->tabKey . "[approvedCommentNotificationMessage]", "textarea_rows" => 4, "teeny" => true]); ?>
	</div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="multipleApprovedCommentNotificationsMessage">
    <div class="wpd-opt-name">
        <label for="multipleApprovedCommentNotificationsMessage"><?php echo $setting["options"]["multipleApprovedCommentNotificationsMessage"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["multipleApprovedCommentNotificationsMessage"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
        <input type="text" name="<?php echo $setting["values"]->tabKey; ?>[multipleApprovedCommentNotificationsMessage]" value="<?php echo esc_attr($setting["values"]->multipleApprovedCommentNotificationsMessage); ?>" id="multipleApprovedCommentNotificationsMessage" style="margin:1px;padding:3px 5px; width:90%;"/>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="mentionNotificationMessage">
	<div class="wpd-opt-name">
		<label for="mentionNotificationMessage"><?php echo $setting["options"]["mentionNotificationMessage"]["label"] ?></label>
		<p class="wpd-desc"><?php echo $setting["options"]["mentionNotificationMessage"]["description"] ?></p>
		<p class="wpd-desc"><?php esc_html_e("Available shortcodes", "wpdiscuz-buddypress-integration"); ?>:
		<p class="wpd-desc">
			<span class="wc_available_variable">[AUTHOR_NAME]</span><br>
			<span class="wc_available_variable">[AUTHOR_URL]</span><br>
			<span class="wc_available_variable">[COMMENT_URL]</span>
		</p>
	</div>
	<div class="wpd-opt-input">
		<?php wp_editor($setting["values"]->mentionNotificationMessage, "mentionNotificationMessage", ["textarea_name" => $setting["values"]->tabKey . "[mentionNotificationMessage]", "textarea_rows" => 4, "teeny" => true]); ?>
	</div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="multipleMentionNotificationsMessage">
    <div class="wpd-opt-name">
        <label for="multipleMentionNotificationsMessage"><?php echo $setting["options"]["multipleMentionNotificationsMessage"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["multipleMentionNotificationsMessage"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
        <input type="text" name="<?php echo $setting["values"]->tabKey; ?>[multipleMentionNotificationsMessage]" value="<?php echo esc_attr($setting["values"]->multipleMentionNotificationsMessage); ?>" id="multipleMentionNotificationsMessage" style="margin:1px;padding:3px 5px; width:90%;"/>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="replyNotificationMessage">
	<div class="wpd-opt-name">
		<label for="replyNotificationMessage"><?php echo $setting["options"]["replyNotificationMessage"]["label"] ?></label>
		<p class="wpd-desc"><?php echo $setting["options"]["replyNotificationMessage"]["description"] ?></p>
		<p class="wpd-desc"><?php esc_html_e("Available shortcodes", "wpdiscuz-buddypress-integration"); ?>:
		<p class="wpd-desc">
			<span class="wc_available_variable">[AUTHOR_NAME]</span><br>
			<span class="wc_available_variable">[AUTHOR_URL]</span><br>
			<span class="wc_available_variable">[COMMENT_URL]</span><br>
			<span class="wc_available_variable">[POST_TITLE]</span><br>
			<span class="wc_available_variable">[POST_URL]</span>
		</p>
	</div>
	<div class="wpd-opt-input">
		<?php wp_editor($setting["values"]->replyNotificationMessage, "replyNotificationMessage", ["textarea_name" => $setting["values"]->tabKey . "[replyNotificationMessage]", "textarea_rows" => 4, "teeny" => true]); ?>
	</div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="multipleReplyNotificationsMessage">
    <div class="wpd-opt-name">
        <label for="multipleReplyNotificationsMessage"><?php echo $setting["options"]["multipleReplyNotificationsMessage"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["multipleReplyNotificationsMessage"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
        <input type="text" name="<?php echo $setting["values"]->tabKey; ?>[multipleReplyNotificationsMessage]" value="<?php echo esc_attr($setting["values"]->multipleReplyNotificationsMessage); ?>" id="multipleReplyNotificationsMessage" style="margin:1px;padding:3px 5px; width:90%;"/>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="commentOnPostNotificationMessage">
	<div class="wpd-opt-name">
		<label for="commentOnPostNotificationMessage"><?php echo $setting["options"]["commentOnPostNotificationMessage"]["label"] ?></label>
		<p class="wpd-desc"><?php echo $setting["options"]["commentOnPostNotificationMessage"]["description"] ?></p>
		<p class="wpd-desc"><?php esc_html_e("Available shortcodes", "wpdiscuz-buddypress-integration"); ?>:
		<p class="wpd-desc">
			<span class="wc_available_variable">[AUTHOR_NAME]</span><br>
			<span class="wc_available_variable">[AUTHOR_URL]</span><br>
			<span class="wc_available_variable">[COMMENT_URL]</span><br>
			<span class="wc_available_variable">[POST_TITLE]</span><br>
			<span class="wc_available_variable">[POST_URL]</span>
		</p>
	</div>
	<div class="wpd-opt-input">
		<?php wp_editor($setting["values"]->commentOnPostNotificationMessage, "commentOnPostNotificationMessage", ["textarea_name" => $setting["values"]->tabKey . "[commentOnPostNotificationMessage]", "textarea_rows" => 4, "teeny" => true]); ?>
	</div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="multipleCommentOnPostNotificationsMessage">
    <div class="wpd-opt-name">
        <label for="multipleCommentOnPostNotificationsMessage"><?php echo $setting["options"]["multipleCommentOnPostNotificationsMessage"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["multipleCommentOnPostNotificationsMessage"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
        <input type="text" name="<?php echo $setting["values"]->tabKey; ?>[multipleCommentOnPostNotificationsMessage]" value="<?php echo esc_attr($setting["values"]->multipleCommentOnPostNotificationsMessage); ?>" id="multipleCommentOnPostNotificationsMessage" style="margin:1px;padding:3px 5px; width:90%;"/>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="subscriptionsNotificationMessage">
	<div class="wpd-opt-name">
		<label for="subscriptionsNotificationMessage"><?php echo $setting["options"]["subscriptionsNotificationMessage"]["label"] ?></label>
		<p class="wpd-desc"><?php echo $setting["options"]["subscriptionsNotificationMessage"]["description"] ?></p>
		<p class="wpd-desc"><?php esc_html_e("Available shortcodes", "wpdiscuz-buddypress-integration"); ?>:
		<p class="wpd-desc">
			<span class="wc_available_variable">[AUTHOR_NAME]</span><br>
			<span class="wc_available_variable">[AUTHOR_URL]</span><br>
			<span class="wc_available_variable">[COMMENT_URL]</span><br>
			<span class="wc_available_variable">[POST_TITLE]</span><br>
			<span class="wc_available_variable">[POST_URL]</span>
		</p>
	</div>
	<div class="wpd-opt-input">
		<?php wp_editor($setting["values"]->subscriptionsNotificationMessage, "subscriptionsNotificationMessage", ["textarea_name" => $setting["values"]->tabKey . "[subscriptionsNotificationMessage]", "textarea_rows" => 4, "teeny" => true]); ?>
	</div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="multipleSubscriptionsNotificationsMessage">
    <div class="wpd-opt-name">
        <label for="multipleSubscriptionsNotificationsMessage"><?php echo $setting["options"]["multipleSubscriptionsNotificationsMessage"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["multipleSubscriptionsNotificationsMessage"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
        <input type="text" name="<?php echo $setting["values"]->tabKey; ?>[multipleSubscriptionsNotificationsMessage]" value="<?php echo esc_attr($setting["values"]->multipleSubscriptionsNotificationsMessage); ?>" id="multipleSubscriptionsNotificationsMessage" style="margin:1px;padding:3px 5px; width:90%;"/>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="followsNotificationMessage">
	<div class="wpd-opt-name">
		<label for="followsNotificationMessage"><?php echo $setting["options"]["followsNotificationMessage"]["label"] ?></label>
		<p class="wpd-desc"><?php echo $setting["options"]["followsNotificationMessage"]["description"] ?></p>
		<p class="wpd-desc"><?php esc_html_e("Available shortcodes", "wpdiscuz-buddypress-integration"); ?>:
		<p class="wpd-desc">
			<span class="wc_available_variable">[AUTHOR_NAME]</span><br>
			<span class="wc_available_variable">[AUTHOR_URL]</span><br>
			<span class="wc_available_variable">[COMMENT_URL]</span><br>
			<span class="wc_available_variable">[POST_TITLE]</span><br>
			<span class="wc_available_variable">[POST_URL]</span>
		</p>
	</div>
	<div class="wpd-opt-input">
		<?php wp_editor($setting["values"]->followsNotificationMessage, "followsNotificationMessage", ["textarea_name" => $setting["values"]->tabKey . "[followsNotificationMessage]", "textarea_rows" => 4, "teeny" => true]); ?>
	</div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="multipleFollowsNotificationsMessage">
    <div class="wpd-opt-name">
        <label for="multipleFollowsNotificationsMessage"><?php echo $setting["options"]["multipleFollowsNotificationsMessage"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["multipleFollowsNotificationsMessage"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
        <input type="text" name="<?php echo $setting["values"]->tabKey; ?>[multipleFollowsNotificationsMessage]" value="<?php echo esc_attr($setting["values"]->multipleFollowsNotificationsMessage); ?>" id="multipleFollowsNotificationsMessage" style="margin:1px;padding:3px 5px; width:90%;"/>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="upvoteEmailSubject">
    <div class="wpd-opt-name">
        <label for="upvoteEmailSubject"><?php echo $setting["options"]["upvoteEmailSubject"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["upvoteEmailSubject"]["description"] ?></p>
        <p class="wpd-desc"><?php esc_html_e("Available shortcodes", "wpdiscuz-buddypress-integration"); ?>:
        <p class="wpd-desc">
            <span class="wc_available_variable">[VOTER_NAME]</span><br>
            <span class="wc_available_variable">[POST_TITLE]</span><br>
            <span class="wc_available_variable">[BLOG_TITLE]</span>
        </p>
    </div>
    <div class="wpd-opt-input">
        <input type="text" name="<?php echo $setting["values"]->tabKey; ?>[upvoteEmailSubject]" value="<?php echo esc_attr($setting["values"]->upvoteEmailSubject); ?>" id="upvoteEmailSubject" style="margin:1px;padding:3px 5px; width:90%;"/>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="upvoteEmailMessage">
    <div class="wpd-opt-name">
        <label for="upvoteEmailMessage"><?php echo $setting["options"]["upvoteEmailMessage"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["upvoteEmailMessage"]["description"] ?></p>
        <p class="wpd-desc"><?php esc_html_e("Available shortcodes", "wpdiscuz-buddypress-integration"); ?>:
        <p class="wpd-desc">
            <span class="wc_available_variable">[SUBSCRIBER_NAME]</span><br>
            <span class="wc_available_variable">[VOTER_NAME]</span><br>
            <span class="wc_available_variable">[VOTER_URL]</span><br>
            <span class="wc_available_variable">[COMMENT_URL]</span><br>
            <span class="wc_available_variable">[POST_TITLE]</span><br>
            <span class="wc_available_variable">[BLOG_TITLE]</span><br>
            <span class="wc_available_variable">[SITE_URL]</span><br>
            <span class="wc_available_variable">[NOTIFICATIONS_PAGE_URL]</span>
        </p>
    </div>
    <div class="wpd-opt-input">
		<?php wp_editor($setting["values"]->upvoteEmailMessage, "upvoteEmailMessage", ["textarea_name" => $setting["values"]->tabKey . "[upvoteEmailMessage]", "textarea_rows" => 10, "teeny" => true]); ?>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="downvoteEmailSubject">
    <div class="wpd-opt-name">
        <label for="downvoteEmailSubject"><?php echo $setting["options"]["downvoteEmailSubject"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["downvoteEmailSubject"]["description"] ?></p>
        <p class="wpd-desc"><?php esc_html_e("Available shortcodes", "wpdiscuz-buddypress-integration"); ?>:
        <p class="wpd-desc">
            <span class="wc_available_variable">[VOTER_NAME]</span><br>
            <span class="wc_available_variable">[POST_TITLE]</span><br>
            <span class="wc_available_variable">[BLOG_TITLE]</span>
        </p>
    </div>
    <div class="wpd-opt-input">
        <input type="text" name="<?php echo $setting["values"]->tabKey; ?>[downvoteEmailSubject]" value="<?php echo esc_attr($setting["values"]->downvoteEmailSubject); ?>" id="downvoteEmailSubject" style="margin:1px;padding:3px 5px; width:90%;"/>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="downvoteEmailMessage">
    <div class="wpd-opt-name">
        <label for="downvoteEmailMessage"><?php echo $setting["options"]["downvoteEmailMessage"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["downvoteEmailMessage"]["description"] ?></p>
        <p class="wpd-desc"><?php esc_html_e("Available shortcodes", "wpdiscuz-buddypress-integration"); ?>:
        <p class="wpd-desc">
            <span class="wc_available_variable">[SUBSCRIBER_NAME]</span><br>
            <span class="wc_available_variable">[VOTER_NAME]</span><br>
            <span class="wc_available_variable">[VOTER_URL]</span><br>
            <span class="wc_available_variable">[COMMENT_URL]</span><br>
            <span class="wc_available_variable">[POST_TITLE]</span><br>
            <span class="wc_available_variable">[BLOG_TITLE]</span><br>
            <span class="wc_available_variable">[SITE_URL]</span><br>
            <span class="wc_available_variable">[NOTIFICATIONS_PAGE_URL]</span>
        </p>
    </div>
    <div class="wpd-opt-input">
		<?php wp_editor($setting["values"]->downvoteEmailMessage, "downvoteEmailMessage", ["textarea_name" => $setting["values"]->tabKey . "[downvoteEmailMessage]", "textarea_rows" => 10, "teeny" => true]); ?>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="followEmailSubject">
    <div class="wpd-opt-name">
        <label for="followEmailSubject"><?php echo $setting["options"]["followEmailSubject"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["followEmailSubject"]["description"] ?></p>
        <p class="wpd-desc"><?php esc_html_e("Available shortcodes", "wpdiscuz-buddypress-integration"); ?>:
        <p class="wpd-desc">
            <span class="wc_available_variable">[FOLLOWER_NAME]</span><br>
            <span class="wc_available_variable">[BLOG_TITLE]</span>
        </p>
    </div>
    <div class="wpd-opt-input">
        <input type="text" name="<?php echo $setting["values"]->tabKey; ?>[followEmailSubject]" value="<?php echo esc_attr($setting["values"]->followEmailSubject); ?>" id="followEmailSubject" style="margin:1px;padding:3px 5px; width:90%;"/>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="followEmailMessage">
    <div class="wpd-opt-name">
        <label for="followEmailMessage"><?php echo $setting["options"]["followEmailMessage"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["followEmailMessage"]["description"] ?></p>
        <p class="wpd-desc"><?php esc_html_e("Available shortcodes", "wpdiscuz-buddypress-integration"); ?>:
        <p class="wpd-desc">
            <span class="wc_available_variable">[SUBSCRIBER_NAME]</span><br>
            <span class="wc_available_variable">[FOLLOWER_NAME]</span><br>
            <span class="wc_available_variable">[FOLLOWER_URL]</span><br>
            <span class="wc_available_variable">[BLOG_TITLE]</span><br>
            <span class="wc_available_variable">[SITE_URL]</span><br>
            <span class="wc_available_variable">[NOTIFICATIONS_PAGE_URL]</span>
        </p>
    </div>
    <div class="wpd-opt-input">
		<?php wp_editor($setting["values"]->followEmailMessage, "followEmailMessage", ["textarea_name" => $setting["values"]->tabKey . "[followEmailMessage]", "textarea_rows" => 10, "teeny" => true]); ?>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="postRatingEmailSubject">
    <div class="wpd-opt-name">
        <label for="postRatingEmailSubject"><?php echo $setting["options"]["postRatingEmailSubject"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["postRatingEmailSubject"]["description"] ?></p>
        <p class="wpd-desc"><?php esc_html_e("Available shortcodes", "wpdiscuz-buddypress-integration"); ?>:
        <p class="wpd-desc">
            <span class="wc_available_variable">[RATER_NAME]</span><br>
            <span class="wc_available_variable">[RATING]</span><br>
            <span class="wc_available_variable">[POST_TITLE]</span><br>
            <span class="wc_available_variable">[BLOG_TITLE]</span>
        </p>
    </div>
    <div class="wpd-opt-input">
        <input type="text" name="<?php echo $setting["values"]->tabKey; ?>[postRatingEmailSubject]" value="<?php echo esc_attr($setting["values"]->postRatingEmailSubject); ?>" id="postRatingEmailSubject" style="margin:1px;padding:3px 5px; width:90%;"/>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="postRatingEmailMessage">
    <div class="wpd-opt-name">
        <label for="postRatingEmailMessage"><?php echo $setting["options"]["postRatingEmailMessage"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["postRatingEmailMessage"]["description"] ?></p>
        <p class="wpd-desc"><?php esc_html_e("Available shortcodes", "wpdiscuz-buddypress-integration"); ?>:
        <p class="wpd-desc">
            <span class="wc_available_variable">[SUBSCRIBER_NAME]</span><br>
            <span class="wc_available_variable">[RATER_NAME]</span><br>
            <span class="wc_available_variable">[RATER_URL]</span><br>
            <span class="wc_available_variable">[RATING]</span><br>
            <span class="wc_available_variable">[POST_TITLE]</span><br>
            <span class="wc_available_variable">[POST_URL]</span><br>
            <span class="wc_available_variable">[BLOG_TITLE]</span><br>
            <span class="wc_available_variable">[SITE_URL]</span><br>
            <span class="wc_available_variable">[NOTIFICATIONS_PAGE_URL]</span>
        </p>
    </div>
    <div class="wpd-opt-input">
		<?php wp_editor($setting["values"]->postRatingEmailMessage, "postRatingEmailMessage", ["textarea_name" => $setting["values"]->tabKey . "[postRatingEmailMessage]", "textarea_rows" => 10, "teeny" => true]); ?>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="replyEmailSubject">
    <div class="wpd-opt-name">
        <label for="replyEmailSubject"><?php echo $setting["options"]["replyEmailSubject"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["replyEmailSubject"]["description"] ?></p>
        <p class="wpd-desc"><?php esc_html_e("Available shortcodes", "wpdiscuz-buddypress-integration"); ?>:
        <p class="wpd-desc">
            <span class="wc_available_variable">[AUTHOR_NAME]</span><br>
            <span class="wc_available_variable">[POST_TITLE]</span><br>
            <span class="wc_available_variable">[BLOG_TITLE]</span>
        </p>
    </div>
    <div class="wpd-opt-input">
        <input type="text" name="<?php echo $setting["values"]->tabKey; ?>[replyEmailSubject]" value="<?php echo esc_attr($setting["values"]->replyEmailSubject); ?>" id="replyEmailSubject" style="margin:1px;padding:3px 5px; width:90%;"/>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="replyEmailMessage">
    <div class="wpd-opt-name">
        <label for="replyEmailMessage"><?php echo $setting["options"]["replyEmailMessage"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["replyEmailMessage"]["description"] ?></p>
        <p class="wpd-desc"><?php esc_html_e("Available shortcodes", "wpdiscuz-buddypress-integration"); ?>:
        <p class="wpd-desc">
            <span class="wc_available_variable">[SUBSCRIBER_NAME]</span><br>
            <span class="wc_available_variable">[AUTHOR_NAME]</span><br>
            <span class="wc_available_variable">[AUTHOR_URL]</span><br>
            <span class="wc_available_variable">[COMMENT_URL]</span><br>
            <span class="wc_available_variable">[POST_TITLE]</span><br>
            <span class="wc_available_variable">[POST_URL]</span><br>
            <span class="wc_available_variable">[BLOG_TITLE]</span><br>
            <span class="wc_available_variable">[SITE_URL]</span><br>
            <span class="wc_available_variable">[NOTIFICATIONS_PAGE_URL]</span>
        </p>
    </div>
    <div class="wpd-opt-input">
		<?php wp_editor($setting["values"]->replyEmailMessage, "replyEmailMessage", ["textarea_name" => $setting["values"]->tabKey . "[replyEmailMessage]", "textarea_rows" => 10, "teeny" => true]); ?>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="commentOnPostEmailSubject">
    <div class="wpd-opt-name">
        <label for="commentOnPostEmailSubject"><?php echo $setting["options"]["commentOnPostEmailSubject"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["commentOnPostEmailSubject"]["description"] ?></p>
        <p class="wpd-desc"><?php esc_html_e("Available shortcodes", "wpdiscuz-buddypress-integration"); ?>:
        <p class="wpd-desc">
            <span class="wc_available_variable">[AUTHOR_NAME]</span><br>
            <span class="wc_available_variable">[POST_TITLE]</span><br>
            <span class="wc_available_variable">[BLOG_TITLE]</span>
        </p>
    </div>
    <div class="wpd-opt-input">
        <input type="text" name="<?php echo $setting["values"]->tabKey; ?>[commentOnPostEmailSubject]" value="<?php echo esc_attr($setting["values"]->commentOnPostEmailSubject); ?>" id="commentOnPostEmailSubject" style="margin:1px;padding:3px 5px; width:90%;"/>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="commentOnPostEmailMessage">
    <div class="wpd-opt-name">
        <label for="commentOnPostEmailMessage"><?php echo $setting["options"]["commentOnPostEmailMessage"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["commentOnPostEmailMessage"]["description"] ?></p>
        <p class="wpd-desc"><?php esc_html_e("Available shortcodes", "wpdiscuz-buddypress-integration"); ?>:
        <p class="wpd-desc">
            <span class="wc_available_variable">[SUBSCRIBER_NAME]</span><br>
            <span class="wc_available_variable">[AUTHOR_NAME]</span><br>
            <span class="wc_available_variable">[AUTHOR_URL]</span><br>
            <span class="wc_available_variable">[COMMENT_URL]</span><br>
            <span class="wc_available_variable">[POST_TITLE]</span><br>
            <span class="wc_available_variable">[POST_URL]</span><br>
            <span class="wc_available_variable">[BLOG_TITLE]</span><br>
            <span class="wc_available_variable">[SITE_URL]</span><br>
            <span class="wc_available_variable">[NOTIFICATIONS_PAGE_URL]</span>
        </p>
    </div>
    <div class="wpd-opt-input">
		<?php wp_editor($setting["values"]->commentOnPostEmailMessage, "commentOnPostEmailMessage", ["textarea_name" => $setting["values"]->tabKey . "[commentOnPostEmailMessage]", "textarea_rows" => 10, "teeny" => true]); ?>
    </div>
</div>
<!-- Option end -->

