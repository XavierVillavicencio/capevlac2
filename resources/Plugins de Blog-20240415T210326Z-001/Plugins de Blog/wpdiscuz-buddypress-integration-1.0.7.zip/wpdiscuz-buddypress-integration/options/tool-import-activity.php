<?php
if (!defined("ABSPATH")) {
	exit();
}

?>
<div class="wpdtool-accordion-item">

	<div class="fas wpdtool-accordion-title" data-wpdtool-selector="wpdtool-<?php echo $tool["selector"]; ?>">
		<p><?php esc_html_e("Import Activity", "wpdiscuz-buddypress-integration"); ?></p>
	</div>

	<div class="wpdtool-accordion-content">

		<div class="wpdtool wpdtool-import-comments-to-activity">
			<p class="wpdtool-desc"><?php esc_html_e("Using this tool you can import comments to BuddyPress activity.", "wpdiscuz-buddypress-integration"); ?></p>
			<form action="" method="post" class="wc-tools-settings-form wc-form">
				<?php wp_nonce_field("wc_tools_form", "wpdiscuz-bpi-import-comments"); ?>
				<div class="wpdtool-block">
					<button type="submit" class="button button-secondary import-comments-to-activity" title="<?php esc_attr_e("Start Import", "wpdiscuz-buddypress-integration"); ?>">
						<?php esc_html_e("Import Comments to Activity", "wpdiscuz-buddypress-integration"); ?>&nbsp;
						<i class="fas wc-hidden"></i>
					</button>
					<input type="number" name="import-comments-to-activity-limit" value="50" min="1" class="import-comments-to-activity-limit"/>
					<input type="text" name="import-comments-to-activity-start-date" value="" class="import-comments-to-activity-start-date" placeholder="<?php esc_attr_e("Start Date", "wpdiscuz-buddypress-integration"); ?>"/>
					<input type="text" name="import-comments-to-activity-end-date" value="" class="import-comments-to-activity-end-date" placeholder="<?php esc_attr_e("End Date", "wpdiscuz-buddypress-integration"); ?>"/>
					<span class="import-comments-to-activity-progress">&nbsp;</span>
					<input type="hidden" name="import-comments-to-activity-start-id" value="0" class="import-comments-to-activity-start-id"/>
					<input type="hidden" name="import-comments-to-activity-count" value="0" class="import-comments-to-activity-count"/>
					<input type="hidden" name="import-comments-to-activity-step" value="0" class="import-comments-to-activity-step"/>
				</div>
			</form>
		</div>

        <div class="wpdtool wpdtool-import-votes-to-activity">
			<p class="wpdtool-desc"><?php esc_html_e("Import comment votes to BuddyPress activity.", "wpdiscuz-buddypress-integration"); ?></p>
			<form action="" method="post" class="wc-tools-settings-form wc-form">
				<?php wp_nonce_field("wc_tools_form", "wpdiscuz-bpi-import-votes"); ?>
				<div class="wpdtool-block">
					<button type="submit" class="button button-secondary import-votes-to-activity" title="<?php esc_attr_e("Start Import", "wpdiscuz-buddypress-integration"); ?>">
						<?php esc_html_e("Import Comment Votes to Activity", "wpdiscuz-buddypress-integration"); ?>&nbsp;
						<i class="fas wc-hidden"></i>
					</button>
					<input type="number" name="import-votes-to-activity-limit" value="50" min="1" class="import-votes-to-activity-limit"/>
                    <input type="text" name="import-votes-to-activity-start-date" value="" class="import-votes-to-activity-start-date" placeholder="<?php esc_attr_e("Start Date", "wpdiscuz-buddypress-integration"); ?>"/>
                    <input type="text" name="import-votes-to-activity-end-date" value="" class="import-votes-to-activity-end-date" placeholder="<?php esc_attr_e("End Date", "wpdiscuz-buddypress-integration"); ?>"/>
					<span class="import-votes-to-activity-progress">&nbsp;</span>
					<input type="hidden" name="import-votes-to-activity-start-id" value="0" class="import-votes-to-activity-start-id"/>
					<input type="hidden" name="import-votes-to-activity-count" value="0" class="import-votes-to-activity-count"/>
					<input type="hidden" name="import-votes-to-activity-step" value="0" class="import-votes-to-activity-step"/>
				</div>
			</form>
		</div>

        <div class="wpdtool wpdtool-import-ratings-to-activity">
			<p class="wpdtool-desc"><?php esc_html_e("Import post rates to BuddyPress activity.", "wpdiscuz-buddypress-integration"); ?></p>
			<form action="" method="post" class="wc-tools-settings-form wc-form">
				<?php wp_nonce_field("wc_tools_form", "wpdiscuz-bpi-import-ratings"); ?>
				<div class="wpdtool-block">
					<button type="submit" class="button button-secondary import-ratings-to-activity" title="<?php esc_attr_e("Start Import", "wpdiscuz-buddypress-integration"); ?>">
						<?php esc_html_e("Import Post Ratings to Activity", "wpdiscuz-buddypress-integration"); ?>&nbsp;
						<i class="fas wc-hidden"></i>
					</button>
					<input type="number" name="import-ratings-to-activity-limit" value="50" min="1" class="import-ratings-to-activity-limit"/>
                    <input type="text" name="import-ratings-to-activity-start-date" value="" class="import-ratings-to-activity-start-date" placeholder="<?php esc_attr_e("Start Date", "wpdiscuz-buddypress-integration"); ?>"/>
                    <input type="text" name="import-ratings-to-activity-end-date" value="" class="import-ratings-to-activity-end-date" placeholder="<?php esc_attr_e("End Date", "wpdiscuz-buddypress-integration"); ?>"/>
					<span class="import-ratings-to-activity-progress">&nbsp;</span>
					<input type="hidden" name="import-ratings-to-activity-start-id" value="0" class="import-ratings-to-activity-start-id"/>
					<input type="hidden" name="import-ratings-to-activity-count" value="0" class="import-ratings-to-activity-count"/>
					<input type="hidden" name="import-ratings-to-activity-step" value="0" class="import-ratings-to-activity-step"/>
				</div>
			</form>
		</div>

	</div>
</div>