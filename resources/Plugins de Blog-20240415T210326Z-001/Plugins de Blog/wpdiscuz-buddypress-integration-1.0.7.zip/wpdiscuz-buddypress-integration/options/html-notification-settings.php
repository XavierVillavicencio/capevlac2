<?php
if (!defined("ABSPATH")) {
	exit();
}
$currentUser = WpdiscuzHelper::getCurrentUser();
?>
<style>
    .wpd-bp-nopt{
        padding: 10px;
    }
</style>
<form id="wpd-bpi-notification-settings" method="post">
    <div id="wpd-bpi-notifications">
        <div><?php esc_html_e("Show notifications when:", "wpdiscuz-buddypress-integration"); ?></div>
        <div class="wpd-bp-nopt">
            <?php
            if ($this->options->notificationForCommentVote) {
                $notificationForCommentVote = get_user_meta($currentUser->ID, self::USER_META_NOTIFICATION_FOR_COMMENT_VOTE, true);
                if (!is_numeric($notificationForCommentVote)) {
                    $notificationForCommentVote = $this->options->notificationForCommentVoteForNewUsers;
                }
                ?>
                <div>
                    <input type="checkbox" <?php checked($notificationForCommentVote == 1) ?> value="1" name="<?php echo $this->options->tabKey; ?>[notificationForCommentVote]" id="notificationForCommentVote" style="margin:0; vertical-align: middle;" />
                    <label for="notificationForCommentVote"><?php esc_html_e("Someone votes on my comment", "wpdiscuz-buddypress-integration"); ?></label>
                </div>
                <?php
            }
            if ($this->options->notificationForFollow) {
                $notificationForFollow = get_user_meta($currentUser->ID, self::USER_META_NOTIFICATION_FOR_FOLLOW, true);
                if (!is_numeric($notificationForFollow)) {
                    $notificationForFollow = $this->options->notificationForFollowForNewUsers;
                }
                ?>
                <div>
                    <input type="checkbox" <?php checked($notificationForFollow == 1) ?> value="1" name="<?php echo $this->options->tabKey; ?>[notificationForFollow]" id="notificationForFollow" style="margin:0; vertical-align: middle;" />
                    <label for="notificationForFollow"><?php esc_html_e("Someone follows me", "wpdiscuz-buddypress-integration"); ?></label>
                </div>
                <?php
            }
            if ($this->options->notificationForPostRating) {
                $notificationForPostRating = get_user_meta($currentUser->ID, self::USER_META_NOTIFICATION_FOR_POST_RATING, true);
                if (!is_numeric($notificationForPostRating)) {
                    $notificationForPostRating = $this->options->notificationForPostRatingForNewUsers;
                }
                ?>
                <div>
                    <input type="checkbox" <?php checked($notificationForPostRating == 1) ?> value="1" name="<?php echo $this->options->tabKey; ?>[notificationForPostRating]" id="notificationForPostRating" style="margin:0; vertical-align: middle;" />
                    <label for="notificationForPostRating"><?php esc_html_e("Someone rated my post", "wpdiscuz-buddypress-integration"); ?></label>
                </div>
                <?php
            }
            if ($this->options->notificationForApprovedComment) {
                $notificationForApprovedComment = get_user_meta($currentUser->ID, self::USER_META_NOTIFICATION_FOR_APPROVED_COMMENT, true);
                if (!is_numeric($notificationForApprovedComment)) {
                    $notificationForApprovedComment = $this->options->notificationForApprovedCommentForNewUsers;
                }
                ?>
                <div>
                    <input type="checkbox" <?php checked($notificationForApprovedComment == 1) ?> value="1" name="<?php echo $this->options->tabKey; ?>[notificationForApprovedComment]" id="notificationForApprovedComment" style="margin:0; vertical-align: middle;" />
                    <label for="notificationForApprovedComment"><?php esc_html_e("My comment is approved", "wpdiscuz-buddypress-integration"); ?></label>
                </div>
                <?php
            }
            if ($this->options->notificationForReply) {
                $notificationForReply = get_user_meta($currentUser->ID, self::USER_META_NOTIFICATION_FOR_REPLY, true);
                if (!is_numeric($notificationForReply)) {
                    $notificationForReply = $this->options->notificationForReplyForNewUsers;
                }
                ?>
                <div>
                    <input type="checkbox" <?php checked($notificationForReply == 1) ?> value="1" name="<?php echo $this->options->tabKey; ?>[notificationForReply]" id="notificationForReply" style="margin:0; vertical-align: middle;" />
                    <label for="notificationForReply"><?php esc_html_e("Someone replied to my comment", "wpdiscuz-buddypress-integration"); ?></label>
                </div>
                <?php
            }
            if ($this->options->notificationForCommentOnPost) {
                $notificationForCommentOnPost = get_user_meta($currentUser->ID, self::USER_META_NOTIFICATION_FOR_COMMENT_ON_POST, true);
                if (!is_numeric($notificationForCommentOnPost)) {
                    $notificationForCommentOnPost = $this->options->notificationForCommentOnPostForNewUsers;
                }
                ?>
                <div>
                    <input type="checkbox" <?php checked($notificationForCommentOnPost == 1) ?> value="1" name="<?php echo $this->options->tabKey; ?>[notificationForCommentOnPost]" id="notificationForCommentOnPost" style="margin:0; vertical-align: middle;" />
                    <label for="notificationForCommentOnPost"><?php esc_html_e("Someone commented on my post", "wpdiscuz-buddypress-integration"); ?></label>
                </div>
                <?php
            }
            if ($this->options->notificationForMention) {
                $notificationForMention = get_user_meta($currentUser->ID, self::USER_META_NOTIFICATION_FOR_MENTION, true);
                if (!is_numeric($notificationForMention)) {
                    $notificationForMention = $this->options->notificationForMentionForNewUsers;
                }
                ?>
                <div>
                    <input type="checkbox" <?php checked($notificationForMention == 1) ?> value="1" name="<?php echo $this->options->tabKey; ?>[notificationForMention]" id="notificationForMention" style="margin:0; vertical-align: middle;" />
                    <label for="notificationForMention"><?php esc_html_e("Someone mentioned me", "wpdiscuz-buddypress-integration"); ?></label>
                </div>
                <?php
            }
            if ($this->options->notificationForSubscriptions) {
                $notificationForSubscriptions = get_user_meta($currentUser->ID, self::USER_META_NOTIFICATION_FOR_SUBSCRIPTIONS, true);
                if (!is_numeric($notificationForSubscriptions)) {
                    $notificationForSubscriptions = $this->options->notificationForSubscriptionsForNewUsers;
                }
                ?>
                <div>
                    <input type="checkbox" <?php checked($notificationForSubscriptions == 1) ?> value="1" name="<?php echo $this->options->tabKey; ?>[notificationForSubscriptions]" id="notificationForSubscriptions" style="margin:0; vertical-align: middle;" />
                    <label for="notificationForSubscriptions"><?php esc_html_e("New comment on subscribed post", "wpdiscuz-buddypress-integration"); ?></label>
                </div>
                <?php
            }
            if ($this->options->notificationForFollows) {
                $notificationForFollows = get_user_meta($currentUser->ID, self::USER_META_NOTIFICATION_FOR_FOLLOWS, true);
                if (!is_numeric($notificationForFollows)) {
                    $notificationForFollows = $this->options->notificationForFollowsForNewUsers;
                }
                ?>
                <div>
                    <input type="checkbox" <?php checked($notificationForFollows == 1) ?> value="1" name="<?php echo $this->options->tabKey; ?>[notificationForFollows]" id="notificationForFollows" style="margin:0; vertical-align: middle;" />
                    <label for="notificationForFollows"><?php esc_html_e("New comment by followed user", "wpdiscuz-buddypress-integration"); ?></label>
                </div>
                <?php
            }
            ?>
        </div>
    </div>
    <br/>
    <div id="wpd-bpi-emails">
        <div><?php esc_html_e("Send me email notifications when:", "wpdiscuz-buddypress-integration"); ?></div>
        <div class="wpd-bp-nopt">
            <?php
            if ($this->options->emailForCommentVote) {
                $emailForCommentVote = get_user_meta($currentUser->ID, self::USER_META_EMAIL_FOR_COMMENT_VOTE, true);
                if (!is_numeric($emailForCommentVote)) {
                    $emailForCommentVote = $this->options->emailForCommentVoteForNewUsers;
                }
                ?>
                <div>
                    <input type="checkbox" <?php checked($emailForCommentVote == 1) ?> value="1" name="<?php echo $this->options->tabKey; ?>[emailForCommentVote]" id="emailForCommentVote" style="margin:0; vertical-align: middle;" />
                    <label for="emailForCommentVote"><?php esc_html_e("Someone votes on my comment", "wpdiscuz-buddypress-integration"); ?></label>
                </div>
                <?php
            }
            if ($this->options->emailForFollow) {
                $emailForFollow = get_user_meta($currentUser->ID, self::USER_META_EMAIL_FOR_FOLLOW, true);
                if (!is_numeric($emailForFollow)) {
                    $emailForFollow = $this->options->emailForFollowForNewUsers;
                }
                ?>
                <div>
                    <input type="checkbox" <?php checked($emailForFollow == 1) ?> value="1" name="<?php echo $this->options->tabKey; ?>[emailForFollow]" id="emailForFollow" style="margin:0; vertical-align: middle;" />
                    <label for="emailForFollow"><?php esc_html_e("Someone follows me", "wpdiscuz-buddypress-integration"); ?></label>
                </div>
                <?php
            }
            if ($this->options->emailForPostRating) {
                $emailForPostRating = get_user_meta($currentUser->ID, self::USER_META_EMAIL_FOR_POST_RATING, true);
                if (!is_numeric($emailForPostRating)) {
                    $emailForPostRating = $this->options->emailForPostRatingForNewUsers;
                }
                ?>
                <div>
                    <input type="checkbox" <?php checked($emailForPostRating == 1) ?> value="1" name="<?php echo $this->options->tabKey; ?>[emailForPostRating]" id="emailForPostRating" style="margin:0; vertical-align: middle;" />
                    <label for="emailForPostRating"><?php esc_html_e("Someone rated my post", "wpdiscuz-buddypress-integration"); ?></label>
                </div>
                <?php
            }
            if ($this->options->emailForApprovedComment) {
                $emailForApprovedComment = get_user_meta($currentUser->ID, self::USER_META_EMAIL_FOR_APPROVED_COMMENT, true);
                if (!is_numeric($emailForApprovedComment)) {
                    $emailForApprovedComment = $this->options->emailForApprovedCommentForNewUsers;
                }
                ?>
                <div>
                    <input type="checkbox" <?php checked($emailForApprovedComment == 1) ?> value="1" name="<?php echo $this->options->tabKey; ?>[emailForApprovedComment]" id="emailForApprovedComment" style="margin:0; vertical-align: middle;" />
                    <label for="emailForApprovedComment"><?php esc_html_e("My comment is approved", "wpdiscuz-buddypress-integration"); ?></label>
                </div>
                <?php
            }
            if ($this->options->emailForReply) {
                $emailForReply = get_user_meta($currentUser->ID, self::USER_META_EMAIL_FOR_REPLY, true);
                if (!is_numeric($emailForReply)) {
                    $emailForReply = $this->options->emailForReplyForNewUsers;
                }
                ?>
                <div>
                    <input type="checkbox" <?php checked($emailForReply == 1) ?> value="1" name="<?php echo $this->options->tabKey; ?>[emailForReply]" id="emailForReply" style="margin:0; vertical-align: middle;" />
                    <label for="emailForReply"><?php esc_html_e("Someone replied to my comment", "wpdiscuz-buddypress-integration"); ?></label>
                </div>
                <?php
            }
            if ($this->options->emailForCommentOnPost) {
                $emailForCommentOnPost = get_user_meta($currentUser->ID, self::USER_META_EMAIL_FOR_COMMENT_ON_POST, true);
                if (!is_numeric($emailForCommentOnPost)) {
                    $emailForCommentOnPost = $this->options->emailForCommentOnPostForNewUsers;
                }
                ?>
                <div>
                    <input type="checkbox" <?php checked($emailForCommentOnPost == 1) ?> value="1" name="<?php echo $this->options->tabKey; ?>[emailForCommentOnPost]" id="emailForCommentOnPost" style="margin:0; vertical-align: middle;" />
                    <label for="emailForCommentOnPost"><?php esc_html_e("Someone commented on my post", "wpdiscuz-buddypress-integration"); ?></label>
                </div>
                <?php
            }
            if ($this->options->emailForMention) {
                $emailForMention = get_user_meta($currentUser->ID, self::USER_META_EMAIL_FOR_MENTION, true);
                if (!is_numeric($emailForMention)) {
                    $emailForMention = $this->options->emailForMentionForNewUsers;
                }
                ?>
                <div>
                    <input type="checkbox" <?php checked($emailForMention == 1) ?> value="1" name="<?php echo $this->options->tabKey; ?>[emailForMention]" id="emailForMention" style="margin:0; vertical-align: middle;" />
                    <label for="emailForMention"><?php esc_html_e("Someone mentioned me", "wpdiscuz-buddypress-integration"); ?></label>
                </div>
                <?php
            }
            if ($this->options->emailForSubscriptions) {
                $emailForSubscriptions = get_user_meta($currentUser->ID, self::USER_META_EMAIL_FOR_SUBSCRIPTIONS, true);
                if (!is_numeric($emailForSubscriptions)) {
                    $emailForSubscriptions = $this->options->emailForSubscriptionsForNewUsers;
                }
                ?>
                <div>
                    <input type="checkbox" <?php checked($emailForSubscriptions == 1) ?> value="1" name="<?php echo $this->options->tabKey; ?>[emailForSubscriptions]" id="emailForSubscriptions" style="margin:0; vertical-align: middle;" />
                    <label for="emailForSubscriptions"><?php esc_html_e("New comment on subscribed post", "wpdiscuz-buddypress-integration"); ?></label>
                </div>
                <?php
            }
            if ($this->options->emailForFollows) {
                $emailForFollows = get_user_meta($currentUser->ID, self::USER_META_EMAIL_FOR_FOLLOWS, true);
                if (!is_numeric($emailForFollows)) {
                    $emailForFollows = $this->options->emailForFollowsForNewUsers;
                }
                ?>
                <div>
                    <input type="checkbox" <?php checked($emailForFollows == 1) ?> value="1" name="<?php echo $this->options->tabKey; ?>[emailForFollows]" id="emailForFollows" style="margin:0; vertical-align: middle;" />
                    <label for="emailForFollows"><?php esc_html_e("New comment by followed user", "wpdiscuz-buddypress-integration"); ?></label>
                </div>
                <?php
            }
		?>
        </div>
    </div>
    <br/>
    <button name="<?php echo $this->options->tabKey; ?>[save]"><?php esc_html_e("Save", "wpdiscuz-buddypress-integration"); ?></button>
</form>