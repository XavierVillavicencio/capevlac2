<?php
if (!defined("ABSPATH")) {
	exit();
}

 class wpDiscuzBPIOptions implements wpDiscuzBPIConstants {

	public $tabKey = "bpi";
 	/* Notifications */
	public $notificationForCommentVote;
	public $notificationForFollow;
	public $notificationForPostRating;
	public $notificationForApprovedComment;
	public $notificationForMention;
	public $notificationForReply;
	public $notificationForCommentOnPost;
	public $notificationForSubscriptions;
	public $notificationForFollows;
 	/* /Notifications */
 	/* Emails */
	public $emailForCommentVote;
	public $emailForFollow;
	public $emailForPostRating;
	public $emailForApprovedComment;
	public $emailForMention;
	public $emailForReply;
	public $emailForCommentOnPost;
	public $emailForSubscriptions;
	public $emailForFollows;
 	/* /Emails */
 	/* Notifications for new users */
 	public $notificationForCommentVoteForNewUsers;
	public $notificationForFollowForNewUsers;
	public $notificationForPostRatingForNewUsers;
	public $notificationForApprovedCommentForNewUsers;
	public $notificationForMentionForNewUsers;
	public $notificationForReplyForNewUsers;
	public $notificationForCommentOnPostForNewUsers;
	public $notificationForSubscriptionsForNewUsers;
	public $notificationForFollowsForNewUsers;
 	/* /Notifications for new users */
 	/* Emails for new users */
	public $emailForCommentVoteForNewUsers;
	public $emailForFollowForNewUsers;
	public $emailForPostRatingForNewUsers;
	public $emailForApprovedCommentForNewUsers;
	public $emailForMentionForNewUsers;
	public $emailForReplyForNewUsers;
	public $emailForCommentOnPostForNewUsers;
	public $emailForSubscriptionsForNewUsers;
	public $emailForFollowsForNewUsers;
 	/* /Emails for new users */
 	/* Notification messages */
	public $commentUpvoteNotificationMessage;
	public $commentDownvoteNotificationMessage;
	public $followNotificationMessage;
	public $postRatingNotificationMessage;
	public $approvedCommentNotificationMessage;
	public $mentionNotificationMessage;
	public $replyNotificationMessage;
	public $commentOnPostNotificationMessage;
	public $subscriptionsNotificationMessage;
	public $followsNotificationMessage;
 	/* /Notification messages */
 	/* Multiple notifications messages */
 	public $multipleCommentUpvoteNotificationsMessage;
 	public $multipleCommentDownvoteNotificationsMessage;
 	public $multipleFollowNotificationsMessage;
 	public $multiplePostRatingNotificationsMessage;
 	public $multipleApprovedCommentNotificationsMessage;
 	public $multipleMentionNotificationsMessage;
 	public $multipleReplyNotificationsMessage;
 	public $multipleCommentOnPostNotificationsMessage;
 	public $multipleSubscriptionsNotificationsMessage;
 	public $multipleFollowsNotificationsMessage;
 	/* /Multiple notifications messages */
 	/* Email messages */
 	public $upvoteEmailSubject;
 	public $upvoteEmailMessage;
 	public $downvoteEmailSubject;
 	public $downvoteEmailMessage;
 	public $followEmailSubject;
 	public $followEmailMessage;
 	public $postRatingEmailSubject;
 	public $postRatingEmailMessage;
 	public $replyEmailSubject;
 	public $replyEmailMessage;
 	public $commentOnPostEmailSubject;
 	public $commentOnPostEmailMessage;
 	/* /Email messages */
	/* Activity */
	 public $activityForCommentVote;
	 public $activityForPostRating;
	/* /Activity */
 	/* Activity Texts */
 	public $commentUpvoteActivityMessage;
 	public $commentDownvoteActivityMessage;
 	public $postRatingActivityMessage;
 	/* /Activity Texts */
 	/* Profile Tabs */
 	public $enableProfileCommentsTab;
 	public $enableProfileSubscriptionsTab;
 	public $enableProfileReactionsTab;
 	public $enableProfileRatesTab;
 	public $enableProfileVotesTab;
 	public $enableProfileFollowingTab;
 	public $enableProfileFollowersTab;
 	public $profileDiscussionsTabTitle;
 	public $profileCommentsTabTitle;
 	public $profileSubscriptionsTabTitle;
 	public $profileReactionsTabTitle;
 	public $profileRatesTabTitle;
 	public $profileVotesTabTitle;
 	public $profileFollowingTabTitle;
 	public $profileFollowersTabTitle;
 	/* /Profile Tabs */
 	/* Common */
 	public $changeUserSettingsButton;
 	public $guestPhrase;
 	public $notificationSettingsTabTitle;
 	/* /Common */

	public function __construct() {
		$this->addOption();
        $this->initOptions(get_option(self::OPTION_SLUG_OPTIONS, []));
        add_action("wpdiscuz_save_options", [&$this, "saveOptions"], 17);
        add_action("wpdiscuz_reset_options", [&$this, "resetOptions"], 17);
        add_filter("wpdiscuz_settings", [&$this, "settingsArray"], 17);
	}

	 public function addOption() {
		 add_option(self::OPTION_SLUG_OPTIONS, $this->getDefaultOptions(), "", "no");
	 }

	 public function initOptions($options) {
		 $defaults = $this->getDefaultOptions();
		 /* Notifications */
		 $this->notificationForCommentVote = isset($options["notificationForCommentVote"]) ? $options["notificationForCommentVote"] : $defaults["notificationForCommentVote"];
		 $this->notificationForFollow = isset($options["notificationForFollow"]) ? $options["notificationForFollow"] : $defaults["notificationForFollow"];
		 $this->notificationForPostRating = isset($options["notificationForPostRating"]) ? $options["notificationForPostRating"] : $defaults["notificationForPostRating"];
		 $this->notificationForApprovedComment = isset($options["notificationForApprovedComment"]) ? $options["notificationForApprovedComment"] : $defaults["notificationForApprovedComment"];
		 $this->notificationForMention = isset($options["notificationForMention"]) ? $options["notificationForMention"] : $defaults["notificationForMention"];
		 $this->notificationForReply = isset($options["notificationForReply"]) ? $options["notificationForReply"] : $defaults["notificationForReply"];
		 $this->notificationForCommentOnPost = isset($options["notificationForCommentOnPost"]) ? $options["notificationForCommentOnPost"] : $defaults["notificationForCommentOnPost"];
		 $this->notificationForSubscriptions = isset($options["notificationForSubscriptions"]) ? $options["notificationForSubscriptions"] : $defaults["notificationForSubscriptions"];
		 $this->notificationForFollows = isset($options["notificationForFollows"]) ? $options["notificationForFollows"] : $defaults["notificationForFollows"];
		 /* /Notifications */
		 /* Emails */
		 $this->emailForCommentVote = isset($options["emailForCommentVote"]) ? $options["emailForCommentVote"] : $defaults["emailForCommentVote"];
		 $this->emailForFollow = isset($options["emailForFollow"]) ? $options["emailForFollow"] : $defaults["emailForFollow"];
		 $this->emailForPostRating = isset($options["emailForPostRating"]) ? $options["emailForPostRating"] : $defaults["emailForPostRating"];
		 $this->emailForApprovedComment = isset($options["emailForApprovedComment"]) ? $options["emailForApprovedComment"] : $defaults["emailForApprovedComment"];
		 $this->emailForMention = isset($options["emailForMention"]) ? $options["emailForMention"] : $defaults["emailForMention"];
		 $this->emailForReply = isset($options["emailForReply"]) ? $options["emailForReply"] : $defaults["emailForReply"];
		 $this->emailForCommentOnPost = isset($options["emailForCommentOnPost"]) ? $options["emailForCommentOnPost"] : $defaults["emailForCommentOnPost"];
		 $this->emailForSubscriptions = isset($options["emailForSubscriptions"]) ? $options["emailForSubscriptions"] : $defaults["emailForSubscriptions"];
		 $this->emailForFollows = isset($options["emailForFollows"]) ? $options["emailForFollows"] : $defaults["emailForFollows"];
		 /* /Emails */
		 /* Notifications for new users */
		 $this->notificationForCommentVoteForNewUsers = isset($options["notificationForCommentVoteForNewUsers"]) ? $options["notificationForCommentVoteForNewUsers"] : $defaults["notificationForCommentVoteForNewUsers"];
		 $this->notificationForFollowForNewUsers = isset($options["notificationForFollowForNewUsers"]) ? $options["notificationForFollowForNewUsers"] : $defaults["notificationForFollowForNewUsers"];
		 $this->notificationForPostRatingForNewUsers = isset($options["notificationForPostRatingForNewUsers"]) ? $options["notificationForPostRatingForNewUsers"] : $defaults["notificationForPostRatingForNewUsers"];
		 $this->notificationForApprovedCommentForNewUsers = isset($options["notificationForApprovedCommentForNewUsers"]) ? $options["notificationForApprovedCommentForNewUsers"] : $defaults["notificationForApprovedCommentForNewUsers"];
		 $this->notificationForMentionForNewUsers = isset($options["notificationForMentionForNewUsers"]) ? $options["notificationForMentionForNewUsers"] : $defaults["notificationForMentionForNewUsers"];
		 $this->notificationForReplyForNewUsers = isset($options["notificationForReplyForNewUsers"]) ? $options["notificationForReplyForNewUsers"] : $defaults["notificationForReplyForNewUsers"];
		 $this->notificationForCommentOnPostForNewUsers = isset($options["notificationForCommentOnPostForNewUsers"]) ? $options["notificationForCommentOnPostForNewUsers"] : $defaults["notificationForCommentOnPostForNewUsers"];
		 $this->notificationForSubscriptionsForNewUsers = isset($options["notificationForSubscriptionsForNewUsers"]) ? $options["notificationForSubscriptionsForNewUsers"] : $defaults["notificationForSubscriptionsForNewUsers"];
		 $this->notificationForFollowsForNewUsers = isset($options["notificationForFollowsForNewUsers"]) ? $options["notificationForFollowsForNewUsers"] : $defaults["notificationForFollowsForNewUsers"];
		 /* /Notifications for new users */
		 /* Emails for new users */
		 $this->emailForCommentVoteForNewUsers = isset($options["emailForCommentVoteForNewUsers"]) ? $options["emailForCommentVoteForNewUsers"] : $defaults["emailForCommentVoteForNewUsers"];
		 $this->emailForFollowForNewUsers = isset($options["emailForFollowForNewUsers"]) ? $options["emailForFollowForNewUsers"] : $defaults["emailForFollowForNewUsers"];
		 $this->emailForPostRatingForNewUsers = isset($options["emailForPostRatingForNewUsers"]) ? $options["emailForPostRatingForNewUsers"] : $defaults["emailForPostRatingForNewUsers"];
		 $this->emailForApprovedCommentForNewUsers = isset($options["emailForApprovedCommentForNewUsers"]) ? $options["emailForApprovedCommentForNewUsers"] : $defaults["emailForApprovedCommentForNewUsers"];
		 $this->emailForMentionForNewUsers = isset($options["emailForMentionForNewUsers"]) ? $options["emailForMentionForNewUsers"] : $defaults["emailForMentionForNewUsers"];
		 $this->emailForReplyForNewUsers = isset($options["emailForReplyForNewUsers"]) ? $options["emailForReplyForNewUsers"] : $defaults["emailForReplyForNewUsers"];
		 $this->emailForCommentOnPostForNewUsers = isset($options["emailForCommentOnPostForNewUsers"]) ? $options["emailForCommentOnPostForNewUsers"] : $defaults["emailForCommentOnPostForNewUsers"];
		 $this->emailForSubscriptionsForNewUsers = isset($options["emailForSubscriptionsForNewUsers"]) ? $options["emailForSubscriptionsForNewUsers"] : $defaults["emailForSubscriptionsForNewUsers"];
		 $this->emailForFollowsForNewUsers = isset($options["emailForFollowsForNewUsers"]) ? $options["emailForFollowsForNewUsers"] : $defaults["emailForFollowsForNewUsers"];
		 /* /Emails for new users */
		 /* Notification messages */
		 $this->commentUpvoteNotificationMessage = isset($options["commentUpvoteNotificationMessage"]) ? wpautop($options["commentUpvoteNotificationMessage"]) : $defaults["commentUpvoteNotificationMessage"];
		 $this->commentDownvoteNotificationMessage = isset($options["commentDownvoteNotificationMessage"]) ? wpautop($options["commentDownvoteNotificationMessage"]) : $defaults["commentDownvoteNotificationMessage"];
		 $this->followNotificationMessage = isset($options["followNotificationMessage"]) ? wpautop($options["followNotificationMessage"]) : $defaults["followNotificationMessage"];
		 $this->postRatingNotificationMessage = isset($options["postRatingNotificationMessage"]) ? wpautop($options["postRatingNotificationMessage"]) : $defaults["postRatingNotificationMessage"];
		 $this->approvedCommentNotificationMessage = isset($options["approvedCommentNotificationMessage"]) ? wpautop($options["approvedCommentNotificationMessage"]) : $defaults["approvedCommentNotificationMessage"];
		 $this->mentionNotificationMessage = isset($options["mentionNotificationMessage"]) ? wpautop($options["mentionNotificationMessage"]) : $defaults["mentionNotificationMessage"];
		 $this->replyNotificationMessage = isset($options["replyNotificationMessage"]) ? wpautop($options["replyNotificationMessage"]) : $defaults["replyNotificationMessage"];
		 $this->commentOnPostNotificationMessage = isset($options["commentOnPostNotificationMessage"]) ? wpautop($options["commentOnPostNotificationMessage"]) : $defaults["commentOnPostNotificationMessage"];
		 $this->subscriptionsNotificationMessage = isset($options["subscriptionsNotificationMessage"]) ? wpautop($options["subscriptionsNotificationMessage"]) : $defaults["subscriptionsNotificationMessage"];
		 $this->followsNotificationMessage = isset($options["followsNotificationMessage"]) ? wpautop($options["followsNotificationMessage"]) : $defaults["followsNotificationMessage"];
		 /* /Notification messages */
		 /* Multiple notifications messages */
		 $this->multipleCommentUpvoteNotificationsMessage = isset($options["multipleCommentUpvoteNotificationsMessage"]) ? wpautop($options["multipleCommentUpvoteNotificationsMessage"]) : $defaults["multipleCommentUpvoteNotificationsMessage"];
		 $this->multipleCommentDownvoteNotificationsMessage = isset($options["multipleCommentDownvoteNotificationsMessage"]) ? wpautop($options["multipleCommentDownvoteNotificationsMessage"]) : $defaults["multipleCommentDownvoteNotificationsMessage"];
		 $this->multipleFollowNotificationsMessage = isset($options["multipleFollowNotificationsMessage"]) ? wpautop($options["multipleFollowNotificationsMessage"]) : $defaults["multipleFollowNotificationsMessage"];
		 $this->multiplePostRatingNotificationsMessage = isset($options["multiplePostRatingNotificationsMessage"]) ? wpautop($options["multiplePostRatingNotificationsMessage"]) : $defaults["multiplePostRatingNotificationsMessage"];
		 $this->multipleApprovedCommentNotificationsMessage = isset($options["multipleApprovedCommentNotificationsMessage"]) ? wpautop($options["multipleApprovedCommentNotificationsMessage"]) : $defaults["multipleApprovedCommentNotificationsMessage"];
		 $this->multipleMentionNotificationsMessage = isset($options["multipleMentionNotificationsMessage"]) ? wpautop($options["multipleMentionNotificationsMessage"]) : $defaults["multipleMentionNotificationsMessage"];
		 $this->multipleReplyNotificationsMessage = isset($options["multipleReplyNotificationsMessage"]) ? wpautop($options["multipleReplyNotificationsMessage"]) : $defaults["multipleReplyNotificationsMessage"];
		 $this->multipleCommentOnPostNotificationsMessage = isset($options["multipleCommentOnPostNotificationsMessage"]) ? wpautop($options["multipleCommentOnPostNotificationsMessage"]) : $defaults["multipleCommentOnPostNotificationsMessage"];
		 $this->multipleSubscriptionsNotificationsMessage = isset($options["multipleSubscriptionsNotificationsMessage"]) ? wpautop($options["multipleSubscriptionsNotificationsMessage"]) : $defaults["multipleSubscriptionsNotificationsMessage"];
		 $this->multipleFollowsNotificationsMessage = isset($options["multipleFollowsNotificationsMessage"]) ? wpautop($options["multipleFollowsNotificationsMessage"]) : $defaults["multipleFollowsNotificationsMessage"];
		 /* /Multiple notifications messages */
		 /* Email messages */
		 $this->upvoteEmailSubject = isset($options["upvoteEmailSubject"]) ? $options["upvoteEmailSubject"] : $defaults["upvoteEmailSubject"];
		 $this->upvoteEmailMessage = isset($options["upvoteEmailMessage"]) ? wpautop($options["upvoteEmailMessage"]) : $defaults["upvoteEmailMessage"];
		 $this->downvoteEmailSubject = isset($options["downvoteEmailSubject"]) ? $options["downvoteEmailSubject"] : $defaults["downvoteEmailSubject"];
		 $this->downvoteEmailMessage = isset($options["downvoteEmailMessage"]) ? wpautop($options["downvoteEmailMessage"]) : $defaults["downvoteEmailMessage"];
		 $this->followEmailSubject = isset($options["followEmailSubject"]) ? $options["followEmailSubject"] : $defaults["followEmailSubject"];
		 $this->followEmailMessage = isset($options["followEmailMessage"]) ? wpautop($options["followEmailMessage"]) : $defaults["followEmailMessage"];
		 $this->postRatingEmailSubject = isset($options["postRatingEmailSubject"]) ? $options["postRatingEmailSubject"] : $defaults["postRatingEmailSubject"];
		 $this->postRatingEmailMessage = isset($options["postRatingEmailMessage"]) ? wpautop($options["postRatingEmailMessage"]) : $defaults["postRatingEmailMessage"];
		 $this->replyEmailSubject = isset($options["replyEmailSubject"]) ? $options["replyEmailSubject"] : $defaults["replyEmailSubject"];
		 $this->replyEmailMessage = isset($options["replyEmailMessage"]) ? wpautop($options["replyEmailMessage"]) : $defaults["replyEmailMessage"];
		 $this->commentOnPostEmailSubject = isset($options["commentOnPostEmailSubject"]) ? $options["commentOnPostEmailSubject"] : $defaults["commentOnPostEmailSubject"];
		 $this->commentOnPostEmailMessage = isset($options["commentOnPostEmailMessage"]) ? wpautop($options["commentOnPostEmailMessage"]) : $defaults["commentOnPostEmailMessage"];
		 /* /Email messages */
		 /* Activity */
		 $this->activityForCommentVote = isset($options["activityForCommentVote"]) ? $options["activityForCommentVote"] : $defaults["activityForCommentVote"];
		 $this->activityForPostRating = isset($options["activityForPostRating"]) ? $options["activityForPostRating"] : $defaults["activityForPostRating"];
		 /* /Activity */
		 /* Activity Texts */
		 $this->commentUpvoteActivityMessage = isset($options["commentUpvoteActivityMessage"]) ? wpautop($options["commentUpvoteActivityMessage"]) : $defaults["commentUpvoteActivityMessage"];
		 $this->commentDownvoteActivityMessage = isset($options["commentDownvoteActivityMessage"]) ? wpautop($options["commentDownvoteActivityMessage"]) : $defaults["commentDownvoteActivityMessage"];
		 $this->postRatingActivityMessage = isset($options["postRatingActivityMessage"]) ? wpautop($options["postRatingActivityMessage"]) : $defaults["postRatingActivityMessage"];
		 /* /Activity Texts */
		 /* Profile Tabs */
		 $this->enableProfileCommentsTab = isset($options["enableProfileCommentsTab"]) ? $options["enableProfileCommentsTab"] : $defaults["enableProfileCommentsTab"];
		 $this->enableProfileSubscriptionsTab = isset($options["enableProfileSubscriptionsTab"]) ? $options["enableProfileSubscriptionsTab"] : $defaults["enableProfileSubscriptionsTab"];
		 $this->enableProfileReactionsTab = isset($options["enableProfileReactionsTab"]) ? $options["enableProfileReactionsTab"] : $defaults["enableProfileReactionsTab"];
		 $this->enableProfileRatesTab = isset($options["enableProfileRatesTab"]) ? $options["enableProfileRatesTab"] : $defaults["enableProfileRatesTab"];
		 $this->enableProfileVotesTab = isset($options["enableProfileVotesTab"]) ? $options["enableProfileVotesTab"] : $defaults["enableProfileVotesTab"];
		 $this->enableProfileFollowingTab = isset($options["enableProfileFollowingTab"]) ? $options["enableProfileFollowingTab"] : $defaults["enableProfileFollowingTab"];
		 $this->enableProfileFollowersTab = isset($options["enableProfileFollowersTab"]) ? $options["enableProfileFollowersTab"] : $defaults["enableProfileFollowersTab"];
		 $this->profileDiscussionsTabTitle = isset($options["profileDiscussionsTabTitle"]) ? $options["profileDiscussionsTabTitle"] : $defaults["profileDiscussionsTabTitle"];
		 $this->profileCommentsTabTitle = isset($options["profileCommentsTabTitle"]) ? $options["profileCommentsTabTitle"] : $defaults["profileCommentsTabTitle"];
		 $this->profileSubscriptionsTabTitle = isset($options["profileSubscriptionsTabTitle"]) ? $options["profileSubscriptionsTabTitle"] : $defaults["profileSubscriptionsTabTitle"];
		 $this->profileReactionsTabTitle = isset($options["profileReactionsTabTitle"]) ? $options["profileReactionsTabTitle"] : $defaults["profileReactionsTabTitle"];
		 $this->profileRatesTabTitle = isset($options["profileRatesTabTitle"]) ? $options["profileRatesTabTitle"] : $defaults["profileRatesTabTitle"];
		 $this->profileVotesTabTitle = isset($options["profileVotesTabTitle"]) ? $options["profileVotesTabTitle"] : $defaults["profileVotesTabTitle"];
		 $this->profileFollowingTabTitle = isset($options["profileFollowingTabTitle"]) ? $options["profileFollowingTabTitle"] : $defaults["profileFollowingTabTitle"];
		 $this->profileFollowersTabTitle = isset($options["profileFollowersTabTitle"]) ? $options["profileFollowersTabTitle"] : $defaults["profileFollowersTabTitle"];
		 /* /Profile Tabs */
		 /* Common */
		 $this->changeUserSettingsButton = isset($options["changeUserSettingsButton"]) ? $options["changeUserSettingsButton"] : $defaults["changeUserSettingsButton"];
		 $this->guestPhrase = isset($options["guestPhrase"]) ? $options["guestPhrase"] : $defaults["guestPhrase"];
		 $this->notificationSettingsTabTitle = isset($options["notificationSettingsTabTitle"]) ? $options["notificationSettingsTabTitle"] : $defaults["notificationSettingsTabTitle"];
		 /* /Common */
	 }

	 public function saveOptions() {
		 if ($this->tabKey === $_POST["wpd_tab"]) {
			 $defaults = $this->getDefaultOptions();
			 /* Notifications */
			 $this->notificationForCommentVote = !empty($_POST[$this->tabKey]["notificationForCommentVote"]) ? intval($_POST[$this->tabKey]["notificationForCommentVote"]) : 0;
			 $this->notificationForFollow = !empty($_POST[$this->tabKey]["notificationForFollow"]) ? intval($_POST[$this->tabKey]["notificationForFollow"]) : 0;
			 $this->notificationForPostRating = !empty($_POST[$this->tabKey]["notificationForPostRating"]) ? intval($_POST[$this->tabKey]["notificationForPostRating"]) : 0;
			 $this->notificationForApprovedComment = !empty($_POST[$this->tabKey]["notificationForApprovedComment"]) ? intval($_POST[$this->tabKey]["notificationForApprovedComment"]) : 0;
			 $this->notificationForMention = !empty($_POST[$this->tabKey]["notificationForMention"]) ? intval($_POST[$this->tabKey]["notificationForMention"]) : 0;
			 $this->notificationForReply = !empty($_POST[$this->tabKey]["notificationForReply"]) ? intval($_POST[$this->tabKey]["notificationForReply"]) : 0;
			 $this->notificationForCommentOnPost = !empty($_POST[$this->tabKey]["notificationForCommentOnPost"]) ? intval($_POST[$this->tabKey]["notificationForCommentOnPost"]) : 0;
			 $this->notificationForSubscriptions = !empty($_POST[$this->tabKey]["notificationForSubscriptions"]) ? intval($_POST[$this->tabKey]["notificationForSubscriptions"]) : 0;
			 $this->notificationForFollows = !empty($_POST[$this->tabKey]["notificationForFollows"]) ? intval($_POST[$this->tabKey]["notificationForFollows"]) : 0;
			 /* /Notifications */
			 /* Emails */
			 $this->emailForCommentVote = !empty($_POST[$this->tabKey]["emailForCommentVote"]) ? intval($_POST[$this->tabKey]["emailForCommentVote"]) : 0;
			 $this->emailForFollow = !empty($_POST[$this->tabKey]["emailForFollow"]) ? intval($_POST[$this->tabKey]["emailForFollow"]) : 0;
			 $this->emailForPostRating = !empty($_POST[$this->tabKey]["emailForPostRating"]) ? intval($_POST[$this->tabKey]["emailForPostRating"]) : 0;
			 $this->emailForApprovedComment = !empty($_POST[$this->tabKey]["emailForApprovedComment"]) ? intval($_POST[$this->tabKey]["emailForApprovedComment"]) : 0;
			 $this->emailForMention = !empty($_POST[$this->tabKey]["emailForMention"]) ? intval($_POST[$this->tabKey]["emailForMention"]) : 0;
			 $this->emailForReply = !empty($_POST[$this->tabKey]["emailForReply"]) ? intval($_POST[$this->tabKey]["emailForReply"]) : 0;
			 $this->emailForCommentOnPost = !empty($_POST[$this->tabKey]["emailForCommentOnPost"]) ? intval($_POST[$this->tabKey]["emailForCommentOnPost"]) : 0;
			 $this->emailForSubscriptions = !empty($_POST[$this->tabKey]["emailForSubscriptions"]) ? intval($_POST[$this->tabKey]["emailForSubscriptions"]) : 0;
			 $this->emailForFollows = !empty($_POST[$this->tabKey]["emailForFollows"]) ? intval($_POST[$this->tabKey]["emailForFollows"]) : 0;
			 /* /Emails */
			 /* Notifications for new users */
			 $this->notificationForCommentVoteForNewUsers = !empty($_POST[$this->tabKey]["notificationForCommentVoteForNewUsers"]) ? ($this->notificationForCommentVote ? intval($_POST[$this->tabKey]["notificationForCommentVoteForNewUsers"]) : 0) : 0;
			 $this->notificationForFollowForNewUsers = !empty($_POST[$this->tabKey]["notificationForFollowForNewUsers"]) ? ($this->notificationForFollow ? intval($_POST[$this->tabKey]["notificationForFollowForNewUsers"]) : 0) : 0;
			 $this->notificationForPostRatingForNewUsers = !empty($_POST[$this->tabKey]["notificationForPostRatingForNewUsers"]) ? ($this->notificationForPostRating ? intval($_POST[$this->tabKey]["notificationForPostRatingForNewUsers"]) : 0) : 0;
			 $this->notificationForApprovedCommentForNewUsers = !empty($_POST[$this->tabKey]["notificationForApprovedCommentForNewUsers"]) ? ($this->notificationForApprovedComment ? intval($_POST[$this->tabKey]["notificationForApprovedCommentForNewUsers"]) : 0) : 0;
			 $this->notificationForMentionForNewUsers = !empty($_POST[$this->tabKey]["notificationForMentionForNewUsers"]) ? ($this->notificationForMention ? intval($_POST[$this->tabKey]["notificationForMentionForNewUsers"]) : 0) : 0;
			 $this->notificationForReplyForNewUsers = !empty($_POST[$this->tabKey]["notificationForReplyForNewUsers"]) ? ($this->notificationForReply ? intval($_POST[$this->tabKey]["notificationForReplyForNewUsers"]) : 0) : 0;
			 $this->notificationForCommentOnPostForNewUsers = !empty($_POST[$this->tabKey]["notificationForCommentOnPostForNewUsers"]) ? ($this->notificationForCommentOnPost ? intval($_POST[$this->tabKey]["notificationForCommentOnPostForNewUsers"]) : 0) : 0;
			 $this->notificationForSubscriptionsForNewUsers = !empty($_POST[$this->tabKey]["notificationForSubscriptionsForNewUsers"]) ? ($this->notificationForSubscriptions ? intval($_POST[$this->tabKey]["notificationForSubscriptionsForNewUsers"]) : 0) : 0;
			 $this->notificationForFollowsForNewUsers = !empty($_POST[$this->tabKey]["notificationForFollowsForNewUsers"]) ? ($this->notificationForFollows ? intval($_POST[$this->tabKey]["notificationForFollowsForNewUsers"]) : 0) : 0;
			 /* /Notifications for new users */
			 /* Emails for new users */
			 $this->emailForCommentVoteForNewUsers = !empty($_POST[$this->tabKey]["emailForCommentVoteForNewUsers"]) ? ($this->emailForCommentVote ? intval($_POST[$this->tabKey]["emailForCommentVoteForNewUsers"]) : 0) : 0;
			 $this->emailForFollowForNewUsers = !empty($_POST[$this->tabKey]["emailForFollowForNewUsers"]) ? ($this->emailForFollow ? intval($_POST[$this->tabKey]["emailForFollowForNewUsers"]) : 0) : 0;
			 $this->emailForPostRatingForNewUsers = !empty($_POST[$this->tabKey]["emailForPostRatingForNewUsers"]) ? ($this->emailForPostRating ? intval($_POST[$this->tabKey]["emailForPostRatingForNewUsers"]) : 0) : 0;
			 $this->emailForApprovedCommentForNewUsers = !empty($_POST[$this->tabKey]["emailForApprovedCommentForNewUsers"]) ? ($this->emailForApprovedComment ? intval($_POST[$this->tabKey]["emailForApprovedCommentForNewUsers"]) : 0) : 0;
			 $this->emailForMentionForNewUsers = !empty($_POST[$this->tabKey]["emailForMentionForNewUsers"]) ? ($this->emailForMention ? intval($_POST[$this->tabKey]["emailForMentionForNewUsers"]) : 0) : 0;
			 $this->emailForReplyForNewUsers = !empty($_POST[$this->tabKey]["emailForReplyForNewUsers"]) ? ($this->emailForReply ? intval($_POST[$this->tabKey]["emailForReplyForNewUsers"]) : 0) : 0;
			 $this->emailForCommentOnPostForNewUsers = !empty($_POST[$this->tabKey]["emailForCommentOnPostForNewUsers"]) ? ($this->emailForCommentOnPost ? intval($_POST[$this->tabKey]["emailForCommentOnPostForNewUsers"]) : 0) : 0;
			 $this->emailForSubscriptionsForNewUsers = !empty($_POST[$this->tabKey]["emailForSubscriptionsForNewUsers"]) ? ($this->emailForSubscriptions ? intval($_POST[$this->tabKey]["emailForSubscriptionsForNewUsers"]) : 0) : 0;
			 $this->emailForFollowsForNewUsers = !empty($_POST[$this->tabKey]["emailForFollowsForNewUsers"]) ? ($this->emailForFollows ? intval($_POST[$this->tabKey]["emailForFollowsForNewUsers"]) : 0) : 0;
			 /* /Emails for new users */
			 /* Notification messages */
			 $this->commentUpvoteNotificationMessage = !empty($_POST[$this->tabKey]["commentUpvoteNotificationMessage"]) ? stripslashes($_POST[$this->tabKey]["commentUpvoteNotificationMessage"]) : $defaults["commentUpvoteNotificationMessage"];
			 $this->commentDownvoteNotificationMessage = !empty($_POST[$this->tabKey]["commentDownvoteNotificationMessage"]) ? stripslashes($_POST[$this->tabKey]["commentDownvoteNotificationMessage"]) : $defaults["commentDownvoteNotificationMessage"];
			 $this->followNotificationMessage = !empty($_POST[$this->tabKey]["followNotificationMessage"]) ? stripslashes($_POST[$this->tabKey]["followNotificationMessage"]) : $defaults["followNotificationMessage"];
			 $this->postRatingNotificationMessage = !empty($_POST[$this->tabKey]["postRatingNotificationMessage"]) ? stripslashes($_POST[$this->tabKey]["postRatingNotificationMessage"]) : $defaults["postRatingNotificationMessage"];
			 $this->approvedCommentNotificationMessage = !empty($_POST[$this->tabKey]["approvedCommentNotificationMessage"]) ? stripslashes($_POST[$this->tabKey]["approvedCommentNotificationMessage"]) : $defaults["approvedCommentNotificationMessage"];
			 $this->mentionNotificationMessage = !empty($_POST[$this->tabKey]["mentionNotificationMessage"]) ? stripslashes($_POST[$this->tabKey]["mentionNotificationMessage"]) : $defaults["mentionNotificationMessage"];
			 $this->replyNotificationMessage = !empty($_POST[$this->tabKey]["replyNotificationMessage"]) ? stripslashes($_POST[$this->tabKey]["replyNotificationMessage"]) : $defaults["replyNotificationMessage"];
			 $this->commentOnPostNotificationMessage = !empty($_POST[$this->tabKey]["commentOnPostNotificationMessage"]) ? stripslashes($_POST[$this->tabKey]["commentOnPostNotificationMessage"]) : $defaults["commentOnPostNotificationMessage"];
			 $this->subscriptionsNotificationMessage = !empty($_POST[$this->tabKey]["subscriptionsNotificationMessage"]) ? stripslashes($_POST[$this->tabKey]["subscriptionsNotificationMessage"]) : $defaults["subscriptionsNotificationMessage"];
			 $this->followsNotificationMessage = !empty($_POST[$this->tabKey]["followsNotificationMessage"]) ? stripslashes($_POST[$this->tabKey]["followsNotificationMessage"]) : $defaults["followsNotificationMessage"];
			 /* /Notification messages */
			 /* Multiple notifications messages */
			 $this->multipleCommentUpvoteNotificationsMessage = !empty($_POST[$this->tabKey]["multipleCommentUpvoteNotificationsMessage"]) ? stripslashes($_POST[$this->tabKey]["multipleCommentUpvoteNotificationsMessage"]) : $defaults["multipleCommentUpvoteNotificationsMessage"];
			 $this->multipleCommentDownvoteNotificationsMessage = !empty($_POST[$this->tabKey]["multipleCommentDownvoteNotificationsMessage"]) ? stripslashes($_POST[$this->tabKey]["multipleCommentDownvoteNotificationsMessage"]) : $defaults["multipleCommentDownvoteNotificationsMessage"];
			 $this->multipleFollowNotificationsMessage = !empty($_POST[$this->tabKey]["multipleFollowNotificationsMessage"]) ? stripslashes($_POST[$this->tabKey]["multipleFollowNotificationsMessage"]) : $defaults["multipleFollowNotificationsMessage"];
			 $this->multiplePostRatingNotificationsMessage = !empty($_POST[$this->tabKey]["multiplePostRatingNotificationsMessage"]) ? stripslashes($_POST[$this->tabKey]["multiplePostRatingNotificationsMessage"]) : $defaults["multiplePostRatingNotificationsMessage"];
			 $this->multipleApprovedCommentNotificationsMessage = !empty($_POST[$this->tabKey]["multipleApprovedCommentNotificationsMessage"]) ? stripslashes($_POST[$this->tabKey]["multipleApprovedCommentNotificationsMessage"]) : $defaults["multipleApprovedCommentNotificationsMessage"];
			 $this->multipleMentionNotificationsMessage = !empty($_POST[$this->tabKey]["multipleMentionNotificationsMessage"]) ? stripslashes($_POST[$this->tabKey]["multipleMentionNotificationsMessage"]) : $defaults["multipleMentionNotificationsMessage"];
			 $this->multipleReplyNotificationsMessage = !empty($_POST[$this->tabKey]["multipleReplyNotificationsMessage"]) ? stripslashes($_POST[$this->tabKey]["multipleReplyNotificationsMessage"]) : $defaults["multipleReplyNotificationsMessage"];
			 $this->multipleCommentOnPostNotificationsMessage = !empty($_POST[$this->tabKey]["multipleCommentOnPostNotificationsMessage"]) ? stripslashes($_POST[$this->tabKey]["multipleCommentOnPostNotificationsMessage"]) : $defaults["multipleCommentOnPostNotificationsMessage"];
			 $this->multipleSubscriptionsNotificationsMessage = !empty($_POST[$this->tabKey]["multipleSubscriptionsNotificationsMessage"]) ? stripslashes($_POST[$this->tabKey]["multipleSubscriptionsNotificationsMessage"]) : $defaults["multipleSubscriptionsNotificationsMessage"];
			 $this->multipleFollowsNotificationsMessage = !empty($_POST[$this->tabKey]["multipleFollowsNotificationsMessage"]) ? stripslashes($_POST[$this->tabKey]["multipleFollowsNotificationsMessage"]) : $defaults["multipleFollowsNotificationsMessage"];
			 /* /Multiple notifications messages */
			 /* Email messages */
			 $this->upvoteEmailSubject = isset($_POST[$this->tabKey]["upvoteEmailSubject"]) ? stripslashes($_POST[$this->tabKey]["upvoteEmailSubject"]) : $defaults["upvoteEmailSubject"];
			 $this->upvoteEmailMessage = isset($_POST[$this->tabKey]["upvoteEmailMessage"]) ? stripslashes($_POST[$this->tabKey]["upvoteEmailMessage"]) : $defaults["upvoteEmailMessage"];
			 $this->downvoteEmailSubject = isset($_POST[$this->tabKey]["downvoteEmailSubject"]) ? stripslashes($_POST[$this->tabKey]["downvoteEmailSubject"]) : $defaults["downvoteEmailSubject"];
			 $this->downvoteEmailMessage = isset($_POST[$this->tabKey]["downvoteEmailMessage"]) ? stripslashes($_POST[$this->tabKey]["downvoteEmailMessage"]) : $defaults["downvoteEmailMessage"];
			 $this->followEmailSubject = isset($_POST[$this->tabKey]["followEmailSubject"]) ? stripslashes($_POST[$this->tabKey]["followEmailSubject"]) : $defaults["followEmailSubject"];
			 $this->followEmailMessage = isset($_POST[$this->tabKey]["followEmailMessage"]) ? stripslashes($_POST[$this->tabKey]["followEmailMessage"]) : $defaults["followEmailMessage"];
			 $this->postRatingEmailSubject = isset($_POST[$this->tabKey]["postRatingEmailSubject"]) ? stripslashes($_POST[$this->tabKey]["postRatingEmailSubject"]) : $defaults["postRatingEmailSubject"];
			 $this->postRatingEmailMessage = isset($_POST[$this->tabKey]["postRatingEmailMessage"]) ? stripslashes($_POST[$this->tabKey]["postRatingEmailMessage"]) : $defaults["postRatingEmailMessage"];
			 $this->replyEmailSubject = isset($_POST[$this->tabKey]["replyEmailSubject"]) ? stripslashes($_POST[$this->tabKey]["replyEmailSubject"]) : $defaults["replyEmailSubject"];
			 $this->replyEmailMessage = isset($_POST[$this->tabKey]["replyEmailMessage"]) ? stripslashes($_POST[$this->tabKey]["replyEmailMessage"]) : $defaults["replyEmailMessage"];
			 $this->commentOnPostEmailSubject = isset($_POST[$this->tabKey]["commentOnPostEmailSubject"]) ? stripslashes($_POST[$this->tabKey]["commentOnPostEmailSubject"]) : $defaults["commentOnPostEmailSubject"];
			 $this->commentOnPostEmailMessage = isset($_POST[$this->tabKey]["commentOnPostEmailMessage"]) ? stripslashes($_POST[$this->tabKey]["commentOnPostEmailMessage"]) : $defaults["commentOnPostEmailMessage"];
			 /* /Email messages */
			 /* Activity */
			 $this->activityForCommentVote = !empty($_POST[$this->tabKey]["activityForCommentVote"]) ? intval($_POST[$this->tabKey]["activityForCommentVote"]) : 0;
			 $this->activityForPostRating = !empty($_POST[$this->tabKey]["activityForPostRating"]) ? intval($_POST[$this->tabKey]["activityForPostRating"]) : 0;
			 /* /Activity */
			 /* Activity Texts */
			 $this->commentUpvoteActivityMessage = !empty($_POST[$this->tabKey]["commentUpvoteActivityMessage"]) ? stripslashes($_POST[$this->tabKey]["commentUpvoteActivityMessage"]) : $defaults["commentUpvoteActivityMessage"];
			 $this->commentDownvoteActivityMessage = !empty($_POST[$this->tabKey]["commentDownvoteActivityMessage"]) ? stripslashes($_POST[$this->tabKey]["commentDownvoteActivityMessage"]) : $defaults["commentDownvoteActivityMessage"];
			 $this->postRatingActivityMessage = !empty($_POST[$this->tabKey]["postRatingActivityMessage"]) ? stripslashes($_POST[$this->tabKey]["postRatingActivityMessage"]) : $defaults["postRatingActivityMessage"];
			 /* /Activity Texts */
			 /* Profile Tabs */
			 $this->enableProfileCommentsTab = !empty($_POST[$this->tabKey]["enableProfileCommentsTab"]) ? intval($_POST[$this->tabKey]["enableProfileCommentsTab"]) : 0;
			 $this->enableProfileSubscriptionsTab = !empty($_POST[$this->tabKey]["enableProfileSubscriptionsTab"]) ? intval($_POST[$this->tabKey]["enableProfileSubscriptionsTab"]) : 0;
			 $this->enableProfileReactionsTab = !empty($_POST[$this->tabKey]["enableProfileReactionsTab"]) ? intval($_POST[$this->tabKey]["enableProfileReactionsTab"]) : 0;
			 $this->enableProfileRatesTab = !empty($_POST[$this->tabKey]["enableProfileRatesTab"]) ? intval($_POST[$this->tabKey]["enableProfileRatesTab"]) : 0;
			 $this->enableProfileVotesTab = !empty($_POST[$this->tabKey]["enableProfileVotesTab"]) ? intval($_POST[$this->tabKey]["enableProfileVotesTab"]) : 0;
			 $this->enableProfileFollowingTab = !empty($_POST[$this->tabKey]["enableProfileFollowingTab"]) ? intval($_POST[$this->tabKey]["enableProfileFollowingTab"]) : 0;
			 $this->enableProfileFollowersTab = !empty($_POST[$this->tabKey]["enableProfileFollowersTab"]) ? intval($_POST[$this->tabKey]["enableProfileFollowersTab"]) : 0;
			 $this->profileDiscussionsTabTitle = isset($_POST[$this->tabKey]["profileDiscussionsTabTitle"]) ? strip_tags(stripslashes($_POST[$this->tabKey]["profileDiscussionsTabTitle"])) : $defaults["profileDiscussionsTabTitle"];
			 $this->profileCommentsTabTitle = isset($_POST[$this->tabKey]["profileCommentsTabTitle"]) ? strip_tags(stripslashes($_POST[$this->tabKey]["profileCommentsTabTitle"])) : $defaults["profileCommentsTabTitle"];
			 $this->profileSubscriptionsTabTitle = isset($_POST[$this->tabKey]["profileSubscriptionsTabTitle"]) ? strip_tags(stripslashes($_POST[$this->tabKey]["profileSubscriptionsTabTitle"])) : $defaults["profileSubscriptionsTabTitle"];
			 $this->profileReactionsTabTitle = isset($_POST[$this->tabKey]["profileReactionsTabTitle"]) ? strip_tags(stripslashes($_POST[$this->tabKey]["profileReactionsTabTitle"])) : $defaults["profileReactionsTabTitle"];
			 $this->profileRatesTabTitle = isset($_POST[$this->tabKey]["profileRatesTabTitle"]) ? strip_tags(stripslashes($_POST[$this->tabKey]["profileRatesTabTitle"])) : $defaults["profileRatesTabTitle"];
			 $this->profileVotesTabTitle = isset($_POST[$this->tabKey]["profileVotesTabTitle"]) ? strip_tags(stripslashes($_POST[$this->tabKey]["profileVotesTabTitle"])) : $defaults["profileVotesTabTitle"];
			 $this->profileFollowingTabTitle = isset($_POST[$this->tabKey]["profileFollowingTabTitle"]) ? strip_tags(stripslashes($_POST[$this->tabKey]["profileFollowingTabTitle"])) : $defaults["profileFollowingTabTitle"];
			 $this->profileFollowersTabTitle = isset($_POST[$this->tabKey]["profileFollowersTabTitle"]) ? strip_tags(stripslashes($_POST[$this->tabKey]["profileFollowersTabTitle"])) : $defaults["profileFollowersTabTitle"];
			 /* /Profile Tabs */
			 /* Common */
			 $this->changeUserSettingsButton = !empty($_POST[$this->tabKey]["changeUserSettingsButton"]) ? intval($_POST[$this->tabKey]["changeUserSettingsButton"]) : 0;
			 $this->guestPhrase = isset($_POST[$this->tabKey]["guestPhrase"]) ? stripslashes($_POST[$this->tabKey]["guestPhrase"]) : $defaults["guestPhrase"];
			 $this->notificationSettingsTabTitle = isset($_POST[$this->tabKey]["notificationSettingsTabTitle"]) ? strip_tags(stripslashes($_POST[$this->tabKey]["notificationSettingsTabTitle"])) : $defaults["notificationSettingsTabTitle"];
			 /* /Common */
			 update_option(self::OPTION_SLUG_OPTIONS, $this->getOptionsArray());
		 }
	 }

	 public function resetOptions($tab) {
		 if ($tab === $this->tabKey || $tab === "all") {
			 delete_option(self::OPTION_SLUG_OPTIONS);
			 $this->addOption();
			 $this->initOptions($this->getDefaultOptions());
		 }
	 }

	 public function getDefaultOptions() {
		 return [
			 /* Notifications */
			 "notificationForCommentVote" => 1,
			 "notificationForFollow" => 1,
			 "notificationForPostRating" => 1,
			 "notificationForApprovedComment" => 1,
			 "notificationForMention" => 1,
			 "notificationForReply" => 1,
			 "notificationForCommentOnPost" => 1,
			 "notificationForSubscriptions" => 1,
			 "notificationForFollows" => 1,
			 /* /Notifications */
			 /* Emails */
			 "emailForCommentVote" => 0,
			 "emailForFollow" => 1,
			 "emailForPostRating" => 1,
			 "emailForApprovedComment" => 1,
			 "emailForMention" => 1,
			 "emailForReply" => 1,
			 "emailForCommentOnPost" => 1,
			 "emailForSubscriptions" => 1,
			 "emailForFollows" => 1,
			 /* /Emails */
			 /* Notifications for new users */
			 "notificationForCommentVoteForNewUsers" => 1,
			 "notificationForFollowForNewUsers" => 1,
			 "notificationForPostRatingForNewUsers" => 1,
			 "notificationForApprovedCommentForNewUsers" => 1,
			 "notificationForMentionForNewUsers" => 1,
			 "notificationForReplyForNewUsers" => 1,
			 "notificationForCommentOnPostForNewUsers" => 1,
			 "notificationForSubscriptionsForNewUsers" => 1,
			 "notificationForFollowsForNewUsers" => 1,
			 /* /Notifications for new users */
			 /* Emails for new users */
			 "emailForCommentVoteForNewUsers" => 0,
			 "emailForFollowForNewUsers" => 1,
			 "emailForPostRatingForNewUsers" => 1,
			 "emailForApprovedCommentForNewUsers" => 1,
			 "emailForMentionForNewUsers" => 1,
			 "emailForReplyForNewUsers" => 1,
			 "emailForCommentOnPostForNewUsers" => 1,
			 "emailForSubscriptionsForNewUsers" => 1,
			 "emailForFollowsForNewUsers" => 1,
			 /* /Emails for new users */
			 /* Notification messages */
			 "commentUpvoteNotificationMessage" => __("<a href='[VOTER_URL]'>[VOTER_NAME]</a> gave you an <a href='[COMMENT_URL]'>upvote</a>", "wpdiscuz-buddypress-integration"),
			 "commentDownvoteNotificationMessage" => __("<a href='[VOTER_URL]'>[VOTER_NAME]</a> gave you an <a href='[COMMENT_URL]'>downvote</a>", "wpdiscuz-buddypress-integration"),
			 "followNotificationMessage" => __("<a href='[FOLLOWER_URL]'>[FOLLOWER_NAME]</a> followed you", "wpdiscuz-buddypress-integration"),
			 "postRatingNotificationMessage" => __("<a href='[RATER_URL]'>[RATER_NAME]</a> rated your post: <a href='[POST_URL]'>[POST_TITLE]</a>", "wpdiscuz-buddypress-integration"),
			 "approvedCommentNotificationMessage" => __("Your <a href='[COMMENT_URL]'>comment</a> is approved", "wpdiscuz-buddypress-integration"),
			 "mentionNotificationMessage" => __("You have been <a href='[COMMENT_URL]'>mentioned</a> by <a href='[AUTHOR_URL]'>[AUTHOR_NAME]</a>", "wpdiscuz-buddypress-integration"),
			 "replyNotificationMessage" => __("<a href='[AUTHOR_URL]'>[AUTHOR_NAME]</a> has <a href='[COMMENT_URL]'>replied</a> to your comment under the post: <a href='[POST_URL]'>[POST_TITLE]</a>", "wpdiscuz-buddypress-integration"),
			 "commentOnPostNotificationMessage" => __("<a href='[AUTHOR_URL]'>[AUTHOR_NAME]</a> has <a href='[COMMENT_URL]'>commented</a> on your post: <a href='[POST_URL]'>[POST_TITLE]</a>", "wpdiscuz-buddypress-integration"),
			 "subscriptionsNotificationMessage" => __("<a href='[AUTHOR_URL]'>[AUTHOR_NAME]</a> has <a href='[COMMENT_URL]'>commented</a> on <a href='[POST_URL]'>[POST_TITLE]</a>", "wpdiscuz-buddypress-integration"),
			 "followsNotificationMessage" => __("<a href='[AUTHOR_URL]'>[AUTHOR_NAME]</a> has left a <a href='[COMMENT_URL]'>comment</a> on <a href='[POST_URL]'>[POST_TITLE]</a>", "wpdiscuz-buddypress-integration"),
			 /* /Notification messages */
			 /* Multiple notifications messages */
			 "multipleCommentUpvoteNotificationsMessage" => __("You have %d new upvotes", "wpdiscuz-buddypress-integration"),
			 "multipleCommentDownvoteNotificationsMessage" => __("You have %d new downvotes", "wpdiscuz-buddypress-integration"),
			 "multipleFollowNotificationsMessage" => __("You have %d new followers", "wpdiscuz-buddypress-integration"),
			 "multiplePostRatingNotificationsMessage" => __("You have %d new post ratings", "wpdiscuz-buddypress-integration"),
			 "multipleApprovedCommentNotificationsMessage" => __("You have %d approved comments", "wpdiscuz-buddypress-integration"),
			 "multipleMentionNotificationsMessage" => __("You have %d new mentions", "wpdiscuz-buddypress-integration"),
			 "multipleReplyNotificationsMessage" => __("You have %d new replies", "wpdiscuz-buddypress-integration"),
			 "multipleCommentOnPostNotificationsMessage" => __("You have %d new comments on your posts", "wpdiscuz-buddypress-integration"),
			 "multipleSubscriptionsNotificationsMessage" => __("You have %d new comments from your subscriptions", "wpdiscuz-buddypress-integration"),
			 "multipleFollowsNotificationsMessage" => __("%d new comments from users you follow", "wpdiscuz-buddypress-integration"),
			 /* /Multiple notifications messages */
			 /* Email messages */
			 "upvoteEmailSubject" => esc_html__("[VOTER_NAME] gave you an upvote", "wpdiscuz-buddypress-integration"),
			 "upvoteEmailMessage" => __("Hi [SUBSCRIBER_NAME],<br/><br/><a href='[VOTER_URL]'>[VOTER_NAME]</a> gave you an <a href='[COMMENT_URL]'>upvote</a>.", "wpdiscuz-buddypress-integration"),
			 "downvoteEmailSubject" => esc_html__("[VOTER_NAME] gave you an downvote", "wpdiscuz-buddypress-integration"),
			 "downvoteEmailMessage" => __("Hi [SUBSCRIBER_NAME],<br/><br/><a href='[VOTER_URL]'>[VOTER_NAME]</a> gave you an <a href='[COMMENT_URL]'>downvote</a>.", "wpdiscuz-buddypress-integration"),
			 "followEmailSubject" => esc_html__("[FOLLOWER_NAME] followed you", "wpdiscuz-buddypress-integration"),
			 "followEmailMessage" => __("Hi [SUBSCRIBER_NAME],<br/><br/><a href='[FOLLOWER_URL]'>[FOLLOWER_NAME]</a> is now following you.", "wpdiscuz-buddypress-integration"),
			 "postRatingEmailSubject" => esc_html__("[RATER_NAME] rated your post", "wpdiscuz-buddypress-integration"),
			 "postRatingEmailMessage" => __("Hi [SUBSCRIBER_NAME],<br/><br/><a href='[RATER_URL]'>[RATER_NAME]</a> rated your post: <a href='[POST_URL]'>[POST_TITLE]</a>.", "wpdiscuz-buddypress-integration"),
			 "replyEmailSubject" => esc_html__("[AUTHOR_NAME] has replied to your comment", "wpdiscuz-buddypress-integration"),
			 "replyEmailMessage" => __("Hi [SUBSCRIBER_NAME],<br/><br/><a href='[AUTHOR_URL]'>[AUTHOR_NAME]</a> has <a href='[COMMENT_URL]'>replied</a> to your comment under the post: <a href='[POST_URL]'>[POST_TITLE]</a>.", "wpdiscuz-buddypress-integration"),
			 "commentOnPostEmailSubject" => esc_html__("[AUTHOR_NAME] has commented on your post", "wpdiscuz-buddypress-integration"),
			 "commentOnPostEmailMessage" => __("Hi [SUBSCRIBER_NAME],<br/><br/><a href='[AUTHOR_URL]'>[AUTHOR_NAME]</a> has <a href='[COMMENT_URL]'>commented</a> on your post: <a href='[POST_URL]'>[POST_TITLE]</a>.", "wpdiscuz-buddypress-integration"),
			 /* /Email messages */
			 /* Activity */
			 "activityForCommentVote" => 1,
			 "activityForPostRating" => 1,
			 /* /Activity */
			 /* Activity Texts */
			 "commentUpvoteActivityMessage" => __("<a href='[VOTER_URL]'>[VOTER_NAME]</a> upvoted <a href='[COMMENT_URL]'>comment</a> on the post <a href='[POST_URL]'>[POST_TITLE]</a>", "wpdiscuz-buddypress-integration"),
			 "commentDownvoteActivityMessage" => __("<a href='[VOTER_URL]'>[VOTER_NAME]</a> downvoted <a href='[COMMENT_URL]'>comment</a> on the post <a href='[POST_URL]'>[POST_TITLE]</a>", "wpdiscuz-buddypress-integration"),
			 "postRatingActivityMessage" => __("<a href='[RATER_URL]'>[RATER_NAME]</a> rated [RATING] stars <a href='[POST_URL]'>[POST_TITLE]</a>", "wpdiscuz-buddypress-integration"),
			 /* /Activity Texts */
			 /* Profile Tabs */
			 "enableProfileCommentsTab" => 1,
			 "enableProfileSubscriptionsTab" => 1,
			 "enableProfileReactionsTab" => 1,
			 "enableProfileRatesTab" => 1,
			 "enableProfileVotesTab" => 1,
			 "enableProfileFollowingTab" => 1,
			 "enableProfileFollowersTab" => 1,
			 "profileDiscussionsTabTitle" => esc_html__("Discussions", "wpdiscuz-buddypress-integration"),
			 "profileCommentsTabTitle" => esc_html__("Comments", "wpdiscuz-buddypress-integration"),
			 "profileSubscriptionsTabTitle" => esc_html__("Subscriptions", "wpdiscuz-buddypress-integration"),
			 "profileReactionsTabTitle" => esc_html__("Reactions", "wpdiscuz-buddypress-integration"),
			 "profileRatesTabTitle" => esc_html__("Rates", "wpdiscuz-buddypress-integration"),
			 "profileVotesTabTitle" => esc_html__("Votes", "wpdiscuz-buddypress-integration"),
			 "profileFollowingTabTitle" => esc_html__("Following", "wpdiscuz-buddypress-integration"),
			 "profileFollowersTabTitle" => esc_html__("Followers", "wpdiscuz-buddypress-integration"),
			 /* /Profile Tabs */
			 /* Common */
			 "changeUserSettingsButton" => 0,
			 "guestPhrase" => esc_html__("Guest", "wpdiscuz-buddypress-integration"),
			 "notificationSettingsTabTitle" => esc_html__("Settings", "wpdiscuz-buddypress-integration"),
			 /* /Common */
		 ];
	 }

	 public function getOptionsArray() {
		 return [
			 /* Notifications */
			 "notificationForCommentVote" => $this->notificationForCommentVote,
			 "notificationForFollow" => $this->notificationForFollow,
			 "notificationForPostRating" => $this->notificationForPostRating,
			 "notificationForApprovedComment" => $this->notificationForApprovedComment,
			 "notificationForMention" => $this->notificationForMention,
			 "notificationForReply" => $this->notificationForReply,
			 "notificationForCommentOnPost" => $this->notificationForCommentOnPost,
			 "notificationForSubscriptions" => $this->notificationForSubscriptions,
			 "notificationForFollows" => $this->notificationForFollows,
			 /* /Notifications */
			 /* Emails */
			 "emailForCommentVote" => $this->emailForCommentVote,
			 "emailForFollow" => $this->emailForFollow,
			 "emailForPostRating" => $this->emailForPostRating,
			 "emailForApprovedComment" => $this->emailForApprovedComment,
			 "emailForMention" => $this->emailForMention,
			 "emailForReply" => $this->emailForReply,
			 "emailForCommentOnPost" => $this->emailForCommentOnPost,
			 "emailForSubscriptions" => $this->emailForSubscriptions,
			 "emailForFollows" => $this->emailForFollows,
			 /* /Emails */
			 /* Notifications for new users */
			 "notificationForCommentVoteForNewUsers" => $this->notificationForCommentVoteForNewUsers,
			 "notificationForFollowForNewUsers" => $this->notificationForFollowForNewUsers,
			 "notificationForPostRatingForNewUsers" => $this->notificationForPostRatingForNewUsers,
			 "notificationForApprovedCommentForNewUsers" => $this->notificationForApprovedCommentForNewUsers,
			 "notificationForMentionForNewUsers" => $this->notificationForMentionForNewUsers,
			 "notificationForReplyForNewUsers" => $this->notificationForReplyForNewUsers,
			 "notificationForCommentOnPostForNewUsers" => $this->notificationForCommentOnPostForNewUsers,
			 "notificationForSubscriptionsForNewUsers" => $this->notificationForSubscriptionsForNewUsers,
			 "notificationForFollowsForNewUsers" => $this->notificationForFollowsForNewUsers,
			 /* /Notifications for new users */
			 /* Emails for new users */
			 "emailForCommentVoteForNewUsers" => $this->emailForCommentVoteForNewUsers,
			 "emailForFollowForNewUsers" => $this->emailForFollowForNewUsers,
			 "emailForPostRatingForNewUsers" => $this->emailForPostRatingForNewUsers,
			 "emailForApprovedCommentForNewUsers" => $this->emailForApprovedCommentForNewUsers,
			 "emailForMentionForNewUsers" => $this->emailForMentionForNewUsers,
			 "emailForReplyForNewUsers" => $this->emailForReplyForNewUsers,
			 "emailForCommentOnPostForNewUsers" => $this->emailForCommentOnPostForNewUsers,
			 "emailForSubscriptionsForNewUsers" => $this->emailForSubscriptionsForNewUsers,
			 "emailForFollowsForNewUsers" => $this->emailForFollowsForNewUsers,
			 /* /Emails for new users */
			 /* Notification messages */
			 "commentUpvoteNotificationMessage" => $this->commentUpvoteNotificationMessage,
			 "commentDownvoteNotificationMessage" => $this->commentDownvoteNotificationMessage,
			 "followNotificationMessage" => $this->followNotificationMessage,
			 "postRatingNotificationMessage" => $this->postRatingNotificationMessage,
			 "approvedCommentNotificationMessage" => $this->approvedCommentNotificationMessage,
			 "mentionNotificationMessage" => $this->mentionNotificationMessage,
			 "replyNotificationMessage" => $this->replyNotificationMessage,
			 "commentOnPostNotificationMessage" => $this->commentOnPostNotificationMessage,
			 "subscriptionsNotificationMessage" => $this->subscriptionsNotificationMessage,
			 "followsNotificationMessage" => $this->followsNotificationMessage,
			 /* /Notification messages */
			 /* Multiple notifications messages */
			 "multipleCommentUpvoteNotificationsMessage" => $this->multipleCommentUpvoteNotificationsMessage,
			 "multipleCommentDownvoteNotificationsMessage" => $this->multipleCommentDownvoteNotificationsMessage,
			 "multipleFollowNotificationsMessage" => $this->multipleFollowNotificationsMessage,
			 "multiplePostRatingNotificationsMessage" => $this->multiplePostRatingNotificationsMessage,
			 "multipleApprovedCommentNotificationsMessage" => $this->multipleApprovedCommentNotificationsMessage,
			 "multipleMentionNotificationsMessage" => $this->multipleMentionNotificationsMessage,
			 "multipleReplyNotificationsMessage" => $this->multipleReplyNotificationsMessage,
			 "multipleCommentOnPostNotificationsMessage" => $this->multipleCommentOnPostNotificationsMessage,
			 "multipleSubscriptionsNotificationsMessage" => $this->multipleSubscriptionsNotificationsMessage,
			 "multipleFollowsNotificationsMessage" => $this->multipleFollowsNotificationsMessage,
			 /* /Multiple notifications messages */
			 /* Email messages */
			 "upvoteEmailSubject" => $this->upvoteEmailSubject,
			 "upvoteEmailMessage" => $this->upvoteEmailMessage,
			 "downvoteEmailSubject" => $this->downvoteEmailSubject,
			 "downvoteEmailMessage" => $this->downvoteEmailMessage,
			 "followEmailSubject" => $this->followEmailSubject,
			 "followEmailMessage" => $this->followEmailMessage,
			 "postRatingEmailSubject" => $this->postRatingEmailSubject,
			 "postRatingEmailMessage" => $this->postRatingEmailMessage,
			 "replyEmailSubject" => $this->replyEmailSubject,
			 "replyEmailMessage" => $this->replyEmailMessage,
			 "commentOnPostEmailSubject" => $this->commentOnPostEmailSubject,
			 "commentOnPostEmailMessage" => $this->commentOnPostEmailMessage,
			 /* /Email messages */
			 /* Common */
			 /* Activity */
			 "activityForCommentVote" => $this->activityForCommentVote,
			 "activityForPostRating" => $this->activityForPostRating,
			 /* /Activity */
			 /* Activity Texts */
			 "commentUpvoteActivityMessage" => $this->commentUpvoteActivityMessage,
			 "commentDownvoteActivityMessage" => $this->commentDownvoteActivityMessage,
			 "postRatingActivityMessage" => $this->postRatingActivityMessage,
			 /* /Activity Texts */
			 /* Profile Tabs */
			 "enableProfileCommentsTab" => $this->enableProfileCommentsTab,
			 "enableProfileSubscriptionsTab" => $this->enableProfileSubscriptionsTab,
			 "enableProfileReactionsTab" => $this->enableProfileReactionsTab,
			 "enableProfileRatesTab" => $this->enableProfileRatesTab,
			 "enableProfileVotesTab" => $this->enableProfileVotesTab,
			 "enableProfileFollowingTab" => $this->enableProfileFollowingTab,
			 "enableProfileFollowersTab" => $this->enableProfileFollowersTab,
			 "profileDiscussionsTabTitle" => $this->profileDiscussionsTabTitle,
			 "profileCommentsTabTitle" => $this->profileCommentsTabTitle,
			 "profileSubscriptionsTabTitle" => $this->profileSubscriptionsTabTitle,
			 "profileReactionsTabTitle" => $this->profileReactionsTabTitle,
			 "profileRatesTabTitle" => $this->profileRatesTabTitle,
			 "profileVotesTabTitle" => $this->profileVotesTabTitle,
			 "profileFollowingTabTitle" => $this->profileFollowingTabTitle,
			 "profileFollowersTabTitle" => $this->profileFollowersTabTitle,
			 /* /Profile Tabs */
			 /* Common */
			 "changeUserSettingsButton" => $this->changeUserSettingsButton,
			 "guestPhrase" => $this->guestPhrase,
			 "notificationSettingsTabTitle" => $this->notificationSettingsTabTitle,
			 /* /Common */
		 ];
	 }

	 public function settingsArray($settings) {
		 $settings["addons"][$this->tabKey] = [
			 "title" => __("BuddyPress Integration", "wpdiscuz-buddypress-integration"),
			 "title_original" => "BuddyPress Integration",
			 "icon" => "",
			 "icon-height" => "",
			 "file_path" => WPD_BPI_PATH . "/options/html-options.php",
			 "values" => $this,
			 "options" => [
				 "enabledNotifications" => [
					 "label" => __("Enabled Notifications", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Enabled Notifications",
					 "description" => __("There are many types of user notifications coming from the comment section. Here you can manage them for all users. Users can set their own notifications preferences in the Notifications &gt; Settings Tab.", "wpdiscuz-buddypress-integration"),
					 "description_original" => "There are many types of user notifications coming from the comment section. Here you can manage them for all users. Users can set their own notifications preferences in the Notifications &gt; Settings Tab.",
					 "docurl" => "#"
				 ],
				 "enabledEmailNotifications" => [
					 "label" => __("Enabled Email Notifications", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Enabled Email Notifications",
					 "description" => __("All kind of notifications can be sent via email as well. It depends on the email notification preferences. You can either disable certain email notification for all users or enable them for all letting them manage their email notifications by their own.", "wpdiscuz-buddypress-integration"),
					 "description_original" => "All kind of notifications can be sent via email as well. It depends on the email notification preferences. You can either disable certain email notification for all users or enable them for all letting them manage their email notifications by their own.",
					 "docurl" => "#"
				 ],
				 "defaultNotifications" => [
					 "label" => __("Default Notifications for New Users", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Default Notifications for New Users",
					 "description" => __("This is the notifications preferences set by default for users who have not managed his/her notifications yet.", "wpdiscuz-buddypress-integration"),
					 "description_original" => "This is the notifications preferences set by default for users who have not managed his/her notifications yet.",
					 "docurl" => "#"
				 ],
				 "defaultEmailNotifications" => [
					 "label" => __("Default Email Notifications for New Users", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Default Email Notifications for New Users",
					 "description" => __("This is the email notifications preferences set by default for users who have not managed his/her notifications yet.", "wpdiscuz-buddypress-integration"),
					 "description_original" => "This is the email notifications preferences set by default for users who have not managed his/her notifications yet.",
					 "docurl" => "#"
				 ],
				 "commentUpvoteNotificationMessage" => [
					 "label" => __("Notification - comment upvote", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Notification - new comment upvote",
					 "description" => "",
					 "description_original" => "",
					 "docurl" => "#"
				 ],
				 "commentDownvoteNotificationMessage" => [
					 "label" => __("Notification - comment downvote", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Notification - new comment downvote",
					 "description" => "",
					 "description_original" => "",
					 "docurl" => "#"
				 ],
				 "followNotificationMessage" => [
					 "label" => __("Notification - new follower", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Notification - new follower",
					 "description" => "",
					 "description_original" => "",
					 "docurl" => "#"
				 ],
				 "postRatingNotificationMessage" => [
					 "label" => __("Notification - new post rating", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Notification - new post rating",
					 "description" => "",
					 "description_original" => "",
					 "docurl" => "#"
				 ],
				 "approvedCommentNotificationMessage" => [
					 "label" => __("Notification - comment is approved", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Notification - comment is approved",
					 "description" => "",
					 "description_original" => "",
					 "docurl" => "#"
				 ],
				 "mentionNotificationMessage" => [
					 "label" => __("Notification - you've been mentioned", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Notification - you've been mentioned",
					 "description" => "",
					 "description_original" => "",
					 "docurl" => "#"
				 ],
				 "replyNotificationMessage" => [
					 "label" => __("Notification - new reply", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Notification - new reply",
					 "description" => "",
					 "description_original" => "",
					 "docurl" => "#"
				 ],
				 "commentOnPostNotificationMessage" => [
					 "label" => __("Notification - new comment (post author)", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Notification - new comment (post author)",
					 "description" => "",
					 "description_original" => "",
					 "docurl" => "#"
				 ],
				 "subscriptionsNotificationMessage" => [
					 "label" => __("Notification - new comment (subscriber)", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Notification - new comment (subscriber)",
					 "description" => "",
					 "description_original" => "",
					 "docurl" => "#"
				 ],
				 "followsNotificationMessage" => [
					 "label" => __("Notification - new comment (by user you follow)", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Notification - new comment (by user you follow)",
					 "description" => "",
					 "description_original" => "",
					 "docurl" => "#"
				 ],
				 "multipleCommentUpvoteNotificationsMessage" => [
					 "label" => __("Notification - comment upvotes (grouped)", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Notification - comment upvotes (grouped)",
					 "description" => "",
					 "description_original" => "",
					 "docurl" => "#"
				 ],
				 "multipleCommentDownvoteNotificationsMessage" => [
					 "label" => __("Notification - comment downvotes (grouped)", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Notification - comment downvotes (grouped)",
					 "description" => "",
					 "description_original" => "",
					 "docurl" => "#"
				 ],
				 "multipleFollowNotificationsMessage" => [
					 "label" => __("Notification - new followers (grouped)", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Notification - new followers (grouped)",
					 "description" => "",
					 "description_original" => "",
					 "docurl" => "#"
				 ],
				 "multiplePostRatingNotificationsMessage" => [
					 "label" => __("Notification - new post ratings (grouped)", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Notification - new post ratings (grouped)",
					 "description" => "",
					 "description_original" => "",
					 "docurl" => "#"
				 ],
				 "multipleApprovedCommentNotificationsMessage" => [
					 "label" => __("Notification - comments are approved (grouped)", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Notification - comments are approved (grouped)",
					 "description" => "",
					 "description_original" => "",
					 "docurl" => "#"
				 ],
				 "multipleMentionNotificationsMessage" => [
					 "label" => __("Notification - you've been mentioned (grouped)", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Notification - you've been mentioned (grouped)",
					 "description" => "",
					 "description_original" => "",
					 "docurl" => "#"
				 ],
				 "multipleReplyNotificationsMessage" => [
					 "label" => __("Notification - new replies (grouped)", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Notification - new replies (grouped)",
					 "description" => "",
					 "description_original" => "",
					 "docurl" => "#"
				 ],
				 "multipleCommentOnPostNotificationsMessage" => [
					 "label" => __("Notification - new comments (post author) (grouped)", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Notification - new comments (post author) (grouped)",
					 "description" => "",
					 "description_original" => "",
					 "docurl" => "#"
				 ],
				 "multipleSubscriptionsNotificationsMessage" => [
					 "label" => __("Notification - new comments (subscriber) (grouped)", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Notification - new comments (subscriber) (grouped)",
					 "description" => "",
					 "description_original" => "",
					 "docurl" => "#"
				 ],
				 "multipleFollowsNotificationsMessage" => [
					 "label" => __("Notification - new comments (by users you follow) (grouped)", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Notification - new comments (by users you follow) (grouped)",
					 "description" => "",
					 "description_original" => "",
					 "docurl" => "#"
				 ],
				 "upvoteEmailSubject" => [
					 "label" => __("Email Subject for Upvote", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Email Subject for Upvote",
					 "description" => "",
					 "description_original" => "",
					 "docurl" => "#"
				 ],
				 "upvoteEmailMessage" => [
					 "label" => __("Email Message for Upvote", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Email Message for Upvote",
					 "description" => "",
					 "description_original" => "",
					 "docurl" => "#"
				 ],
				 "downvoteEmailSubject" => [
					 "label" => __("Email Subject for Downvote", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Email Subject for Downvote",
					 "description" => "",
					 "description_original" => "",
					 "docurl" => "#"
				 ],
				 "downvoteEmailMessage" => [
					 "label" => __("Email Message for Downvote", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Email Message for Downvote",
					 "description" => "",
					 "description_original" => "",
					 "docurl" => "#"
				 ],
				 "followEmailSubject" => [
					 "label" => __("Email Subject for Follow", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Email Subject for Downvote",
					 "description" => "",
					 "description_original" => "",
					 "docurl" => "#"
				 ],
				 "followEmailMessage" => [
					 "label" => __("Email Message for Follow", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Email Message for Downvote",
					 "description" => "",
					 "description_original" => "",
					 "docurl" => "#"
				 ],
				 "postRatingEmailSubject" => [
					 "label" => __("Email Subject for Post Rating", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Email Subject for Post Rating",
					 "description" => "",
					 "description_original" => "",
					 "docurl" => "#"
				 ],
				 "postRatingEmailMessage" => [
					 "label" => __("Email Message for Post Rating", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Email Message for Post Rating",
					 "description" => "",
					 "description_original" => "",
					 "docurl" => "#"
				 ],
				 "replyEmailSubject" => [
					 "label" => __("Email Subject for Reply", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Email Subject for Reply",
					 "description" => "",
					 "description_original" => "",
					 "docurl" => "#"
				 ],
				 "replyEmailMessage" => [
					 "label" => __("Email Message for Reply", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Email Message for Reply",
					 "description" => "",
					 "description_original" => "",
					 "docurl" => "#"
				 ],
				 "commentOnPostEmailSubject" => [
					 "label" => __("Email Subject for Comment on Post", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Email Subject for Comment on Post",
					 "description" => "",
					 "description_original" => "",
					 "docurl" => "#"
				 ],
				 "commentOnPostEmailMessage" => [
					 "label" => __("Email Message for Comment on Post", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Email Message for Comment on Post",
					 "description" => "",
					 "description_original" => "",
					 "docurl" => "#"
				 ],
				 "enabledActivities" => [
					 "label" => __("Integrated Activities", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Integrated Activities",
					 "description" => __("Comment section activities generate activity entries in the BuddyPress Activity page. Here you can enable or disable activities coming from the comment section.", "wpdiscuz-buddypress-integration"),
					 "description_original" => "Comment section activities generate activity entries in the BuddyPress Activity page. Here you can enable or disable activities coming from the comment section.",
					 "docurl" => "#"
				 ],
				 "commentUpvoteActivityMessage" => [
					 "label" => __("Activity Text for Comment Upvote", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Activity Text for Upvote",
					 "description" => "",
					 "description_original" => "",
					 "docurl" => "#"
				 ],
				 "commentDownvoteActivityMessage" => [
					 "label" => __("Activity Text for Comment Downvote", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Activity Text for Downvote",
					 "description" => "",
					 "description_original" => "",
					 "docurl" => "#"
				 ],
				 "postRatingActivityMessage" => [
					 "label" => __("Activity Text for Post Rating", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Activity Text for Post Rating",
					 "description" => "",
					 "description_original" => "",
					 "docurl" => "#"
				 ],
				 "enabledProfileTabs" => [
					 "label" => __("Enabled Profile Tabs", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Enabled Profile Tabs",
					 "description" => __("BuddyPress Integration addon adds Discussions Tab in the user profile page. All these tabs (Comments, Subscriptions, Reactions... ) become sub-tabs of the main Discussions Tab.", "wpdiscuz-buddypress-integration"),
					 "description_original" => "BuddyPress Integration addon adds Discussions Tab in the user profile page. All these tabs (Comments, Subscriptions, Reactions... ) become sub-tabs of the main Discussions Tab.",
					 "docurl" => "#"
				 ],
				 "profileDiscussionsTabTitle" => [
					 "label" => __("Discussions Tab Name", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Discussions Tab Name",
					 "description" => "",
					 "description_original" => "",
					 "docurl" => "#"
				 ],
				 "profileCommentsTabTitle" => [
					 "label" => __("Comments Tab Name", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Comments Tab Name",
					 "description" => "",
					 "description_original" => "",
					 "docurl" => "#"
				 ],
				 "profileSubscriptionsTabTitle" => [
					 "label" => __("Subscriptions Tab Name", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Subscriptions Tab Name",
					 "description" => "",
					 "description_original" => "",
					 "docurl" => "#"
				 ],
				 "profileReactionsTabTitle" => [
					 "label" => __("Reactions Tab Name", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Reactions Tab Name",
					 "description" => "",
					 "description_original" => "",
					 "docurl" => "#"
				 ],
				 "profileRatesTabTitle" => [
					 "label" => __("Rates Tab Name", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Rates Tab Name",
					 "description" => "",
					 "description_original" => "",
					 "docurl" => "#"
				 ],
				 "profileVotesTabTitle" => [
					 "label" => __("Votes Tab Name", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Votes Tab Name",
					 "description" => "",
					 "description_original" => "",
					 "docurl" => "#"
				 ],
				 "profileFollowingTabTitle" => [
					 "label" => __("Following Tab Name", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Following Tab Name",
					 "description" => "",
					 "description_original" => "",
					 "docurl" => "#"
				 ],
				 "profileFollowersTabTitle" => [
					 "label" => __("Followers Tab Name", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Followers Tab Name",
					 "description" => "",
					 "description_original" => "",
					 "docurl" => "#"
				 ],
				 "changeUserSettingsButton" => [
					 "label" => __('Link "My Content and Settings" Button to Profile Discussions Tab.', "wpdiscuz-buddypress-integration"),
					 "label_original" => 'Link "My Content and Settings" Button to Profile Discussions Tab.',
					 "description" => __('The "My Content & Settings" button opens a pop-up window allowing users to manage their comments, subscriptions and more... Because of the BuddyPress Integration addon creates Discussions Tab with the same sub-tabs in the users\' profile page, it\'s recommended to link this button to the Discussions Tab.', "wpdiscuz-buddypress-integration"),
					 "description_original" => 'The "My Content & Settings" button opens a pop-up window allowing users to manage their comments, subscriptions and more... Because of the BuddyPress Integration addon creates Discussions Tab with the same sub-tabs in the users\' profile page, it\'s recommended to link this button to the Discussions Tab.',
					 "docurl" => "#"
				 ],
				 "guestPhrase" => [
					 "label" => __("Guest", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Guest",
					 "description" => "",
					 "description_original" => "",
					 "docurl" => "#"
				 ],
				 "notificationSettingsTabTitle" => [
					 "label" => __("Notification Settings Tab Name", "wpdiscuz-buddypress-integration"),
					 "label_original" => "Notification Settings Tab Name",
					 "description" => __("This addon integrates wpDiscuz with BuddyPress Notification system. All actions in the comment section generate corresponding notifications in users Notifications Tab. The Settings Sub-tab allows users to turn on/off certain notification.", "wpdiscuz-buddypress-integration"),
					 "description_original" => "This addon integrates wpDiscuz with BuddyPress Notification system. All actions in the comment section generate corresponding notifications in users Notifications Tab. The Settings Sub-tab allows users to turn on/off certain notification.",
					 "docurl" => "#"
				 ],
			 ],
		 ];
		 return $settings;
	 }

	 public function isProfileTabsEnabled() {
		 return $this->enableProfileCommentsTab || $this->enableProfileSubscriptionsTab || $this->enableProfileReactionsTab || $this->enableProfileRatesTab || $this->enableProfileVotesTab || $this->enableProfileFollowingTab || $this->enableProfileFollowersTab;
	 }

 }