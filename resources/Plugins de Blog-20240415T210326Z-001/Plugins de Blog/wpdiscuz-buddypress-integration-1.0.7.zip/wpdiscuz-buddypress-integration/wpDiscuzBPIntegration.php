<?php
/*
 * Plugin Name: wpDiscuz - BuddyPress Integration
 * Description: Fully integrates wpDiscuz with BuddyPress plugin. Includes notifications, activities, profile tabs, etc..
 * Version: 1.0.7
 * Author: gVectors Team
 * Author URI: https://www.gvectors.com/
 * Plugin URI: https://www.gvectors.com/wpdiscuz-buddypress-integration/
 * Text Domain: wpdiscuz-buddypress-integration
 * Domain Path: /languages/
 */
if (!defined("ABSPATH")) {
	exit();
}

define("WPD_BPI_PATH", __DIR__);
define("WPD_BPI_DIR_NAME", basename(WPD_BPI_PATH));

include_once WPD_BPI_PATH . "/includes/gvt-api-manager.php";
include WPD_BPI_PATH . "/includes/wpDiscuzBPIConstants.php";
include WPD_BPI_PATH . "/options/wpDiscuzBPIOptions.php";
include WPD_BPI_PATH . "/includes/wpDiscuzBPIDBManager.php";
include WPD_BPI_PATH . "/includes/wpDiscuzBPINotifications.php";
include WPD_BPI_PATH . "/includes/wpDiscuzBPIActivity.php";
include WPD_BPI_PATH . "/includes/wpDiscuzBPIProfileTabs.php";

class wpDiscuzBPIntegration implements wpDiscuzBPIConstants {

	private static $instance;
	private $version;
	private $options;
	public $apimanager;

	private function __construct() {
		add_action("plugins_loaded", [&$this, "pluginsLoaded"], 999);
	}

	public static function getInstance() {
		if (is_null(self::$instance)) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public function pluginsLoaded() {
		if (function_exists("wpDiscuz") && function_exists("buddypress")) {
			$this->version = get_option(self::OPTION_VERSION, "1.0.0");
			$this->apimanager = new GVT_API_Manager(__FILE__, "wpdiscuz_options_page", "wpdiscuz_option_page");
			load_plugin_textdomain("wpdiscuz-buddypress-integration", false, dirname(plugin_basename(__FILE__)) . "/languages/");
			$this->options = new wpDiscuzBPIOptions();
			$dbmanager = new wpDiscuzBPIDBManager();
			if (bp_is_active("notifications")) {
				new wpDiscuzBPINotifications($this->options, $dbmanager);
			}
			if (bp_is_active("activity")) {
				new wpDiscuzBPIActivity($this->options, $dbmanager);
			}
			if ($this->options->isProfileTabsEnabled()) {
				new wpDiscuzBPIProfileTabs($this->options, $dbmanager);
			}
			add_action("admin_init", [&$this, "pluginNewVersion"], 999);
			add_filter("wpdiscuz_user_settings_button", [&$this, "changeUserSettingsButton"], 999, 2);
		} else {
			add_action("admin_notices", [&$this, "requirements"], 999);
		}
	}

	public function requirements() {
		if (current_user_can("manage_options")) {
			echo "<div class='error'><p>" . __("wpDiscuz - BuddyPress Integration requires wpDiscuz and BuddyPress to be installed!", "wpdiscuz-buddypress-integration") . "</p></div>";
		}
	}

	public function pluginNewVersion() {
		$pluginData = get_plugin_data(__FILE__);
		if (version_compare($pluginData["Version"], $this->version, ">")) {
			update_option(self::OPTION_VERSION, $pluginData["Version"]);
		} else {
			add_option(self::OPTION_VERSION, "1.0.0", "", "no");
			if (get_option("wpdiscuz_bpi_update_wpdiscuz_options", "1")) {
				$wpdOptions = get_option(WpdiscuzCore::OPTION_SLUG_OPTIONS, []);
				$wpdOptions[WpdiscuzCore::TAB_LOGIN]["enableProfileURLs"] = 1;
				$wpdOptions[WpdiscuzCore::TAB_LOGIN]["showLoggedInUsername"] = 1;
				$wpdOptions[WpdiscuzCore::TAB_LOGIN]["showLoginLinkForGuests"] = 1;
				$wpdOptions[WpdiscuzCore::TAB_LOGIN]["websiteAsProfileUrl"] = 0;
				update_option(WpdiscuzCore::OPTION_SLUG_OPTIONS, $wpdOptions);
				update_option("wpdiscuz_bpi_update_wpdiscuz_options", 0);
			}
		}
	}

	public function changeUserSettingsButton($html, $currentUser) {
		if (!empty($currentUser->ID) && $this->options->changeUserSettingsButton) {
			return "<a href='" . trailingslashit(bp_core_get_user_domain($currentUser->ID) . "discussions") . "'>" . str_replace(" wpd-info", "", $html) . "</a>";
		}
		return $html;
	}

}

$wpDiscuzBPIntegration = wpDiscuzBPIntegration::getInstance();