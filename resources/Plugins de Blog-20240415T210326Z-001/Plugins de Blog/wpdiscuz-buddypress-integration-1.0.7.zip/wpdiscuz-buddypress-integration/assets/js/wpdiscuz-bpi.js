/* global jQuery */
/* global wpDiscuzBPIObj */
jQuery(document).ready(function ($) {
    $(document).on('click', '.wpdiscuz-bpi-delete', function (e) {
        e.preventDefault();
        var id = parseInt($(this).parents('.wpdiscuz-bpi-item[data-wpd-bpi-delete-id]').data('wpd-bpi-delete-id'));
        if (id && confirm(wpDiscuzBPIObj.confirmDelete)) {
            var data = new FormData();
            data.append('action', "wpdBPIDelete");
            data.append('id', id);
            $.ajax({
                type: 'POST',
                url: wpDiscuzBPIObj.url,
                data: data,
                contentType: false,
                processData: false
            }).done(function (r) {
                if (typeof r === 'object') {
                    if (r.success) {
                        location.reload(true);
                    } else {
                        console.log(r);
                    }
                } else {
                    console.log(r);
                }
            }).fail(function(jqXHR, textStatus, errorThrown) {
                console.log(errorThrown);
            });
        }
    });
    $(document).on('click', '.wpdiscuz-bpi-unsubscribe', function (e) {
        e.preventDefault();
        var id = parseInt($(this).parents('.wpdiscuz-bpi-item[data-wpd-bpi-subscription-id]').data('wpd-bpi-subscription-id'));
        if (id && confirm(wpDiscuzBPIObj.confirmUnsubscribe)) {
            var data = new FormData();
            data.append('action', "wpdBPIUnsubscribe");
            data.append('id', id);
            $.ajax({
                type: 'POST',
                url: wpDiscuzBPIObj.url,
                data: data,
                contentType: false,
                processData: false
            }).done(function (r) {
                if (typeof r === 'object') {
                    if (r.success) {
                        location.reload(true);
                    } else {
                        console.log(r);
                    }
                } else {
                    console.log(r);
                }
            }).fail(function(jqXHR, textStatus, errorThrown) {
                console.log(errorThrown);
            });
        }
    });
    $(document).on('click', '.wpdiscuz-bpi-unfollow', function (e) {
        e.preventDefault();
        var id = parseInt($(this).parents('.wpdiscuz-bpi-item[data-wpd-bpi-follow-id]').data('wpd-bpi-follow-id'));
        if (id && confirm(wpDiscuzBPIObj.confirmUnfollow)) {
            var data = new FormData();
            data.append('action', "wpdBPIUnfollow");
            data.append('id', id);
            $.ajax({
                type: 'POST',
                url: wpDiscuzBPIObj.url,
                data: data,
                contentType: false,
                processData: false
            }).done(function (r) {
                if (typeof r === 'object') {
                    if (r.success) {
                        location.reload(true);
                    } else {
                        console.log(r);
                    }
                } else {
                    console.log(r);
                }
            }).fail(function(jqXHR, textStatus, errorThrown) {
                console.log(errorThrown);
            });
        }
    });
});