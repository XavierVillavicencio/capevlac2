/* global jQuery */
/* global ajaxurl */
jQuery(document).ready(function ($) {
    var doingAjax = false;
    /* Comments */
    $(function () {
        $(".import-comments-to-activity-start-date").datepicker({
            dateFormat: 'yy-mm-dd',
            changeMonth: true,
            changeYear: true,
            numberOfMonths: 1,
            onClose: function (selectedDate) {
                $(".wam-ad-end").datepicker("option", "minDate", selectedDate);
            }
        });
        $(".import-comments-to-activity-end-date").datepicker({
            dateFormat: 'yy-mm-dd',
            changeMonth: true,
            changeYear: true,
            numberOfMonths: 1,
            onClose: function (selectedDate) {
                $(".wam-ad-start").datepicker("option", "maxDate", selectedDate);
            }
        });
    });
    $('.import-comments-to-activity-step').val(0);
    $(document).on('click', '.import-comments-to-activity', function (e) {
        e.preventDefault();
        if ($('.import-comments-to-activity-start-id').val() >= 0 && parseInt($('.import-comments-to-activity-limit').val()) > 0) {
            var btn = $(this);
            btn.prop('disabled', true);
            $('.fas', btn).addClass('fa-pulse fa-spinner').removeClass('wc-hidden');
            checkCommentsCount(btn);
        }

    });
    function checkCommentsCount(btn) {
        doingAjax = true;
        var data = btn.parents('.wc-form').serialize();
        $.ajax({
            type: 'POST',
            url: ajaxurl,
            data: {importComments: data, action: 'wpdBPICheckCommentsCount'}
        }).done(function (response) {
            try {
                var resp = JSON.parse(response);
                $('.import-comments-to-activity-count').val(resp.count);
                if (resp.count) {
                    importComments(btn);
                } else {
                    $('.import-comments-to-activity-progress').css({'color': '#10b493'});
                    $('.import-comments-to-activity-progress').text('100% Done');
                    setTimeout(function () {
                        location.reload(true);
                    }, 2000);
                }
            } catch (e) {
                console.log(e);
            }
        }).fail(function (jqXHR, textStatus, errorThrown) {
            console.log(errorThrown);
        });
    }
    function importComments(btn) {
        doingAjax = true;
        var data = btn.parents('.wc-form').serialize();
        $.ajax({
            type: 'POST',
            url: ajaxurl,
            data: {importComments: data, action: 'wpdBPIImportComments'}
        }).done(function (response) {
            try {
                var resp = JSON.parse(response);
                $('.import-comments-to-activity-step').val(resp.step);
                $('.import-comments-to-activity-start-id').val(resp.startId);
                if (resp.progress < 100) {
                    importComments(btn);
                } else {
                    $('.fas', btn).removeClass('fa-pulse fa-spinner').addClass('wc-hidden');
                }
                if (resp.progress <= 1) {
                    $('.import-comments-to-activity-progress').text(1 + '%');
                } else {
                    if (resp.progress < 100) {
                        $('.import-comments-to-activity-progress').text(resp.progress + '%');
                    } else {
                        $('.import-comments-to-activity-progress').css({'color': '#10b493'});
                        $('.import-comments-to-activity-progress').text(resp.progress + '% Done');
                        $('.import-comments-to-activity-count').val(0);
                        $('.import-comments-to-activity-step').val(0);
                        $('.import-comments-to-activity-start-id').val(0);
                        doingAjax = false;
                        setTimeout(function () {
                            location.reload(true);
                        }, 2000);
                    }
                }
            } catch (e) {
                console.log(e);
            }
        }).fail(function (jqXHR, textStatus, errorThrown) {
            console.log(errorThrown);
        });
    }
    /* /Comments */

    /* Votes */
    $(function () {
        $(".import-votes-to-activity-start-date").datepicker({
            dateFormat: 'yy-mm-dd',
            changeMonth: true,
            changeYear: true,
            numberOfMonths: 1,
            onClose: function (selectedDate) {
                $(".wam-ad-end").datepicker("option", "minDate", selectedDate);
            }
        });
        $(".import-votes-to-activity-end-date").datepicker({
            dateFormat: 'yy-mm-dd',
            changeMonth: true,
            changeYear: true,
            numberOfMonths: 1,
            onClose: function (selectedDate) {
                $(".wam-ad-start").datepicker("option", "maxDate", selectedDate);
            }
        });
    });
    $('.import-votes-to-activity-step').val(0);
    $(document).on('click', '.import-votes-to-activity', function (e) {
        e.preventDefault();
        if ($('.import-votes-to-activity-start-id').val() >= 0 && parseInt($('.import-votes-to-activity-limit').val()) > 0) {
            var btn = $(this);
            btn.prop('disabled', true);
            $('.fas', btn).addClass('fa-pulse fa-spinner').removeClass('wc-hidden');
            checkCommentsVotesCount(btn);
        }

    });
    function checkCommentsVotesCount(btn) {
        doingAjax = true;
        var data = btn.parents('.wc-form').serialize();
        $.ajax({
            type: 'POST',
            url: ajaxurl,
            data: {importCommentVotes: data, action: 'wpdBPICheckCommentsVotesCount'}
        }).done(function (response) {
            try {
                var resp = JSON.parse(response);
                $('.import-votes-to-activity-count').val(resp.count);
                if (resp.count) {
                    importCommentVotes(btn);
                } else {
                    $('.import-votes-to-activity-progress').css({'color': '#10b493'});
                    $('.import-votes-to-activity-progress').text('100% Done');
                    setTimeout(function () {
                        location.reload(true);
                    }, 2000);
                }
            } catch (e) {
                console.log(e);
            }
        }).fail(function (jqXHR, textStatus, errorThrown) {
            console.log(errorThrown);
        });
    }
    function importCommentVotes(btn) {
        doingAjax = true;
        var data = btn.parents('.wc-form').serialize();
        $.ajax({
            type: 'POST',
            url: ajaxurl,
            data: {importCommentVotes: data, action: 'wpdBPIImportCommentVotes'}
        }).done(function (response) {
            try {
                var resp = JSON.parse(response);
                $('.import-votes-to-activity-step').val(resp.step);
                $('.import-votes-to-activity-start-id').val(resp.startId);
                if (resp.progress < 100) {
                    importCommentVotes(btn);
                } else {
                    $('.fas', btn).removeClass('fa-pulse fa-spinner').addClass('wc-hidden');
                }
                if (resp.progress <= 1) {
                    $('.import-votes-to-activity-progress').text(1 + '%');
                } else {
                    if (resp.progress < 100) {
                        $('.import-votes-to-activity-progress').text(resp.progress + '%');
                    } else {
                        $('.import-votes-to-activity-progress').css({'color': '#10b493'});
                        $('.import-votes-to-activity-progress').text(resp.progress + '% Done');
                        $('.import-votes-to-activity-count').val(0);
                        $('.import-votes-to-activity-step').val(0);
                        $('.import-votes-to-activity-start-id').val(0);
                        doingAjax = false;
                        setTimeout(function () {
                            location.reload(true);
                        }, 2000);
                    }
                }
            } catch (e) {
                console.log(e);
            }
        }).fail(function (jqXHR, textStatus, errorThrown) {
            console.log(errorThrown);
        });
    }
    /* /Votes */

    /* Ratings */
    $(function () {
        $(".import-ratings-to-activity-start-date").datepicker({
            dateFormat: 'yy-mm-dd',
            changeMonth: true,
            changeYear: true,
            numberOfMonths: 1,
            onClose: function (selectedDate) {
                $(".wam-ad-end").datepicker("option", "minDate", selectedDate);
            }
        });
        $(".import-ratings-to-activity-end-date").datepicker({
            dateFormat: 'yy-mm-dd',
            changeMonth: true,
            changeYear: true,
            numberOfMonths: 1,
            onClose: function (selectedDate) {
                $(".wam-ad-start").datepicker("option", "maxDate", selectedDate);
            }
        });
    });
    $('.import-ratings-to-activity-step').val(0);
    $(document).on('click', '.import-ratings-to-activity', function (e) {
        e.preventDefault();
        if ($('.import-ratings-to-activity-start-id').val() >= 0 && parseInt($('.import-ratings-to-activity-limit').val()) > 0) {
            var btn = $(this);
            btn.prop('disabled', true);
            $('.fas', btn).addClass('fa-pulse fa-spinner').removeClass('wc-hidden');
            checkRatingsCount(btn);
        }

    });
    function checkRatingsCount(btn) {
        doingAjax = true;
        var data = btn.parents('.wc-form').serialize();
        $.ajax({
            type: 'POST',
            url: ajaxurl,
            data: {importPostRatings: data, action: 'wpdBPICheckPostRatingsCount'}
        }).done(function (response) {
            try {
                var resp = JSON.parse(response);
                $('.import-ratings-to-activity-count').val(resp.count);
                if (resp.count) {
                    importPostRatings(btn);
                } else {
                    $('.import-ratings-to-activity-progress').css({'color': '#10b493'});
                    $('.import-ratings-to-activity-progress').text('100% Done');
                    setTimeout(function () {
                        location.reload(true);
                    }, 2000);
                }
            } catch (e) {
                console.log(e);
            }
        }).fail(function (jqXHR, textStatus, errorThrown) {
            console.log(errorThrown);
        });
    }
    function importPostRatings(btn) {
        doingAjax = true;
        var data = btn.parents('.wc-form').serialize();
        $.ajax({
            type: 'POST',
            url: ajaxurl,
            data: {importPostRatings: data, action: 'wpdBPIImportPostRatings'}
        }).done(function (response) {
            try {
                var resp = JSON.parse(response);
                $('.import-ratings-to-activity-step').val(resp.step);
                $('.import-ratings-to-activity-start-id').val(resp.startId);
                if (resp.progress < 100) {
                    importPostRatings(btn);
                } else {
                    $('.fas', btn).removeClass('fa-pulse fa-spinner').addClass('wc-hidden');
                }
                if (resp.progress <= 1) {
                    $('.import-ratings-to-activity-progress').text(1 + '%');
                } else {
                    if (resp.progress < 100) {
                        $('.import-ratings-to-activity-progress').text(resp.progress + '%');
                    } else {
                        $('.import-ratings-to-activity-progress').css({'color': '#10b493'});
                        $('.import-ratings-to-activity-progress').text(resp.progress + '% Done');
                        $('.import-ratings-to-activity-count').val(0);
                        $('.import-ratings-to-activity-step').val(0);
                        $('.import-ratings-to-activity-start-id').val(0);
                        doingAjax = false;
                        setTimeout(function () {
                            location.reload(true);
                        }, 2000);
                    }
                }
            } catch (e) {
                console.log(e);
            }
        }).fail(function (jqXHR, textStatus, errorThrown) {
            console.log(errorThrown);
        });
    }
    /* /Ratings */
    window.addEventListener('beforeunload', function (e) {
        if (doingAjax) {
            e.preventDefault();
            e.returnValue = '';
            return "You have attempted to leave this page while background task is running. Are you sure?";
        }
    });
});