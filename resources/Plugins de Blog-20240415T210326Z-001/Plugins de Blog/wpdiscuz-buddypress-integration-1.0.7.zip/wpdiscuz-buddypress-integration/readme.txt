=== wpDiscuz – BuddyPress Integration ===
Contributors: gVectors Team
Requires at least: 5.0
Tested up to: 6.2
Stable tag: 1.0.7
Requires PHP: 5.4 and higher
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

This is the most professional approach to integrate wpDiscuz comment system with
BuddyPress user profile builder plugin. It includes notifications, activities, 
profile tabs and more. All actions of the comment section will generate
 notifications in the users profile system. For example "new reply to my comment", 
"my comment is upvoted", "someone started following me", "my comment is approved", 
and more… Users will have lots of options to manage their subscriptions, 
"in-site" and email notifications. New comments and votes will be displayed in 
the BuddyPress activity stream. Users will have a new tab called Discussions in 
their profile page. This tab opens seven sub-tabs: Comments, Reactions, Rates, 
Subscriptions, Votes, Following, Followers. Each sub-tab contains complete 
information about the user activity in the comment section and lets him/her to 
manage them in the one place. In addition, it comes with a tool to import all 
previous comments and likes to the activity stream.