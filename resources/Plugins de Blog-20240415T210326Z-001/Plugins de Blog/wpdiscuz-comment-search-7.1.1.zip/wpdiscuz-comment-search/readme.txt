=== wpDiscuz - Comment Search ===
Contributors: gVectors Team
Requires at least: 5.0
Tested up to: 6.4
Stable tag: 7.1.1
Requires PHP: 5.4 and higher
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

A must addon for websites with large amount of comments. This is a perfect way to find comments
with AJAX powered search form. It starts searching while you’re typing search words. Works very 
smooth and displays search  result without reloading page. wpDiscuz Comment Search addon comes 
with three search modes: “comment text”, “comment author” and “comment author email”. So you can 
find all comments made by certain author name and email address. This addon has complete package 
of front-end customization options; colors, backgrounds, borders, phrases and more…