=== wpDiscuz - Media Uploader ===
Contributors: gVectors Team
Requires at least: 5.0
Tested up to: 6.0
Stable tag: 7.1.1
Requires PHP: 5.4 and higher
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Allows to upload photos, videos, audio and other type of files with comments. 
This addon brings the best comment file attachment experience ever. 
Separate buttons for all types of media and files. It works with Single and 
Multiple file uploading modes. Each part of user interface and user experience 
is fully configurable. Attached media files will be displayed with image 
lightbox, HTML5 video and audio players.