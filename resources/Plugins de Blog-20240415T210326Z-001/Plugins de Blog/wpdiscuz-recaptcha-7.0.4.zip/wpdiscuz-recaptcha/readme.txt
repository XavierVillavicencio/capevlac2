=== wpDiscuz - Google reCAPTCHA ===
Contributors: gVectors Team
Requires at least: 5.0
Tested up to: 6.2
Stable tag: 7.0.4
Requires PHP: 5.4 and higher
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Best protection for your comments with wpDiscuz Google reCAPTCHA addon!
The new (2.0) reCAPTCHA is great. A significant number of your users can 
now attest they are human without having to solve a CAPTCHA. Instead with 
just a single click they’ll confirm they are not a robot. People call it 
the No CAPTCHA reCAPTCHA experience.  This addon protects your website 
comments from spam and abuse while letting real people pass through with ease.