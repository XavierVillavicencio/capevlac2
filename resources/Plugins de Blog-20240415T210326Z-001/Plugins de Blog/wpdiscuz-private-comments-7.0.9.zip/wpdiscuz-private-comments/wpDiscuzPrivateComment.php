<?php
/*
 * Plugin Name: wpDiscuz - Private Comments
 * Description: An easy tool for letting users create private comment threads. These threads are only visible for website administrators, moderators and for the thread owner.
 * Version: 7.0.9
 * Author: gVectors Team
 * Plugin URI: https://gvectors.com/product/wpdiscuz-private-comment/
 * Author URI: https://gvectors.com/product/wpdiscuz-private-comment/
 * Text Domain: wpdiscuz_private_comment
 * Domain Path: /languages/
 */
define("WPC_DIR_PATH", dirname(__FILE__));

include_once WPC_DIR_PATH . "/includes/wpDiscuzPrivateCommentConst.php";
include_once WPC_DIR_PATH . "/includes/wpdPrivateCommentOptions.php";
include_once WPC_DIR_PATH . "/includes/wpdPrivateCommentDB.php";
include_once WPC_DIR_PATH . "/includes/gvt-api-manager.php";

class wpDiscuzPrivateComment implements wpDiscuzPrivateCommentConst {

    private $version;
    private static $instance;
    private $options;
    private $db;
    private $visibleCommentIDs;
    private $currentUser;
    private $isSupportPrivateComment;
	public $apimanager;

    private function __construct() {
        add_action("plugins_loaded", [&$this, "pluginLoad"], 129);
    }

    public function pluginLoad() {
        if (function_exists("wpDiscuz")) {
	        $this->apimanager = new GVT_API_Manager(__FILE__, "wpdiscuz_options_page", "wpdiscuz_option_page");
            $this->isSupportPrivateComment = false;
            $this->options = new wpdPrivatCommentOptions();
            $this->db = new wpdPrivateCommentDB($this->options);
            add_filter("comments_clauses", [&$this, "commentsClauses"], 10, 2);
            add_filter("get_comments_number", [&$this, "getCommentNumber"], 268, 2);
            add_filter("preprocess_comment", [&$this, "preprocessComment"], 1548);
            add_action("wp_insert_comment", [&$this, "commentInserted"], 99, 2);
            add_filter("get_comment", [&$this, "getComment"]);
            add_filter("comment_moderation_recipients", [&$this, "notificationRecipients"], 11, 2);
            add_filter("comment_notification_recipients", [&$this, "notificationRecipients"], 11, 2);
            add_filter("wpdiscuz_rf_exclude_comment_types", [&$this, "excludeCommentTypes"], 171);
            add_filter("wpdiscuz_email_notification", [&$this, "subscriptionsEmail"], 454, 3);
            add_filter("wpdiscuz_follow_email_notification", [&$this, "subscriptionsEmail"], 454, 3);
            add_action("wpdiscuz_before_submit_button_in_wrapper", [&$this, "addToolBar"], 500, 3);
            add_action("wpdiscuz_front_scripts", [&$this, "frontendScripts"]);
            add_filter("wpdiscuz_live_update_new_comment_ids", [&$this, "liveUpdateCommentIDs"], 545, 3);
            add_filter("wpdiscuz_bubble_new_comment_ids", [&$this, "liveUpdateCommentIDs"], 545, 3);
            add_filter("wpdiscuz_comment_buttons", [&$this, "commentButtons"], 5743, 4);
            add_filter("wpdiscuz_comment_type_icon", [&$this, "commentTypeIcon"], 5841, 2);
            add_filter("wpdiscuz_comment_wrap_classes", [&$this, "commentClasses"], 5942, 2);
            add_filter("wpdiscuz_get_form", [&$this, "isSupportPrivateComment"], 57);
            add_action("wp_ajax_wpdPrivateCommentChangeStatus", [&$this, "changeStatus"]);
            add_filter("admin_comment_types_dropdown", [&$this, "addCommentType"]);
            add_filter("comment_row_actions", [&$this, "commentRowPrivateAction"], 10, 2);
            add_filter("wpdiscuz_found_comments_query", [&$this, "wpdiscuzFoundCommentsQuery"], 5478, 2);
            add_action("admin_enqueue_scripts", [&$this, "adminScripts"], 100);
            load_plugin_textdomain("wpdiscuz_private_comment", false, dirname(plugin_basename(__FILE__)) . "/languages/");
            $this->initPluginVersion();
        } else {
            add_action("admin_notices", [&$this, "pcRequirements"], 1);
        }
    }

    public function pcRequirements() {
        if (current_user_can("manage_options")) {
            echo "<div class='error'><p>" . __("wpDiscuz - Private Comments requires wpDiscuz to be installed!", "wpdiscuz_private_comment") . "</p></div>";
        }
    }

    public function excludeCommentTypes($types) {
        $types[] = self::PRIVATE_CONTENT_TYPE;
        return $types;
    }

    public function getComment($comment) {
        $backtrace = wp_debug_backtrace_summary("wpDiscuzPrivateComment", 0, false);
        if ($comment->comment_type === self::PRIVATE_CONTENT_TYPE && !in_array("get_comments", $backtrace)) {
            $currentUser = $this->getCurrentUser();
            if ($currentUser->exists()) {
                if ($comment->user_id != $currentUser->ID && !$this->canModeratePrivateComment($currentUser, $comment->comment_post_ID)) {
                    $wpdiscuz = wpDiscuz();
                    $commentStatusIn = ["1"];
                    if ($wpdiscuz->commentsArgs["status"] === "all") {
                        $commentStatusIn[] = "0";
                    }
                    $rootComment = $wpdiscuz->helperOptimization->getCommentRoot($comment->comment_parent, $commentStatusIn);
                    if (!$rootComment || ($rootComment && $rootComment->user_id != $currentUser->ID)) {
                        $comment = NULL;
                    }
                }
            } else if (!$this->canModeratePrivateComment($currentUser, $comment->comment_post_ID)) {
                $comment = NULL;
            }
        }
        return $comment;
    }

    public function preprocessComment($commentdata) {
        $currentUser = $this->getCurrentUser();
        if ($this->currentUserCanAdd("can_add_private_comment", $currentUser)) {
            $parentID = $commentdata["comment_parent"];
            $commentType = filter_input(INPUT_POST, "wpdiscuz-is-private", FILTER_SANITIZE_NUMBER_INT);
            $parentComment = NULL;
            if ($parentID) {
                $parentComment = get_comment($parentID);
            }
            if ($commentType || ($parentComment && $parentComment->comment_type === self::PRIVATE_CONTENT_TYPE)) {
                $commentdata["comment_type"] = self::PRIVATE_CONTENT_TYPE;
            }
        }
        return $commentdata;
    }

    public function commentsClauses($args, $q) {
        $postID = null;
        if (!empty($q->query_vars["post_id"])) {
            $postID = $q->query_vars["post_id"];
        }
        $current_user = $this->getCurrentUser();
        global $wpdb;
        if ($current_user->exists()) {
            if ($this->canModeratePrivateComment($current_user, $postID)) {
                return $args;
            }
            if (!$this->visibleCommentIDs) {
                $this->visibleCommentIDs = $this->db->getPrivateCommentsByUserID($current_user->ID);
            }
            $privateCommentIDs = $this->visibleCommentIDs;
            $condition = "";
            if ($privateCommentIDs) {
                $privateCommentIDs = implode(",", $privateCommentIDs);
                $condition = " OR ({$wpdb->comments}.`comment_type` = '" . self::PRIVATE_CONTENT_TYPE . "' AND {$wpdb->comments}.`comment_ID` IN($privateCommentIDs))";
            }
            $args["where"] .= " AND (({$wpdb->comments}.`comment_type` != '" . self::PRIVATE_CONTENT_TYPE . "') OR ({$wpdb->comments}.`user_id` = {$current_user->ID} AND {$wpdb->comments}.`comment_type` = '" . self::PRIVATE_CONTENT_TYPE . "') $condition)";
        } else {
            $args["where"] .= " AND {$wpdb->comments}.`comment_type` != '" . self::PRIVATE_CONTENT_TYPE . "'";
        }
        return $args;
    }

    public function liveUpdateCommentIDs($newCommentIds, $postId, $currentUser) {
        if ($newCommentIds && $currentUser->exists() && !$this->canModeratePrivateComment($currentUser, $postId)) {
            $newCommentIds = get_comments([
                "comment__in" => $newCommentIds,
                "post__in" => $postId,
                "fields" => "ids"
            ]);
        }
        return $newCommentIds;
    }

    public function isSupportPrivateComment($form) {
        $options = $this->options->get();
        $this->isSupportPrivateComment = $form && in_array($form->getFormID(), $options["private_comment_forms"]);
        return $form;
    }

    public function addToolBar($currentUser, $uniqueId, $isMainForm) {
        if ($isMainForm) {
            $options = $this->options->get();
            if ($this->isSupportPrivateComment) {
                if ($uniqueId == "0_0" && $this->currentUserCanAdd("can_add_private_comment", $currentUser)) {
                    ?>
                    <label class="wpd_label" wpd-tooltip="<?php _e("Private Comment", "wpdiscuz_private_comment"); ?>">
                        <input id="wpdiscuz_private_comment_input" class="wpd_label__checkbox wpdiscuz-private-comment-input" value="1" type="checkbox" name="wpdiscuz-is-private" <?php echo isset($options["private_comment_set_private"]) && $options["private_comment_set_private"] ? "checked='checked'" : ""; ?>/>
                        <span class="wpd_label__text">
                            <span class="wpd_label__check">
                                <i class="fas fa-eye-slash wpdicon wpdicon-on"></i>
                                <i class="fas fa-eye wpdicon wpdicon-off"></i>
                            </span>
                        </span>
                    </label>
                    <?php
                }
            }
        }
    }

    private function currentUserCanAdd($key, $user) {
        if (!$user->exists()) {
            return false;
        }
        $options = $this->options->get();
        $roles = $user->roles;
        foreach ($roles as $role) {
            if (in_array($role, $options[$key])) {
                return true;
            }
        }
        return false;
    }

    private function canModeratePrivateComment($user, $post_id = null) {
        $options = $this->options->get();
        if ($options["post_author_can_moderate"]) {
            if (is_null($post_id)) {
                global $post;
                if (!empty($post->ID)) {
                    $post_id = $post->ID;
                }
            } else {
                $post = get_post($post_id);
            }
            if (!empty($post_id) && $user->ID == $post->post_author) {
                return true;
            }
        }
        $roles = $user->roles;
        foreach ($roles as $role) {
            if (in_array($role, $options["moderator_user_groups"])) {
                return true;
            }
        }
        return false;
    }

    public function commentInserted($commentId, $commentObject) {
        $options = $this->options->get();
        if ($commentObject->comment_type === self::PRIVATE_CONTENT_TYPE && $options["private_comment_notification_enabled"]) {
            $moderatorsRoles = $options["moderator_user_groups"];
            $moderators = get_users(["role__in" => $moderatorsRoles]);
            if ($options["post_author_can_moderate"]) {
                if ($postAuthorID = get_post_field("post_author", $commentObject->comment_post_ID)) {
                    if ($postAuthor = get_user_by("id", $postAuthorID)) {
                        $userExists = false;
                        foreach ($moderators as $k => $user) {
                            if ($user->ID == $postAuthor->ID) {
                                $userExists = true;
                                break;
                            }
                        }
                        if (!$userExists) {
                            $moderators[] = $postAuthor;
                        }
                    }
                }
            }
            if ($moderators) {
                foreach ($moderators as $moderator) {
                    if ($moderator->ID != $commentObject->user_id) {
                        $phraseMessage = $this->replaceMessageShortcode(__($options["private_comment_notification_message"], "wpdiscuz_private_comment"), $commentObject);
                        $message = "$phraseMessage<br/>==========================";
                        $message .= "<br/><br/>{$commentObject->comment_content}";
                        $headers = [];
                        $headers[] = "Content-Type: text/html; charset=UTF-8";
                        $headers[] = "From: " . get_option("blogname") . " <" . get_option("admin_email") . "> \r\n";
                        wp_mail($moderator->user_email, __($options["private_comment_notification_subject"], "wpdiscuz_private_comment"), $message, $headers);
                    }
                }
            }
        }
    }

    private function replaceMessageShortcode($message, $commentObject) {
        $commentPostID = $commentObject->comment_post_ID;
        $commentLink = get_comment_link($commentObject);
        $postTitle = "";
        $postURL = "";
        $commentPost = get_post($commentPostID);
        if ($commentPost) {
            $postTitle = $commentPost->post_title;
            $postURL = get_permalink($commentPostID);
        }
        return str_replace(["[post-title]", "[post-url]", "[comment-url]"], [$postTitle, $postURL, $commentLink], $message);
    }

    public function notificationRecipients($emails, $comment_id) {
        $comment = get_comment($comment_id);
        $filteredEmiles = [];
        if ($comment && $comment->comment_type === self::PRIVATE_CONTENT_TYPE) {
            foreach ($emails as $email) {
                $user = get_user_by("email", $email);
                if ($this->canModeratePrivateComment($user, $comment->comment_post_ID)) {
                    $filteredEmiles[] = $email;
                }
            }
            $emails = $filteredEmiles;
        }
        return $emails;
    }

    public function subscriptionsEmail($sendMail, $email_data, $comment) {
        if ($comment->comment_type === self::PRIVATE_CONTENT_TYPE) {
            $email = isset($email_data["email"]) ? $email_data["email"] : $email_data["follower_email"];
            $user = get_user_by("email", $email);
            if ($user && !$this->canModeratePrivateComment($user, $comment->comment_post_ID)) {
                $visibleCommentIDs = $this->db->getPrivateCommentsByUserID($user->ID, $comment->comment_post_ID);
                $sendMail = in_array($comment->comment_ID, $visibleCommentIDs);
            } else if (!$user) {
                $sendMail = false;
            }
        }
        return $sendMail;
    }

    public function getCommentNumber($count, $post_id) {
        $current_user = $this->getCurrentUser();
        if ($current_user->exists() && !$this->canModeratePrivateComment($current_user, $post_id)) {
            $publicCommentsCount = $this->db->getPublicCommentsCount($post_id);
            $privateCommentIDs = $this->db->getPrivateCommentsByUserID($current_user->ID, $post_id);
            if (is_singular()) {
                $this->visibleCommentIDs = $privateCommentIDs;
            }
            $privateCommentsCount = count($privateCommentIDs);
            $count = $publicCommentsCount + $privateCommentsCount;
        } elseif (!$current_user->exists()) {
            $count = $this->db->getPublicCommentsCount($post_id);
        }
        return $count;
    }

    public function commentButtons($output, $comment, $user, $currentUser) {
        if ($this->isSupportPrivateComment && $currentUser->exists() && !$comment->comment_parent && $comment->comment_type !== self::STICKY_CONTENT_TYPE) {
            $privateIconID = "wpdiscuz_private_comment_" . $comment->comment_ID;
            $statusClass = "";
            $title = __("Private", "wpdiscuz_private_comment");
            if ($this->canModeratePrivateComment($currentUser, $comment->comment_post_ID)) {
                if ($comment->comment_type === self::PRIVATE_CONTENT_TYPE) {
                    $statusClass = " hidden ";
                    $title = __("Public", "wpdiscuz_private_comment");
                }
                $output .= "<span class='wpdiscuz-private-comment-action wpd-cta-button" . $statusClass . "' id='" . $privateIconID . "'><span class='wc_private_text'>" . $title . "</span></span>";
            } else if ($comment->comment_type !== self::PRIVATE_CONTENT_TYPE && $currentUser->ID == $comment->user_id) {
                $output .= "<span class='wpdiscuz-private-comment-action wpd-cta-button' id='" . $privateIconID . "'><span class='wc_private_text'>" . $title . "</span></span>";
            }
        }
        return $output;
    }

    public function commentTypeIcon($output, $comment) {
        $wpdiscuz = wpDiscuz();
        if ($comment->comment_type === self::PRIVATE_CONTENT_TYPE) {
            $output .= "<i class='fas fa-eye-slash wpd-private' aria-hidden='true' title='" . __("Private comment thread", "wpdiscuz_private_comment") . "'></i>";
        }
        return $output;
    }

    public function commentClasses($classes, $comment) {
        $wpdiscuz = wpDiscuz();
        if ($comment->comment_type === self::PRIVATE_CONTENT_TYPE) {
            $classes[] = "wc-private-comment";
        }
        return $classes;
    }

    public function changeStatus() {
        $htmlID = filter_input(INPUT_POST, "html_id", FILTER_SANITIZE_STRING);
        $status = trim(filter_input(INPUT_POST, "status", FILTER_SANITIZE_STRING));
        $commentID = str_replace("wpdiscuz_private_comment_", "", $htmlID);
        $response = ["text" => __("permission denied", "wpdiscuz_private_comment"), "remove_button" => 1];
        if ($commentID) {
            $comment = get_comment($commentID);
            if ($comment && !$comment->comment_parent) {
                $wpdiscuz = wpDiscuz();
                $currentUser = $this->getCurrentUser();
                $canModeratePrivateComment = $this->canModeratePrivateComment($currentUser, $comment->comment_post_ID);
                if ($canModeratePrivateComment || ($status !== self::PRIVATE_CONTENT_TYPE && $currentUser->ID == $comment->user_id)) {
                    $commentsId = [$comment->comment_ID];
                    $wpdiscuz->helperOptimization->getTreeByParentId($comment->comment_ID, $commentsId);
                    $this->db->changeCommentsType($commentsId, $status);
                    $response["text"] = ($status === self::PRIVATE_CONTENT_TYPE) ? __("Private", "wpdiscuz_private_comment") : __("Public", "wpdiscuz_private_comment");
                    if ($canModeratePrivateComment) {
                        $response["remove_button"] = 0;
                    }
                    do_action("wpdiscuz_reset_comments_cache", $comment->comment_post_ID);
                    do_action("wpd_change_private_status",$commentsId,$status);
                    wp_send_json_success($response);
                }
            }
        }
        wp_send_json_error($response);
    }

    public function frontendScripts($options) {
        $suf = $options->general["loadMinVersion"] ? ".min" : "";
        wp_register_style("wpdiscuz-private-comment-css", plugins_url("/assets/css/wpdiscuz-private-comment$suf.css", __FILE__), null, $this->version);
        wp_enqueue_style("wpdiscuz-private-comment-css");
        wp_register_script("wpdiscuz-private-comment-js", plugins_url("/assets/js/wpdiscuz-private-comment$suf.js", __FILE__), ["jquery"], $this->version, true);
        wp_enqueue_script("wpdiscuz-private-comment-js");
    }

    public function adminScripts() {
	    global $pagenow;
        if ($pagenow === WpdiscuzCore::PAGE_COMMENTS) {
            wp_register_script("wpdiscuz-private-comment-admin-js", plugins_url("/assets/js/wpdiscuz-private-comment-admin.js", __FILE__), ["jquery"], $this->version);
            wp_enqueue_script("wpdiscuz-private-comment-admin-js");
        }
    }

    private function initPluginVersion() {
        if (!function_exists("get_plugins")) {
            require_once ABSPATH . "wp-admin/includes/plugin.php";
        }
        $plugin_folder = get_plugins("/" . plugin_basename(dirname(__FILE__)));
        $plugin_file = basename(( __FILE__));
        $this->version = $plugin_folder[$plugin_file]["Version"];
    }

    private function getCurrentUser() {
        if (!$this->currentUser) {
            $this->currentUser = WpdiscuzHelper::getCurrentUser();
        }
        return $this->currentUser;
    }

    public static function getInstance() {
        if (is_null(self::$instance)) {
            self::$instance = new wpDiscuzPrivateComment();
        }
        return self::$instance;
    }

    public function addCommentType($args) {
        if ($user = wp_get_current_user()) {
            if ($this->canModeratePrivateComment($user)) {
                $args[self::PRIVATE_CONTENT_TYPE] = __("Private", "wpdiscuz_private_comment");
            }
        }
        return $args;
    }

    public function commentRowPrivateAction($actions, $comment) {
        if ($user = wp_get_current_user()) {
            if ($this->canModeratePrivateComment($user, $comment->comment_post_ID)) {
                if (!$comment->comment_parent) {
                    $privateIcon = "fa-eye";
                    if ($comment->comment_type === self::PRIVATE_CONTENT_TYPE) {
                        $privateText = __("Public", "wpdiscuz_private_comment");
                        $privateIcon .= "-slash";
                    } else {
                        $privateText = __("Private", "wpdiscuz_private_comment");
                    }
                    $actions["private"] = "<a data-comment='" . $comment->comment_ID . "' data-post='" . $comment->comment_post_ID . "' class='wc_private_btn' href='#'> <i class='fas " . $privateIcon . "'></i> <span class='wc_private_text'>" . $privateText . "</span></a>";
                }
            }
        }
        return $actions;
    }

    public function wpdiscuzFoundCommentsQuery($typesNotIn, $postId = null) {
        if ((($user = wp_get_current_user()) && !$this->canModeratePrivateComment($user, $postId)) || !$user) {
            $typesNotIn[] = self::PRIVATE_CONTENT_TYPE;
        }
        return $typesNotIn;
    }

}

$wpDiscuzPrivateComment = wpDiscuzPrivateComment::getInstance();
