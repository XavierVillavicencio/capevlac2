=== wpDiscuz - Private Comments ===
Contributors: gVectors Team
Requires at least: 5.0
Tested up to: 5.7
Stable tag: 7.0.9
Requires PHP: 5.4 and higher
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

wpDiscuz Private Comments addon is an easy tool to allow commenters create private comment threads. 
These threads will be available for website administrators, moderators and for the thread owners. 
Addon adds a small button next to the comment submit button to set it as private, also it 
adds [Private] button to parent comments to make it as private after the comment is submitted. 
The buttons to set comments as private can be displayed / hidden for certain user roles in dashboard. 
Also, it allows setting certain user role to moderate private comments. This feature can be 
enabled / disabled for certain Comment Form in case you have many custom comment forms for 
custom post types.