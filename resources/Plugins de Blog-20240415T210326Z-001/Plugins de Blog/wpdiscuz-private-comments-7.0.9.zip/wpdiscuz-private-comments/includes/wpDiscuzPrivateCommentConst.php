<?php

interface wpDiscuzPrivateCommentConst {
    const PRIVATE_CONTENT_TYPE = "private";
    const STICKY_CONTENT_TYPE = "wpdiscuz_sticky";
}
