<?php
if (!defined("ABSPATH")) {
    exit();
}
$values = $setting["values"]->get();
$blogRoles = get_editable_roles();
?>
<style>
    #wpd-setbox .wpd-setcon .wpd-opt-row .wpd-opt-name{width: 50%;}
    #wpd-setbox .wpd-setcon .wpd-opt-row .wpd-opt-input{width: 50%;}
</style>
<div class="wpd-subtitle">
    <?php _e("General", "wpdiscuz_private_comment") ?>
</div>
<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="can_add_private_comment">
    <div class="wpd-opt-name">
        <label for="can_add_private_comment"><?php echo $setting["options"]["can_add_private_comment"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["can_add_private_comment"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
        <?php
        foreach ($blogRoles as $role => $info) {
            if ($role == 'administrator') {
                ?>
                <div class="wpd-mublock-inline wpd-mu-mimes" style="max-width: 49%;">
                    <input type="checkbox" checked disabled value="<?php echo $role; ?>" name="<?php echo $setting["values"]->tabKey; ?>[can_add_private_comment][]" id="wpdpmadd-<?php echo $role; ?>" style="margin:0px; vertical-align: middle;" />
                    <label style="color: #999999;" for="wpdpmadd-<?php echo $role; ?>" style="white-space:nowrap; font-size:13px;"><?php echo $info['name']; ?></label>
                </div>
                <?php
            } else {
                ?>
                <div class="wpd-mublock-inline wpd-mu-mimes" style="max-width: 49%;">
                    <input type="checkbox" <?php checked(in_array($role, $values["can_add_private_comment"])); ?> value="<?php echo $role; ?>" name="<?php echo $setting["values"]->tabKey; ?>[can_add_private_comment][]" id="wpdpmadd-<?php echo $role; ?>" style="margin:0px; vertical-align: middle;" />
                    <label for="wpdpmadd-<?php echo $role; ?>" style="white-space:nowrap; font-size:13px;"><?php echo $info['name']; ?></label>
                </div>
                <?php
            }
        }
        ?>
        <div class="wpd-clear"></div>
    </div>
</div>
<!-- Option end -->
<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="moderator_user_groups">
    <div class="wpd-opt-name">
        <label for="moderator_user_groups"><?php echo $setting["options"]["moderator_user_groups"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["moderator_user_groups"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
        <?php
        foreach ($blogRoles as $role => $info) {
            if ($role == 'administrator') {
                ?>
                <div class="wpd-mublock-inline wpd-mu-mimes" style="width: 200px; min-width: 33%;">
                    <input type="checkbox" checked disabled value="<?php echo $role; ?>" name="<?php echo $setting["values"]->tabKey; ?>[moderator_user_groups][]" id="wpdpmoderator-<?php echo $role; ?>" style="margin:0px; vertical-align: middle;" />
                    <label style="color: #999999;" for="wpdpmoderator-<?php echo $role; ?>" style="white-space:nowrap; font-size:13px;"><?php echo $info['name']; ?></label>
                </div>
                <?php
            } else if (key_exists('moderate_comments', $info['capabilities']) && $info['capabilities']['moderate_comments']) {
                ?>
                <div class="wpd-mublock-inline wpd-mu-mimes" style="width: 200px; min-width: 33%;">
                    <input type="checkbox" <?php checked(in_array($role, $values['moderator_user_groups'])); ?> value="<?php echo $role; ?>" name="<?php echo $setting["values"]->tabKey; ?>[moderator_user_groups][]" id="wpdpmoderator-<?php echo $role; ?>" style="margin:0px; vertical-align: middle;" />
                    <label for="wpdpmoderator-<?php echo $role; ?>" style="white-space:nowrap; font-size:13px;"><?php echo $info['name']; ?></label>
                </div>
                <?php
            }
        }
        ?>
        <div class="wpd-clear"></div>
    </div>
</div>
<!-- Option end -->
<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="post_author_can_moderate">
    <div class="wpd-opt-name">
        <label for="post_author_can_moderate"><?php echo $setting["options"]["post_author_can_moderate"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["post_author_can_moderate"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
        <div class="wpd-switcher">
            <input type="checkbox" <?php checked($values["post_author_can_moderate"] == 1); ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[post_author_can_moderate]" id="post_author_can_moderate">
            <label for="post_author_can_moderate"></label>
        </div>
    </div>
</div>
<!-- Option end -->
<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="private_comment_forms">
    <div class="wpd-opt-name">
        <label for="private_comment_forms"><?php echo $setting["options"]["private_comment_forms"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["private_comment_forms"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
        <?php
        $forms = get_posts(['numberposts' => -1,
            'post_type' => 'wpdiscuz_form',
            'post_status' => 'publish']);
        foreach ($forms as $form) {
            ?>
            <div class="wpd-mublock-inline wpd-mu-mimes" style="width: 200px; min-width: 33%;">
                <input type="checkbox" <?php checked(in_array($form->ID, $values['private_comment_forms'])); ?> value="<?php echo $form->ID; ?>" name="<?php echo $setting["values"]->tabKey; ?>[private_comment_forms][]" id="wpdpmform-<?php echo $form->ID; ?>" style="margin:0px; vertical-align: middle;" />
                <label for="wpdpmform-<?php echo $form->ID; ?>" style="white-space:nowrap; font-size:13px;"><?php echo $form->post_title ? $form->post_title : __('no title', "wpdiscuz_private_comment") . ' ( ID : ' . $form->ID . ' )'; ?></label>
            </div>
            <?php
        }
        ?>
        <div class="wpd-clear"></div>
    </div>
</div>
<!-- Option end -->
<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="private_comment_set_private">
    <div class="wpd-opt-name">
        <label for="private_comment_set_private"><?php echo $setting["options"]["private_comment_set_private"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["private_comment_set_private"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
        <div class="wpd-switcher">
            <input type="checkbox" <?php checked($values["private_comment_set_private"] == 1); ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[private_comment_set_private]" id="private_comment_set_private">
            <label for="private_comment_set_private"></label>
        </div>
    </div>
</div>
<!-- Option end -->
<div class="wpd-subtitle">
    <?php _e("Email Notification", "wpdiscuz_private_comment") ?>
</div>
<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="private_comment_notification_enabled">
    <div class="wpd-opt-name">
        <label for="private_comment_notification_enabled"><?php echo $setting["options"]["private_comment_notification_enabled"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["private_comment_notification_enabled"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
        <div class="wpd-switcher">
            <input type="checkbox" <?php checked($values["private_comment_notification_enabled"]); ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[private_comment_notification_enabled]" id="private_comment_notification_enabled">
            <label for="private_comment_notification_enabled"></label>
        </div>
    </div>
</div>
<!-- Option end -->
<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="private_comment_notification_subject">
    <div class="wpd-opt-name">
        <label for="private_comment_notification_subject"><?php echo $setting["options"]["private_comment_notification_subject"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["private_comment_notification_subject"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
        <input type="text" name="<?php echo $setting["values"]->tabKey; ?>[private_comment_notification_subject]" value="<?php echo esc_attr($values['private_comment_notification_subject']); ?>" id="private_comment_notification_subject" style="margin:1px;padding:3px 5px; width:90%;"/>
    </div>
</div>
<!-- Option end -->
<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="private_comment_notification_message">
    <div class="wpd-opt-name">
        <label for="private_comment_notification_message"><?php echo $setting["options"]["private_comment_notification_message"]["label"] ?></label>
        <p class="wpd-desc">
            <?php echo $setting["options"]["private_comment_notification_message"]["description"] ?>
            [post-title] - <?php _e('Post Title', "wpdiscuz_private_comment"); ?><br>
            [post-url] -  <?php _e('Post URL', "wpdiscuz_private_comment"); ?><br>
            [comment-url] - <?php _e('Private Comment Thread URL', "wpdiscuz_private_comment"); ?>
        </p>
    </div>
    <div class="wpd-opt-input">
        <textarea name="<?php echo $setting["values"]->tabKey; ?>[private_comment_notification_message]" id="private_comment_notification_message" style="width:90%;" rows="6"><?php echo $values['private_comment_notification_message']; ?></textarea>
    </div>
</div>
<!-- Option end -->