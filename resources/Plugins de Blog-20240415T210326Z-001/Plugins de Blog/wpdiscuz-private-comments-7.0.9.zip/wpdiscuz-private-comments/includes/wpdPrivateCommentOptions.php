<?php

class wpdPrivatCommentOptions {

    private $pluginOptions;
    private $optionKey = "wpdiscuz_private_comment";
    public $tabKey = "wpc";

    public function __construct() {
        $this->add();
        $this->init();
        add_action("wpdiscuz_save_options", [&$this, "saveOptions"], 15);
        add_action("wpdiscuz_reset_options", [&$this, "resetOptions"], 15);
        add_filter("wpdiscuz_settings", [&$this, "settingsArray"], 55);
    }

    public function getDefault() {
        $formIDs = [];
        $forms = get_posts(["numberposts" => -1,
            "post_type" => "wpdiscuz_form",
            "post_status" => "publish"]);
        foreach ($forms as $form) {
            $formIDs[] = $form->ID;
        }
        return ["moderator_user_groups" => ["administrator", "editor"],
            "can_add_private_comment" => ["administrator", "editor", "author", "contributor", "subscriber"],
            "private_comment_forms" => $formIDs,
            "private_comment_notification_enabled" => 0,
            "private_comment_notification_subject" => __("New Private Comment", "wpdiscuz_private_comment"),
            "private_comment_notification_message" => __('Hi!<br />New private comment thread is create under "[post-title]" post. <br />Please make sure you\'re logged-in before navigating to the private comment thread. <br /><br />Post URL: [post-url] <br />Comment Thread URL: [comment-url] ', "wpdiscuz_private_comment"),
            "private_comment_set_private" => 0,
            "post_author_can_moderate" => 1,
        ];
    }

    public function get() {
        return $this->pluginOptions;
    }

    private function add() {
        $defaults = $this->getDefault();
        add_option($this->optionKey, $defaults, "", "no");
    }

    private function init() {
        $this->pluginOptions = get_option($this->optionKey);
    }

    public function saveOptions() {
        if ($this->tabKey === $_POST["wpd_tab"]) {
            $this->pluginOptions["moderator_user_groups"] = isset($_POST[$this->tabKey]["moderator_user_groups"]) ? $_POST[$this->tabKey]["moderator_user_groups"] : [];
            $this->pluginOptions["can_add_private_comment"] = isset($_POST[$this->tabKey]["can_add_private_comment"]) ? $_POST[$this->tabKey]["can_add_private_comment"] : [];
            $this->pluginOptions["private_comment_forms"] = isset($_POST[$this->tabKey]["private_comment_forms"]) ? $_POST[$this->tabKey]["private_comment_forms"] : [];
            $this->pluginOptions["private_comment_notification_enabled"] = isset($_POST[$this->tabKey]["private_comment_notification_enabled"]) ? $_POST[$this->tabKey]["private_comment_notification_enabled"] : 0;
            $this->pluginOptions["private_comment_notification_subject"] = isset($_POST[$this->tabKey]["private_comment_notification_subject"]) ? wp_unslash($_POST[$this->tabKey]["private_comment_notification_subject"]) : __("New Private Comment", "wpdiscuz_private_comment");
            $this->pluginOptions["private_comment_notification_message"] = isset($_POST[$this->tabKey]["private_comment_notification_message"]) ? wp_unslash($_POST[$this->tabKey]["private_comment_notification_message"]) : __('Hi!<br />New private comment thread is create under "[post-title]" post. <br />Please make sure you\'re logged-in before navigating to the private comment thread. <br /><br />Post URL: [post-url] <br />Comment Thread URL: [comment-url] ', "wpdiscuz_private_comment");
            $this->pluginOptions["can_add_private_comment"][] = "administrator";
            $this->pluginOptions["moderator_user_groups"][] = "administrator";
            $this->pluginOptions["private_comment_set_private"] = isset($_POST[$this->tabKey]["private_comment_set_private"]) ? $_POST[$this->tabKey]["private_comment_set_private"] : 0;
            $this->pluginOptions["post_author_can_moderate"] = isset($_POST[$this->tabKey]["post_author_can_moderate"]) ? $_POST[$this->tabKey]["post_author_can_moderate"] : 0;
            update_option($this->optionKey, $this->pluginOptions);
        }
    }

    public function resetOptions($tab) {
        if ($this->tabKey === $tab || $tab === "all") {
            delete_option($this->optionKey);
            $this->add();
            $this->init();
        }
    }

    public function settingsArray($settings) {
        $settings["addons"][$this->tabKey] = [
            "title" => __("Private Comments", "wpdiscuz_private_comment"),
            "title_original" => "Private Comments",
            "icon" => "",
            "icon-height" => "",
            "file_path" => WPC_DIR_PATH . "/includes/options-tab-content.php",
            "values" => $this,
            "options" => [
                "can_add_private_comment" => [
                    "label" => __("User roles can create private comment threads", "wpdiscuz_private_comment"),
                    "label_original" => "User roles can create private comment threads",
                    "description" => "",
                    "description_original" => "",
                    "docurl" => "#"
                ],
                "moderator_user_groups" => [
                    "label" => __("User roles can moderate private comments threads", "wpdiscuz_private_comment"),
                    "label_original" => "User roles can moderate private comments threads",
                    "description" => "",
                    "description_original" => "",
                    "docurl" => "#"
                ],
                "post_author_can_moderate" => [
                    "label" => __("Post author can moderate private comments threads", "wpdiscuz_private_comment"),
                    "label_original" => "Post author can moderate private comments threads",
                    "description" => "",
                    "description_original" => "",
                    "docurl" => "#"
                ],
                "private_comment_forms" => [
                    "label" => __("Enable private threads for comment forms", "wpdiscuz_private_comment"),
                    "label_original" => "Enable private threads for comment forms",
                    "description" => __("You can manage comment forms and fields in Dashboard > Comments > Forms admin page.", "wpdiscuz_private_comment"),
                    "description_original" => "You can manage comment forms and fields in Dashboard > Comments > Forms admin page.",
                    "docurl" => "#"
                ],
                "private_comment_set_private" => [
                    "label" => __("Set new comments to private", "wpdiscuz_private_comment"),
                    "label_original" => "Set new comments to private",
                    "description" => "",
                    "description_original" => "",
                    "docurl" => "#"
                ],
                "private_comment_notification_enabled" => [
                    "label" => __("Enable Notification", "wpdiscuz_private_comment"),
                    "label_original" => "Enable Notification",
                    "description" => "",
                    "description_original" => "",
                    "docurl" => "#"
                ],
                "private_comment_notification_subject" => [
                    "label" => __("Email Subject", "wpdiscuz_private_comment"),
                    "label_original" => "Email Subject",
                    "description" => "",
                    "description_original" => "",
                    "docurl" => "#"
                ],
                "private_comment_notification_message" => [
                    "label" => __("Email Text", "wpdiscuz_private_comment"),
                    "label_original" => "Email Text",
                    "description" => "",
                    "description_original" => "",
                    "docurl" => "#"
                ],
            ],
        ];
        return $settings;
    }

}
