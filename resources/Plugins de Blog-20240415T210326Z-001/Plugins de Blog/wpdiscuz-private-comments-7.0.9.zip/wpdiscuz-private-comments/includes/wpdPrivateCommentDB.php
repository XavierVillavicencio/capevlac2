<?php

class wpdPrivateCommentDB {

    private $options;

    public function __construct($options) {
        $this->options = $options;
    }

    public function getPublicCommentsCount($postID) {
        global $wpdb;
        return $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM `{$wpdb->comments}` WHERE `comment_type` != '" . wpDiscuzPrivateComment::PRIVATE_CONTENT_TYPE . "' AND `comment_post_ID` = %d AND `comment_approved` = '1'", $postID));
    }

    public function getPrivateCommentsByUserID($userID, $postID = NULL) {
        global $wpdb;
        $wpdiscuz = wpDiscuz();
        $privateCommentIDs = [];
        $condition = "";
        if ($postID) {
            $condition = " AND `comment_post_ID` =" . intval($postID);
        }
        $parentCommentIDs = $wpdb->get_col($wpdb->prepare("SELECT `comment_ID` FROM `{$wpdb->comments}` WHERE `comment_type` = '" . wpDiscuzPrivateComment::PRIVATE_CONTENT_TYPE . "' AND `comment_parent` = 0 AND `user_id` = %d $condition", $userID));
        if ($parentCommentIDs) {
            foreach ($parentCommentIDs as $parentCommentID) {
                $tree = [];
                $privateCommentIDs[] = $parentCommentID;
                $wpdiscuz->helperOptimization->getTreeByParentId($parentCommentID, $tree);
                $privateCommentIDs = array_merge($privateCommentIDs, $tree);
            }
        }
        return $privateCommentIDs;
    }

    public function changeCommentsType($commentIDs, $type) {
        if ($commentIDs) {
            global $wpdb;
            $ids = implode(",", $commentIDs);
            $type = $type === "private" ? WpdiscuzCore::$DEFAULT_COMMENT_TYPE : wpDiscuzPrivateComment::PRIVATE_CONTENT_TYPE;
            $sql = "UPDATE `{$wpdb->comments}` SET `comment_type` = '$type' WHERE `comment_ID` IN ($ids);";
            $wpdb->query("UPDATE `{$wpdb->comments}` SET `comment_type` = '$type' WHERE `comment_ID` IN ($ids);");
        }
    }

    public function getCommentData($commentID) {
        global $wpdb;
        return $wpdb->get_row($wpdb->prepare("SELECT `user_id`,`comment_parent` FROM `{$wpdb->comments}` WHERE `comment_ID` = %d", $commentID), ARRAY_A);
    }

}
