=== wpDiscuz - Advanced Liking ===
Contributors: gVectors Team
Requires at least: 5.0
Tested up to: 5.9
Stable tag: 7.0.7
Requires PHP: 5.4 and higher
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Finally, after dozens of wpDiscuz users requests we’re releasing the Advanced Likers addon.
This is a light solution for people who wants to display comment likers list and encourage 
commenters with some reputation titles and badges. wpDiscuz Advanced Likers addon opens a 
pop-up window with all voters/likes of current comment. You can see positive and negative 
voters separately. The light user reputation system allows to display different rating titles 
and badges based on amount of received likes.