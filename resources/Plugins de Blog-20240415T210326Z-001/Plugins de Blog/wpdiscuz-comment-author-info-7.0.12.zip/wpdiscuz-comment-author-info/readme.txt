=== wpDiscuz - Comment Author Info ===
Contributors: gVectors Team
Requires at least: 5.0
Tested up to: 6.0
Stable tag: 7.0.12
Requires PHP: 5.4 and higher
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

WordPress Comment System has a lack of information about comment authors, people only see 
commenter name and avatar. wpDiscuz Comment Author Info addon is designed to provide 
extended details about comment authors. Using this addon people will be able to see 
comment author extended profile, activity, votes and subscriptions. Click on comment 
author info icon and open pop-up window with according tabs. In Profile tab you can see 
commenter quick statistic (number of comments, posts, likes, dislikes), biography, etc… 
In Activity tab all comments of this author, in Votes tab: all voted comments and in 
Subscriptions tab: all type of subscriptions to  new comments.