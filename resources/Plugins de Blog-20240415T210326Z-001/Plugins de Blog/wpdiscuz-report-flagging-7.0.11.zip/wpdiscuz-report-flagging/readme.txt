=== wpDiscuz - Report and Flagging ===
Contributors: gVectors Team
Requires at least: 5.0
Tested up to: 6.0
Stable tag: 7.0.11
Requires PHP: 5.4 and higher
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Flagging a comment tells admins that a comment requires moderator attention. 
This addon comes with complete package of very useful functions and tools, 
which automatically moderates all comments based on number of flags and down 
votes (dislikes).  In other words, website visitors will help you moderate bad comments. 
Those will be automatically unapproved or trashed once the maximum number of 
flags and dislikes is reached. Moreover, it allows visitors to report comments 
choosing bad comment category and writing some  description/reason. 
Addon keeps you informed by email notifications about new comment reports 
and new auto-moderated comments.