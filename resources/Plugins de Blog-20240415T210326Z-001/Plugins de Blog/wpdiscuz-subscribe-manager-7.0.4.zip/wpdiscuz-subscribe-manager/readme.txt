=== wpDiscuz - Subscription Manager ===
Contributors: gVectors Team
Requires at least: 5.0
Tested up to: 5.7
Stable tag: 7.0.4
Requires PHP: 5.4 and higher
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Finally you can monitor and manage all subscribers in dashboard. 
As you may already know wpDiscuz has three subscription options on 
comment section (notify on new comments, on replies to my all comments 
and on replies of this one comment). All subscriptions were being saved 
in database but you had no access. Using this addon you’ll see all guests 
and users who have subscribed using one of wpDiscuz subscription option 
mentioned above. Ads “Subscriptions” subMenu in Comments menu section. 
Displays numeric subscription statistic. Allows you find and manage own 
subscriptions in “Your Subscriptions” admin page.