/* global jQuery */
jQuery(document).ready(function ($) {
    $(document).on('click', '.wpdiscuz-giphy-preview-gif', function () {
        var el = $(this);
        var img = el.find('.wpdiscuz-giphy-embedded-gif');
        img.prop('src', img.prop('src').replace('giphy_s.gif', 'giphy.gif'));
        el.removeClass('wpdiscuz-giphy-preview-gif').addClass('wpdiscuz-giphy-full-gif');
    });

    $(document).on('click', '.wpdiscuz-giphy-full-gif', function () {
        var el = $(this);
        var img = el.find('.wpdiscuz-giphy-embedded-gif');
        img.prop('src', img.prop('src').replace('giphy.gif', 'giphy_s.gif'));
        el.removeClass('wpdiscuz-giphy-full-gif').addClass('wpdiscuz-giphy-preview-gif');
    });
});