/* global jQuery */
/* global wpDiscuzGiphyObj */
/* global wpdiscuzAjaxObj */
/* global wpDiscuzEditor */
/* global Quill */
jQuery(document).ready(function ($) {
    var url = 'https://api.giphy.com/v1/gifs/';
    var limit = parseInt(wpDiscuzGiphyObj.limit);
    var categories = {};
    var offset = 0;
    var doingajax = false;
    var activeEditorId = '';
    var selection = null;
    var xhr = null;
    var wpdiscuzLoadRichEditor = parseInt(wpdiscuzAjaxObj.loadRichEditor);

    if (parseInt(wpDiscuzGiphyObj.isAllowed)) {
        if (wpdiscuzLoadRichEditor) {
            wpDiscuzEditor.addButtonEventHandler('giphy', function (editor) {
                activeEditorId = '#' + editor.container.id;
                selection = editor.getSelection();
                $('#wpdiscuz-giphy-popup-bg').show();
                $('#wpdiscuz-giphy-popup').css('display', 'flex');
                getGIFCategories();
            });
        } else {
            $(document).on('click', '.wpdiscuz-giphy-icon', function () {
                $('.wpd-form-foot', $(this).parents('.wpd_comm_form')).slideDown(parseInt(wpdiscuzAjaxObj.enableDropAnimation) ? 500 : 0);
                if ($(this).parents('.wpd_comm_form').length) {
                    activeEditorId = '#wc-textarea-' + $(this).parents('.wpd_comm_form').find('[name=wpdiscuz_unique_id]').val();
                } else if ($(this).parents('#wpdiscuz-edit-form').length) {
                    activeEditorId = '#wc-textarea-edit_' + $(this).parents('#wpdiscuz-edit-form').find('[name=wpdiscuz_unique_id]').val();
                }
                $('#wpdiscuz-giphy-popup-bg').show();
                $('#wpdiscuz-giphy-popup').css('display', 'flex');
                getGIFCategories();
            });
        }

        $(document).on('click', '.wpdiscuz-giphy-category', function () {
            var category = $(this).attr('data-searchterm');
            $('#wpdiscuz-giphy-links').show();
            if (category === 'trending') {
                $('#wpdiscuz-giphy-content').attr('data-searchterm', category).empty();
                searchTrendingGIFs(true);
            } else {
                $('#wpdiscuz-giphy-content').removeAttr('data-searchterm').empty();
                getGIFCategories(category);
            }
        });

        $(document).on('click', '.wpdiscuz-giphy-subcategory', function () {
            var category = $(this).attr('data-searchterm');
            $('#wpdiscuz-giphy-content').attr('data-searchterm', category).empty();
            $('#wpdiscuz-giphy-links').show();
            if (category === 'trending') {
                searchTrendingGIFs(true);
            } else {
                searchGIFsByCategory(category, true);
            }
        });

        $(document).on('click', '.wpdiscuz-giphy-gif', function () {
            var shortcode = "[wpd-giphy id='" + $(this).attr('data-id') + "' subdomain='" + $(this).attr('data-subdomain') + "' width='" + $(this).attr('data-width') + "' height='" + $(this).attr('data-height') + "']";
            if (wpdiscuzLoadRichEditor) {
                var editor = wpDiscuzEditor.createEditor(activeEditorId);
                if (!selection) {
                    selection = {index: editor.getLength() - 1, length: 0};
                }
                editor.insertText(selection.index, shortcode, Quill.sources.USER);
                editor.setSelection(selection.index + selection.length + shortcode.length, Quill.sources.USER);
                selection = null;
            } else {
                var textarea = $(activeEditorId);
                var textareaVal = textarea.val();
                var selectionStart = textareaVal.length;
                if (textarea.prop("selectionStart")) {
                    selectionStart = textarea.prop("selectionStart");
                }
                textarea.val(textareaVal.slice(0, selectionStart) + shortcode + textareaVal.slice(selectionStart));
            }
            closePopup();
        });

        $(document).on('keyup', '#wpdiscuz-giphy-search', function () {
            var el = $(this);
            var val = el.val();
            if (val.length > 2) {
                $('#wpdiscuz-giphy-content').attr('data-searchterm', val).empty();
                $('#wpdiscuz-giphy-links').show();
                searchGIFs(val, true);
            } else if (val.length === 0) {
                $('#wpdiscuz-giphy-content').removeAttr('data-searchterm').empty();
                getGIFCategories();
            }
        });

        $('#wpdiscuz-giphy-content').on('scroll', function () {
            var searchterm = encodeURIComponent($(this).attr('data-searchterm'));
            if (offset && searchterm && (this.scrollHeight - this.scrollTop - this.clientHeight < 200)) {
                if (searchterm === 'trending') {
                    searchTrendingGIFs(false);
                } else {
                    searchGIFsByCategory(searchterm, false);
                }
            }
        });

        $(document).on('click', '#wpdiscuz-giphy-back-to-categories', function (e) {
            e.preventDefault();
            $('#wpdiscuz-giphy-search').val('');
            $('#wpdiscuz-giphy-content').removeAttr('data-searchterm').empty();
            getGIFCategories();
        });

        $(document).on('click', '#wpdiscuz-giphy-popup-bg', function () {
            closePopup();
        });

    }

    function getGIFCategories(parent) {
        offset = 0;
        parent = parent ? parent : '';
        if ($.isEmptyObject(categories) || (parent && $.isEmptyObject(categories[parent].subcategories))) {
            $('#wpdiscuz-loading-bar').show();
            $.ajax({
                type: 'GET',
                url: url + 'categories' + (parent ? ('/' + parent) : '') + '?api_key=' + wpDiscuzGiphyObj.key
            }).done(function (r) {
                if (r.data) {
                    if (parent) {
                        for (var i in r.data) {
                            categories[parent].subcategories[r.data[i].name_encoded] = r.data[i];
                        }
                    } else {
                        for (var i in r.data) {
                            r.data[i].subcategories = {};
                            categories[r.data[i].name_encoded] = r.data[i];
                        }
                    }
                    printCategories(categories, parent);
                }
                $('#wpdiscuz-loading-bar').fadeOut(250);
                if (!parent) {
                    $('#wpdiscuz-giphy-links').hide();
                }
            }).fail(function (jqXHR, textStatus, errorThrown) {
                if (!parent) {
                    $('#wpdiscuz-giphy-links').hide();
                }
                $('#wpdiscuz-loading-bar').fadeOut(250);
                if (typeof jqXHR.responseJSON !== 'undefined' && typeof jqXHR.responseJSON.message !== 'undefined') {
                    wpdiscuzAjaxObj.setCommentMessage(jqXHR.responseJSON.message, 'error');
                }
                console.log(errorThrown);
            });
        } else {
            if (!parent) {
                $('#wpdiscuz-giphy-links').hide();
            }
            printCategories(categories, parent);
        }
    }

    function searchGIFsByCategory(category, clearWrapper) {
        if (!doingajax) {
            doingajax = true;
            $('#wpdiscuz-loading-bar').show();
            $.ajax({
                type: 'GET',
                url: url + 'search?api_key=' + wpDiscuzGiphyObj.key + '&q=' + category + '&lang=' + wpDiscuzGiphyObj.lang + '&rating=' + wpDiscuzGiphyObj.rating + '&limit=' + limit + '&offset=' + offset
            }).done(function (r) {
                if (r.data) {
                    if (clearWrapper) {
                        $('#wpdiscuz-giphy-content').empty().append(
                            $('<div>').attr('id', 'wpdiscuz-giphy-content-left'),
                            $('<div>').attr('id', 'wpdiscuz-giphy-content-right')
                        );
                    }
                    printGIFs(r.data);
                    setOffset(r);
                }
                doingajax = false;
                $('#wpdiscuz-loading-bar').fadeOut(250);
            }).fail(function (jqXHR, textStatus, errorThrown) {
                doingajax = false;
                $('#wpdiscuz-loading-bar').fadeOut(250);
                if (typeof jqXHR.responseJSON !== 'undefined' && typeof jqXHR.responseJSON.message !== 'undefined') {
                    wpdiscuzAjaxObj.setCommentMessage(jqXHR.responseJSON.message, 'error');
                }
                console.log(errorThrown);
            });
        }
    }

    function searchTrendingGIFs(clearWrapper) {
        if (!doingajax) {
            doingajax = true;
            $('#wpdiscuz-loading-bar').show();
            $.ajax({
                type: 'GET',
                url: url + 'trending?api_key=' + wpDiscuzGiphyObj.key + '&rating=' + wpDiscuzGiphyObj.rating + '&limit=' + limit + '&offset=' + offset
            }).done(function (r) {
                if (r.data) {
                    if (clearWrapper) {
                        $('#wpdiscuz-giphy-content').empty().append(
                            $('<div>').attr('id', 'wpdiscuz-giphy-content-left'),
                            $('<div>').attr('id', 'wpdiscuz-giphy-content-right')
                        );
                    }
                    printGIFs(r.data);
                    setOffset(r);
                }
                doingajax = false;
                $('#wpdiscuz-loading-bar').fadeOut(250);
            }).fail(function (jqXHR, textStatus, errorThrown) {
                doingajax = false;
                $('#wpdiscuz-loading-bar').fadeOut(250);
                if (typeof jqXHR.responseJSON !== 'undefined' && typeof jqXHR.responseJSON.message !== 'undefined') {
                    wpdiscuzAjaxObj.setCommentMessage(jqXHR.responseJSON.message, 'error');
                }
                console.log(errorThrown);
            });
        }
    }

    function searchGIFs(search) {
        $('#wpdiscuz-loading-bar').show();
        if (xhr) {
            xhr.abort();
        }
        xhr = $.ajax({
            type: 'GET',
            url: url + 'search?api_key=' + wpDiscuzGiphyObj.key + '&q=' + encodeURIComponent(search) + '&lang=' + wpDiscuzGiphyObj.lang + '&rating=' + wpDiscuzGiphyObj.rating + '&limit=' + limit
        }).done(function (r) {
            if (r.data) {
                $('#wpdiscuz-giphy-content').empty().append(
                    $('<div>').attr('id', 'wpdiscuz-giphy-content-left'),
                    $('<div>').attr('id', 'wpdiscuz-giphy-content-right')
                );
                printGIFs(r.data);
                setOffset(r);
            }
            $('#wpdiscuz-loading-bar').fadeOut(250);
        }).fail(function (jqXHR, textStatus, errorThrown) {
            $('#wpdiscuz-loading-bar').fadeOut(250);
            if (typeof jqXHR.responseJSON !== 'undefined' && typeof jqXHR.responseJSON.message !== 'undefined') {
                wpdiscuzAjaxObj.setCommentMessage(jqXHR.responseJSON.message, 'error');
            }
            console.log(errorThrown);
        });
    }

    function printCategories(data, parent) {
        if (parent) {
            var subcategories = data[parent].subcategories;
            for (var i in subcategories) {
                $('#wpdiscuz-giphy-content').append(
                    $('<div>')
                        .addClass('wpdiscuz-giphy-subcategory')
                        .attr('data-searchterm', i)
                        .prop('title', subcategories[i].name)
                        .css('background-image', 'url(' + subcategories[i].gif.images.downsized.url + ')')
                        .append(
                            $('<div>')
                                .addClass('wpdiscuz-giphy-category-smooth')
                                .html(subcategories[i].name)
                        )
                );
            }
        } else {
            $('#wpdiscuz-giphy-content').append(
                $('<div>')
                    .addClass('wpdiscuz-giphy-category wpdiscuz-giphy-trending')
                    .attr('data-searchterm', 'trending')
                    .prop('title', wpDiscuzGiphyObj.phraseTrending)
                    .css('background-color', '#91b58c')
                    .append(
                        $('<div>')
                            .addClass('wpdiscuz-giphy-category-smooth')
                            .html('<svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="chart-line" class="svg-inline--fa fa-chart-line fa-w-16" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="16" height="16"><path fill="currentColor" d="M496 384H64V80c0-8.84-7.16-16-16-16H16C7.16 64 0 71.16 0 80v336c0 17.67 14.33 32 32 32h464c8.84 0 16-7.16 16-16v-32c0-8.84-7.16-16-16-16zM464 96H345.94c-21.38 0-32.09 25.85-16.97 40.97l32.4 32.4L288 242.75l-73.37-73.37c-12.5-12.5-32.76-12.5-45.25 0l-68.69 68.69c-6.25 6.25-6.25 16.38 0 22.63l22.62 22.62c6.25 6.25 16.38 6.25 22.63 0L192 237.25l73.37 73.37c12.5 12.5 32.76 12.5 45.25 0l96-96 32.4 32.4c15.12 15.12 40.97 4.41 40.97-16.97V112c.01-8.84-7.15-16-15.99-16z"></path></svg>&nbsp;' + wpDiscuzGiphyObj.phraseTrending)
                    )
            );
            for (var i in data) {
                $('#wpdiscuz-giphy-content').append(
                    $('<div>')
                        .addClass('wpdiscuz-giphy-category')
                        .attr('data-searchterm', i)
                        .prop('title', data[i].name)
                        .css('background-image', 'url(' + data[i].gif.images.downsized.url + ')')
                        .append(
                            $('<div>')
                                .addClass('wpdiscuz-giphy-category-smooth')
                                .html(data[i].name)
                        )
                );
            }
        }
    }

    function printGIFs(data) {
        var half = Math.round(data.length / 2);
        data.forEach(function (val, i) {
            $('#wpdiscuz-giphy-content-' + (i < half ? 'left' : 'right')).append(
                $('<img>')
                    .attr('src', val.images.preview_gif.url)
                    .attr('data-id', val.id)
                    .attr('data-subdomain', /https:\/\/(media[\d]?)\.giphy\.com\/media/.exec(val.images.original.url)[1])
                    .attr('data-width', val.images.original.width)
                    .attr('data-height', val.images.original.height)
                    .addClass('wpdiscuz-giphy-gif')
                    .prop('title', val.title)
            );
        });
    }

    function setOffset(r) {
        if (r.pagination) {
            // 4999 is maximum accepted value for giphy
            if (offset >= 4999 || offset >= r.pagination.total_count) {
                offset = 0;
            } else {
                offset += r.pagination.count;
            }
        } else {
            offset = 0;
        }
    }

    function closePopup() {
        $('#wpdiscuz-giphy-popup-bg').hide();
        $('#wpdiscuz-giphy-popup').hide();
        $('#wpdiscuz-giphy-links').hide();
        $('#wpdiscuz-giphy-content').removeAttr('data-searchterm').empty();
        $('#wpdiscuz-giphy-search').val('');
        activeEditorId = '';
        selection = null;
    }

    $(document).on('click', '.wpdiscuz-giphy-preview-gif', function () {
        var el = $(this);
        var img = el.find('.wpdiscuz-giphy-embedded-gif');
        img.prop('src', img.prop('src').replace('giphy_s.gif', 'giphy.gif'));
        el.removeClass('wpdiscuz-giphy-preview-gif').addClass('wpdiscuz-giphy-full-gif');
    });

    $(document).on('click', '.wpdiscuz-giphy-full-gif', function () {
        var el = $(this);
        var img = el.find('.wpdiscuz-giphy-embedded-gif');
        img.prop('src', img.prop('src').replace('giphy.gif', 'giphy_s.gif'));
        el.removeClass('wpdiscuz-giphy-full-gif').addClass('wpdiscuz-giphy-preview-gif');
    });
});