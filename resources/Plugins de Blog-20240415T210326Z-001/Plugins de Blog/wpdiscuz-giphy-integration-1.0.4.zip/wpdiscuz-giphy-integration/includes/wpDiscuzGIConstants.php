<?php

if (!defined("ABSPATH")) {
	exit();
}

interface wpDiscuzGIConstants {

	const OPTION_VERSION                              = "wpdiscuz_giphy_version";
	const OPTION_SLUG_OPTIONS                         = "wpdiscuz_giphy_options";

}