<?php
/*
 * Plugin Name: wpDiscuz - GIPHY Integration
 * Description: Adds gif animation to comments powered by GIPHY (giphy.com)
 * Version: 1.0.4
 * Author: gVectors Team
 * Author URI: https://www.gvectors.com/
 * Plugin URI: https://www.gvectors.com/wpdiscuz-giphy-integration/
 * Text Domain: wpdiscuz-giphy-integration
 * Domain Path: /languages/
 */
if (!defined("ABSPATH")) {
    exit();
}

define("WPD_GI_PATH", __DIR__);
define("WPD_GI_DIR_NAME", basename(WPD_GI_PATH));

include_once WPD_GI_PATH . "/includes/gvt-api-manager.php";
include WPD_GI_PATH . "/includes/wpDiscuzGIConstants.php";
include WPD_GI_PATH . "/options/wpDiscuzGIOptions.php";

class wpDiscuzGiphyIntegration implements wpDiscuzGIConstants {

    private static $instance;
    private $version;
    private $options;
    private static $giphyPattern = '@\[(\[?)(wpd\-giphy)(?![\w-])([^\]\/]*(?:\/(?!\])[^\]\/]*)*?)(?:(\/)\]|\](?:([^\[]*+(?:\[(?!\/\2\])[^\[]*+)*+)\[\/\2\])?)(\]?)@isu';
    private static $attsPattern = '@([\w-]+)\s*=\s*\'([^\']*)\'(?:\s|$)|([\w-]+)\s*=\s*\'([^\']*)\'(?:\s|$)|([\w-]+)\s*=\s*([^\s\']+)(?:\s|$)|\'([^\']*)\'(?:\s|$)|\'([^\']*)\'(?:\s|$)|(\S+)(?:\s|$)@isu';
    public $apimanager;

    private function __construct() {
        add_action("plugins_loaded", [&$this, "pluginsLoaded"], 999);
    }

    public static function getInstance() {
        if (is_null(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function pluginsLoaded() {
        if (function_exists("wpDiscuz")) {
            $this->version = get_option(self::OPTION_VERSION, "1.0.0");
            $this->apimanager = new GVT_API_Manager(__FILE__, "wpdiscuz_options_page", "wpdiscuz_option_page");
            $this->options = new wpDiscuzGIOptions();
            load_plugin_textdomain("wpdiscuz-giphy-integration", false, dirname(plugin_basename(__FILE__)) . "/languages/");
            add_filter("comment_text", [$this, "displayGIFs"], 999, 3);
            add_filter("wpforo_content", [$this, "displayGIFsInPost"], 900);
            add_filter("wpforo_strip_shortcodes", [$this, "stripShortcodes"], 900);
            add_filter("get_comment_excerpt", [$this, "excerpDisplayGIFs"], 900, 3);
            $wpdiscuz = wpDiscuz();
            if ($wpdiscuz->options->form["richEditor"] === "both" || (!wp_is_mobile() && $wpdiscuz->options->form["richEditor"] === "desktop")) {
                add_filter("wpdiscuz_editor_buttons", [$this, "editorButtons"]);
            } else {
                add_filter("wpdiscuz_editor_buttons_html", [$this, "editorButtonsHtml"]);
            }
            add_action("wp_footer", [$this, "printPopup"]);
            add_action("wpdiscuz_front_scripts", [$this, "enqueueScripts"]);
            add_action("admin_enqueue_scripts", [$this, "enqueueAdminScripts"]);
            add_action("wpforo_frontend_enqueue_scripts", [$this, "enqueueWpForoScripts"]);
            add_action("admin_init", [$this, "pluginNewVersion"], 999);
        } else {
            add_action("admin_notices", [$this, "requirements"], 999);
        }
    }

    public function displayGIFs($content, $comment, $args = []) {
        if (!empty($args["is_wpdiscuz_comment"]) || is_admin()) {
            if (preg_match_all(self::$giphyPattern, $content, $matches, PREG_SET_ORDER)) {
                foreach ($matches as $key => $match) {
                    $match[3] = str_replace(["&#8217;", "&#8242;", "’", "′"], "'", $match[3]);
                    if (preg_match_all(self::$attsPattern, $match[3], $atts, PREG_SET_ORDER)) {
                        $gif = "<div class='wpdiscuz-giphy-embedded-gif-wrapper " . ($this->options->playOnLoad ? "wpdiscuz-giphy-full-gif" : "wpdiscuz-giphy-preview-gif") . "' style='width:auto;height:auto;'>";
                        $gif .= "<div class='wpdiscuz-giphy-embedded-gif-button'><img src='" . plugins_url(WPD_GI_DIR_NAME . "/assets/img/gif.png") . "'></div>";
                        $gif .= "<img class='wpdiscuz-giphy-embedded-gif' width='" . $atts[2][2] . "' height='" . $atts[3][2] . "' src='https://" . $atts[1][2] . ".giphy.com/media/" . $atts[0][2] . "/giphy" . ($this->options->playOnLoad ? "" : "_s") . ".gif' style='width:auto;height:auto;max-width:100%;'>";
                        $gif .= "</div>";
                        $content = str_replace($match[0], $gif, $content);
                    }
                }
            }
        }
        return $content;
    }

    public function displayGIFsInPost($content) {
        if (preg_match_all(self::$giphyPattern, $content, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $key => $match) {
                $match[3] = str_replace(["&#8217;", "&#8242;", "’", "′"], "'", $match[3]);
                if (preg_match_all(self::$attsPattern, $match[3], $atts, PREG_SET_ORDER)) {
                    $gif = "<div class='wpdiscuz-giphy-embedded-gif-wrapper " . ($this->options->playOnLoad ? "wpdiscuz-giphy-full-gif" : "wpdiscuz-giphy-preview-gif") . "' style='width:auto;height:auto;'>";
                    $gif .= "<img class='wpdiscuz-giphy-embedded-gif' width='" . $atts[2][2] . "' height='" . $atts[3][2] . "' src='https://" . $atts[1][2] . ".giphy.com/media/" . $atts[0][2] . "/giphy" . ($this->options->playOnLoad ? "" : "_s") . ".gif' style='width:auto;height:auto;max-width:100%;'>";
                    $gif .= "</div>";
                    $content = str_replace($match[0], $gif, $content);
                }
            }
        }
        return $content;
    }

    public function stripShortcodes($text){
        return preg_replace( '#\[wpd-giphy[^\[\]]+?]#iu', '', $text );
    }
    
    public function excerpDisplayGIFs($excerpt, $commentID, $comment) {
        if (preg_match_all(self::$giphyPattern, $excerpt, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $key => $match) {
                $match[3] = str_replace(["&#8217;", "&#8242;", "’", "′"], "'", $match[3]);
                if (preg_match_all(self::$attsPattern, $match[3], $atts, PREG_SET_ORDER)) {
                    $gif = "<div class='wpdiscuz-giphy-embedded-gif-wrapper " . ($this->options->playOnLoad ? "wpdiscuz-giphy-full-gif" : "wpdiscuz-giphy-preview-gif") . "' style='width:auto;height:auto;'>";
                    $gif .= "<div class='wpdiscuz-giphy-embedded-gif-button'><img src='" . plugins_url(WPD_GI_DIR_NAME . "/assets/img/gif.png") . "'></div>";
                    $gif .= "<img class='wpdiscuz-giphy-embedded-gif' width='" . $atts[2][2] . "' height='" . $atts[3][2] . "' src='https://" . $atts[1][2] . ".giphy.com/media/" . $atts[0][2] . "/giphy" . ($this->options->playOnLoad ? "" : "_s") . ".gif'  style='width:auto;height:auto;max-width:100%;'>";
                    $gif .= "</div>";
                    $excerpt = str_replace($match[0], $gif, $excerpt);
                }
            }
        }
        return $excerpt;
    }

    public function editorButtons($buttons) {
        if ($this->options->isAllowedFormAndUser()) {
            $buttons[] = [
                "class" => "ql-giphy",
                "value" => "",
                "name" => "giphy",
                "title" => esc_attr__("GIPHY", "wpdiscuz-giphy-integration"),
                "svg" => "<svg height='16' width='16' xmlns='http://www.w3.org/2000/svg' viewBox='4 2 16.32 20'><g fill='none' fill-rule='evenodd'><path d='M6.331 4.286H17.99v15.428H6.33z' fill='#000'/><g fill-rule='nonzero'><path d='M4 3.714h2.331v16.572H4z' fill='#04ff8e'/><path d='M17.989 8.286h2.331v12h-2.331z' fill='#8e2eff'/><path d='M4 19.714h16.32V22H4z' fill='#00c5ff'/><path d='M4 2h9.326v2.286H4z' fill='#fff152'/><path d='M17.989 6.571V4.286h-2.332V2h-2.331v6.857h6.994V6.571' fill='#ff5b5b'/><path d='M17.989 11.143V8.857h2.331' fill='#551c99'/></g><path d='M13.326 2v2.286h-2.332' fill='#999131'/></g></svg>"
            ];
        }
        return $buttons;
    }

    public function editorButtonsHtml($buttons) {
        if ($this->options->isAllowedFormAndUser()) {
            $buttons .= "<span class='wpdiscuz-giphy-icon' title='" . esc_attr__("GIPHY", "wpdiscuz-giphy-integration") . "'>";
            $buttons .= "<svg width='18' height='18' xmlns='http://www.w3.org/2000/svg' viewBox='4 2 16.32 20'><g fill='none' fill-rule='evenodd'><path d='M6.331 4.286H17.99v15.428H6.33z' fill='#000'/><g fill-rule='nonzero'><path d='M4 3.714h2.331v16.572H4z' fill='#04ff8e'/><path d='M17.989 8.286h2.331v12h-2.331z' fill='#8e2eff'/><path d='M4 19.714h16.32V22H4z' fill='#00c5ff'/><path d='M4 2h9.326v2.286H4z' fill='#fff152'/><path d='M17.989 6.571V4.286h-2.332V2h-2.331v6.857h6.994V6.571' fill='#ff5b5b'/><path d='M17.989 11.143V8.857h2.331' fill='#551c99'/></g><path d='M13.326 2v2.286h-2.332' fill='#999131'/></g></svg>";
            $buttons .= "</span>";
        }
        return $buttons;
    }

    public function printPopup() {
        $wpdiscuz = wpDiscuz();
        if ($wpdiscuz->isWpdiscuzLoaded && $this->options->isAllowedFormAndUser()) {
            ?>
            <div id="wpdiscuz-giphy-popup-bg"></div>
            <div id="wpdiscuz-giphy-popup">
                <div id="wpdiscuz-giphy-search-wrapper">
                    <input type="text" name="wpdiscuz-giphy-search" id="wpdiscuz-giphy-search" placeholder="<?php esc_attr_e("Search GIPHY", "wpdiscuz-giphy-integration"); ?>">
                </div>
                <div id="wpdiscuz-giphy-links">
                    <a href="#" id="wpdiscuz-giphy-back-to-categories"><?php esc_html_e("&lsaquo; Back to Categories", "wpdiscuz-giphy-integration"); ?></a>
                </div>
                <div id="wpdiscuz-giphy-content"></div>
                <div id="wpdiscuz-giphy-powered-by"><img src="<?php echo plugins_url(WPD_GI_DIR_NAME); ?>/assets/img/PoweredByGiphy.png"></div>
            </div>
            <?php
        }
    }

    public function enqueueScripts($options) {
        $dep = [$options->general["loadComboVersion"] ? "wpdiscuz-combo-js" : "wpdiscuz-ajax-js"];
        $suf = $options->general["loadMinVersion"] ? ".min" : "";
        wp_register_style("wpdiscuz-giphy", plugins_url(WPD_GI_DIR_NAME . "/assets/css/wpdiscuz-giphy$suf.css"), [], $this->version);
        wp_enqueue_style("wpdiscuz-giphy");
        wp_register_script("wpdiscuz-giphy", plugins_url(WPD_GI_DIR_NAME . "/assets/js/wpdiscuz-giphy$suf.js"), $dep, $this->version, true);
        wp_enqueue_script("wpdiscuz-giphy");
        wp_localize_script("wpdiscuz-giphy", "wpDiscuzGiphyObj", [
            "key" => "YJCuQ2KSqDQ3RVooSGLbnBzimmUVqmE2",
            "lang" => $this->options->lang,
            "rating" => $this->options->rating,
            "limit" => $this->options->limit,
            "isAllowed" => $this->options->isAllowedFormAndUser(),
            "phraseTrending" => esc_html__("Trending", "wpdiscuz-giphy-integration"),
        ]);
    }

    public function enqueueWpForoScripts() {
        if (is_wpforo_page()) {
            $options = wpDiscuz()->options;
            $suf = $options->general["loadMinVersion"] ? ".min" : "";
            wp_register_style("wpdiscuz-giphy", plugins_url(WPD_GI_DIR_NAME . "/assets/css/wpdiscuz-giphy$suf.css"), [], $this->version);
            wp_enqueue_style("wpdiscuz-giphy");
        }
    }

    public function enqueueAdminScripts() {
        global $pagenow;
        if ($pagenow === WpdiscuzCore::PAGE_COMMENTS) {
            wp_register_style("wpdiscuz-giphy-admin", plugins_url(WPD_GI_DIR_NAME . "/assets/css/wpdiscuz-giphy-admin.css"), [], $this->version);
            wp_enqueue_style("wpdiscuz-giphy-admin");
            wp_register_script("wpdiscuz-giphy-admin", plugins_url(WPD_GI_DIR_NAME . "/assets/js/wpdiscuz-giphy-admin.js"), ["jquery"], $this->version, true);
            wp_enqueue_script("wpdiscuz-giphy-admin");
        }
    }

    public function requirements() {
        if (current_user_can("manage_options")) {
            echo "<div class='error'><p>" . __("wpDiscuz - Giphy Integration requires wpDiscuz to be installed!", "wpdiscuz-giphy-integration") . "</p></div>";
        }
    }

    public function pluginNewVersion() {
        $pluginData = get_plugin_data(__FILE__);
        if (version_compare($pluginData["Version"], $this->version, ">")) {
            update_option(self::OPTION_VERSION, $pluginData["Version"]);
        } else {
            add_option(self::OPTION_VERSION, "1.0.0", "", "no");
        }
    }

}

$wpDiscuzGiphyIntegration = wpDiscuzGiphyIntegration::getInstance();
