<?php
if (!defined("ABSPATH")) {
    exit();
}
?>
<div class="wpd-opt-row">
    <div class="wpd-opt-intro">
        <img class="wpd-opt-img" src="<?php echo plugins_url(WPD_GI_DIR_NAME) ?>/assets/img/giphy-logo.svg" style="height: 60px; padding-top: 5px;">
        GIPHY is an online GIF database. Its main product is GIF Keyboard. GIPHY provides with animated GIF images that users can embed in posts, messages, and in this case in comments.
        GIPHY is free. Check their terms of service and other guidelines – <a href="https://support.giphy.com/hc/en-us/articles/360020027752-GIPHY-User-Terms-of-Service" target="_blank">Terms of Service</a> and <a href="https://support.giphy.com/hc/en-us/articles/360028134111-GIPHY-API-Terms-of-Service-" target="_blank">API Terms</a>
    </div>
</div>

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="lang">
    <div class="wpd-opt-name">
        <label for="lang"><?php echo $setting["options"]["lang"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["lang"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
        <input type="text" name="<?php echo $setting["values"]->tabKey; ?>[lang]" value="<?php echo esc_attr($setting["values"]->lang); ?>" id="lang" style="margin:1px;padding:3px 5px; width:90%;"/>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="rating">
    <div class="wpd-opt-name">
        <label for="rating"><?php echo $setting["options"]["rating"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["rating"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
        <div class="wpd-radio">
            <input type="radio" value="g" <?php checked("g" === $setting["values"]->rating); ?> name="<?php echo $setting["values"]->tabKey; ?>[rating]" id="ratingOff" class="rating"/>
            <label for="ratingOff" class="wpd-radio-circle"></label>
            <label for="ratingOff"><?php esc_html_e("G", "wpdiscuz-giphy-integration") ?></label>
        </div>
        <div class="wpd-radio">
            <input type="radio" value="pg" <?php checked("pg" === $setting["values"]->rating); ?> name="<?php echo $setting["values"]->tabKey; ?>[rating]" id="ratingLow" class="rating"/>
            <label for="ratingLow" class="wpd-radio-circle"></label>
            <label for="ratingLow"><?php esc_html_e("PG", "wpdiscuz-giphy-integration") ?></label>
        </div>
        <div class="wpd-radio">
            <input type="radio" value="pg-13" <?php checked("pg-13" === $setting["values"]->rating); ?> name="<?php echo $setting["values"]->tabKey; ?>[rating]" id="ratingMedium" class="rating"/>
            <label for="ratingMedium" class="wpd-radio-circle"></label>
            <label for="ratingMedium"><?php esc_html_e("PG-13", "wpdiscuz-giphy-integration") ?></label>
        </div>
        <div class="wpd-radio">
            <input type="radio" value="r" <?php checked("r" === $setting["values"]->rating); ?> name="<?php echo $setting["values"]->tabKey; ?>[rating]" id="ratingHigh" class="rating"/>
            <label for="ratingHigh" class="wpd-radio-circle"></label>
            <label for="ratingHigh"><?php esc_html_e("R", "wpdiscuz-giphy-integration") ?></label>
        </div>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="limit">
    <div class="wpd-opt-name">
        <label for="limit"><?php echo $setting["options"]["limit"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["limit"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
        <input type="number" min="10" max="50" name="<?php echo $setting["values"]->tabKey; ?>[limit]" value="<?php echo esc_attr($setting["values"]->limit); ?>" id="limit" style="margin:1px;padding:3px 5px; width:90%;"/>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="playOnLoad">
    <div class="wpd-opt-name">
        <label for="playOnLoad"><?php echo esc_html($setting["options"]["playOnLoad"]["label"]); ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["playOnLoad"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
        <div class="wpd-switcher">
            <input type="checkbox" <?php checked($setting["values"]->playOnLoad == 1) ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[playOnLoad]" id="playOnLoad">
            <label for="playOnLoad"></label>
        </div>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="allowedForms">
    <div class="wpd-opt-name">
        <label for="allowedForms"><?php echo $setting["options"]["allowedForms"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["allowedForms"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
		<?php
		$forms = get_posts(["numberposts" => -1, "post_type" => "wpdiscuz_form", "post_status" => "publish"]);
		foreach ($forms as $form) {
			?>
            <div class="wpd-mublock-inline" style="width:95%;">
                <input type="checkbox" <?php checked(in_array($form->ID, $setting["values"]->allowedForms)); ?> value="<?php echo $form->ID; ?>" name="<?php echo $setting["values"]->tabKey; ?>[allowedForms][]" id="wti-form<?php echo $form->ID; ?>" style="margin:0px; vertical-align: middle;" />
                <label for="wti-form<?php echo $form->ID; ?>" style="white-space:nowrap; font-size:13px;"><?php echo $form->post_title ? esc_html($form->post_title) : __('no title', "wpdiscuz-giphy-integration") . ' ( ID : ' . $form->ID . ' )'; ?></label>
            </div>
			<?php
		}
		?>
    </div>
</div>
<!-- Option end -->

<!-- Option start -->
<div class="wpd-opt-row" data-wpd-opt="allowedUserRoles">
    <div class="wpd-opt-name">
        <label for="allowedUserRoles"><?php echo $setting["options"]["allowedUserRoles"]["label"] ?></label>
        <p class="wpd-desc"><?php echo $setting["options"]["allowedUserRoles"]["description"] ?></p>
    </div>
    <div class="wpd-opt-input">
		<?php
		foreach (get_editable_roles() as $role => $info) {
			?>
            <div class="wpd-mublock-inline" style="width: 45%;">
                <input type="checkbox" <?php checked(in_array($role, $setting["values"]->allowedUserRoles)); ?> value="<?php echo $role; ?>" name="<?php echo $setting["values"]->tabKey; ?>[allowedUserRoles][]" id="wti-<?php echo $role; ?>" style="margin:0px; vertical-align: middle;" />
                <label for="wti-<?php echo $role; ?>" style=""><?php echo $info["name"]; ?></label>
            </div>
			<?php
		}
		?>
        <div class="wpd-mublock-inline" style="width: 45%;">
            <input type="checkbox" <?php checked($setting["values"]->isGuestAllowed == 1); ?> value="1" name="<?php echo $setting["values"]->tabKey; ?>[isGuestAllowed]" id="wti-guest" style="margin:0px; vertical-align: middle;" />
            <label for="wti-guest" style=""><?php esc_html_e("Guest", "wpdiscuz-giphy-integration"); ?></label>
        </div>
    </div>
</div>
<!-- Option end -->