<?php

if (!defined("ABSPATH")) {
    exit();
}

class wpDiscuzGIOptions implements wpDiscuzGIConstants {

    public $tabKey = "wgi";
    public $lang;
    public $rating;
    public $limit;
    public $playOnLoad;
    public $allowedForms;
    public $allowedUserRoles;
    public $isGuestAllowed;

    public function __construct() {
        $this->addOption();
        $this->initOptions(get_option(self::OPTION_SLUG_OPTIONS, []));
        add_action("wpdiscuz_save_options", [&$this, "saveOptions"], 47);
        add_action("wpdiscuz_reset_options", [&$this, "resetOptions"], 47);
        add_filter("wpdiscuz_settings", [&$this, "settingsArray"], 47);
    }

    public function addOption() {
        add_option(self::OPTION_SLUG_OPTIONS, $this->getDefaultOptions(), "", "no");
    }

    public function initOptions($options) {
        $defaults = $this->getDefaultOptions();
        $this->lang = isset($options["lang"]) ? $options["lang"] : $defaults["lang"];
        $this->rating = isset($options["rating"]) ? $options["rating"] : $defaults["rating"];
        $this->limit = isset($options["limit"]) ? $options["limit"] : $defaults["limit"];
        $this->playOnLoad = isset($options["playOnLoad"]) ? $options["playOnLoad"] : $defaults["playOnLoad"];
        $this->allowedForms = isset($options["allowedForms"]) ? $options["allowedForms"] : $defaults["allowedForms"];
        $this->allowedUserRoles = isset($options["allowedUserRoles"]) ? $options["allowedUserRoles"] : $defaults["allowedUserRoles"];
        $this->isGuestAllowed = isset($options["isGuestAllowed"]) ? $options["isGuestAllowed"] : $defaults["isGuestAllowed"];
    }

    public function saveOptions() {
        if ($this->tabKey === $_POST["wpd_tab"]) {
            $defaults = $this->getDefaultOptions();
            $this->lang = !empty($_POST[$this->tabKey]["lang"]) ? strip_tags(stripslashes($_POST[$this->tabKey]["lang"])) : $defaults["lang"];
            $this->rating = !empty($_POST[$this->tabKey]["rating"]) ? trim($_POST[$this->tabKey]["rating"]) : $defaults["rating"];
            $this->limit = !empty($_POST[$this->tabKey]["limit"]) ? intval($_POST[$this->tabKey]["limit"]) : $defaults["limit"];
            if ($this->limit < 10) {
                $this->limit = 10;
            } else if ($this->limit > 50) {
                $this->limit = 50;
            }
            $this->playOnLoad = !empty($_POST[$this->tabKey]["playOnLoad"]) ? intval($_POST[$this->tabKey]["playOnLoad"]) : 0;
            $this->allowedForms = !empty($_POST[$this->tabKey]["allowedForms"]) && is_array($_POST[$this->tabKey]["allowedForms"]) ? $_POST[$this->tabKey]["allowedForms"] : [];
            $this->allowedUserRoles = !empty($_POST[$this->tabKey]["allowedUserRoles"]) && is_array($_POST[$this->tabKey]["allowedUserRoles"]) ? $_POST[$this->tabKey]["allowedUserRoles"] : [];
            $this->isGuestAllowed = !empty($_POST[$this->tabKey]["isGuestAllowed"]) ? intval($_POST[$this->tabKey]["isGuestAllowed"]) : 0;
            update_option(self::OPTION_SLUG_OPTIONS, $this->getOptionsArray());
        }
    }

    public function resetOptions($tab) {
        if ($tab === $this->tabKey || $tab === "all") {
            delete_option(self::OPTION_SLUG_OPTIONS);
            $this->addOption();
            $this->initOptions($this->getDefaultOptions());
        }
    }

    public function getDefaultOptions() {
        $formIDs = [];
        $forms = get_posts([
            "numberposts" => -1,
            "post_type" => "wpdiscuz_form",
            "post_status" => "publish"
        ]);
        foreach ($forms as $form) {
            $formIDs[] = $form->ID;
        }
        return [
            "lang" => "en",
            "rating" => "g",
            "limit" => 10,
            "playOnLoad" => 1,
            "allowedForms" => $formIDs,
            "allowedUserRoles" => ["administrator", "editor", "author", "contributor", "subscriber"],
            "isGuestAllowed" => 0,
        ];
    }

    public function getOptionsArray() {
        return [
            "lang" => $this->lang,
            "rating" => $this->rating,
            "limit" => $this->limit,
            "playOnLoad" => $this->playOnLoad,
            "allowedForms" => $this->allowedForms,
            "allowedUserRoles" => $this->allowedUserRoles,
            "isGuestAllowed" => $this->isGuestAllowed,
        ];
    }

    public function settingsArray($settings) {
        $settings["addons"][$this->tabKey] = [
            "title" => __("Giphy Integration", "wpdiscuz-giphy-integration"),
            "title_original" => "Giphy Integration",
            "icon" => "",
            "icon-height" => "",
            "file_path" => WPD_GI_PATH . "/options/html-options.php",
            "values" => $this,
            "options" => [
                "lang" => [
                    "label" => __("Language", "wpdiscuz-giphy-integration"),
                    "label_original" => "Language",
                    "description" => __("<a href='https://developers.giphy.com/docs/optional-settings#language-support' target='_blank'>Supported Languages</a>", "wpdiscuz-giphy-integration"),
                    "description_original" => "<a href='https://developers.giphy.com/docs/optional-settings#language-support' target='_blank'>Supported Languages</a>",
                    "docurl" => "#"
                ],
                "rating" => [
                    "label" => __("GIF rating", "wpdiscuz-giphy-integration"),
                    "label_original" => "GIF rating",
                    "description" => __("<a href='https://developers.giphy.com/docs/optional-settings/#rating' target='_blank'>Content Rating</a>", ""),
                    "description_original" => "<a href='https://developers.giphy.com/docs/optional-settings/#rating' target='_blank'>Content Rating</a>",
                    "docurl" => "#"
                ],
                "limit" => [
                    "label" => __("Limit GIFs on gif picker popup window", "wpdiscuz-giphy-integration"),
                    "label_original" => "Limit GIFs on gif picker popup window",
                    "description" => "",
                    "description_original" => "",
                    "docurl" => "#"
                ],
                "playOnLoad" => [
                    "label" => __("Autoplay GIF animations on comments", "wpdiscuz-giphy-integration"),
                    "label_original" => "Play GIFs on Page Load",
                    "description" => "",
                    "description_original" => "",
                    "docurl" => "#"
                ],
                "allowedForms" => [
                    "label" => __("Allow GIFs for Comment Forms", "wpdiscuz-giphy-integration"),
                    "label_original" => "Allow GIFs for Comment Forms",
                    "description" => "",
                    "description_original" => "",
                    "docurl" => "#"
                ],
                "allowedUserRoles" => [
                    "label" => __("Allow user roles to embed GIFs in comments", "wpdiscuz-giphy-integration"),
                    "label_original" => "Allow user roles to embed GIFs in comments",
                    "description" => "",
                    "description_original" => "",
                    "docurl" => "#"
                ],
            ],
        ];
        return $settings;
    }

    public function isAllowedFormAndUser() {
        global $post;
        $wpdiscuz = wpDiscuz();
        $form = !empty($post->ID) ? $wpdiscuz->wpdiscuzForm->getForm($post->ID) : null;
        $allowedUser = false;
        $currentUser = WpdiscuzHelper::getCurrentUser();
        if (!empty($currentUser->ID)) {
            if (!empty($currentUser->roles)) {
                foreach ($currentUser->roles as $k => $val) {
                    if (in_array($val, $this->allowedUserRoles)) {
                        $allowedUser = true;
                        break;
                    }
                }
            } else {
                foreach ($this->allowedUserRoles as $val) {
                    if (current_user_can($val)) {
                        $allowedUser = true;
                        break;
                    }
                }
            }
        } else if ($this->isGuestAllowed) {
            $allowedUser = true;
        }
        return $allowedUser && $form && in_array($form->getFormID(), $this->allowedForms);
    }

}
