=== wpDiscuz - GIPHY Integration ===
Contributors: gVectors Team
Requires at least: 5.0
Tested up to: 6.2
Stable tag: 1.0.4
Requires PHP: 5.4 and higher
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

This addon brings live to your comments with hundreds of thousands of hilarious 
GIFs provided by GIPHY API. GIPHY is the API that delivers the most relevant 
GIFs for any application, anywhere in the world. Its main product is GIF Keyboard. 
GIPHY provides with animated GIF images that users can embed in posts, messages, 
and in this case in comments. wpDiscuz – GIPHY Integration addon adds [GIF] 
button on the toolbar of comment editor. Clicking this will open a new popup 
where you can search for your favorite gifs and insert them in your comment content.