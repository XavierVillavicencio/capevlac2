=== wpDiscuz - myCRED Integration ===
Contributors: gVectors Team
Requires at least: 5.0
Tested up to: 6.0
Stable tag: 7.0.6
Requires PHP: 5.4 and higher
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

This addon integrates wpDiscuz with myCRED plugin. myCRED is an adaptive points 
management tool to help you build reward programs, monetize your website or just 
reward users with points for posting comments or publishing content. And now you 
can use this system with wpDiscuz comment plugin. This addon allows these two 
awesome plugins work together. Comment authors get points if their comments have 
been liked/voted up, and they’ll loss points in cases  dislikes/down votes. 
This «Like to Point» feature also works for voters, they can get certain amount 
of points for comment voting. wpDiscuz – myCRED Integration addon also displays 
member badges and ranks under comment author avatar and label.