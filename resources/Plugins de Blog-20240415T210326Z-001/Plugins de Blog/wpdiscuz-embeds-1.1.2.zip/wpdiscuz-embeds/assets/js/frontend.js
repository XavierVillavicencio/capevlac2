//jQuery(document).ready(function ($) {
//    function weInitEmbeds() {
//        
//    }
//   wpdiscuzAjaxObj.wmuImagesInit = weInitEmbeds; 
//});