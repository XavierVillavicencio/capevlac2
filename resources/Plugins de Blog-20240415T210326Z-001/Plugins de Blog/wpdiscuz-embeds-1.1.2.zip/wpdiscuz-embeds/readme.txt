=== wpDiscuz - Embeds ===
Contributors: gVectors Team
Requires at least: 5.0
Tested up to: 6.2
Stable tag: 1.1.2
Requires PHP: 5.4 and higher
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

wpDiscuz Embeds addon allows to embed hundreds of video, social network, audio 
and photo content providers in comments and replies. More than 30 video 
providers: Youtube, Vimeo, Dailymotion, Rutube, Vevo, Vesti, Metacafe, Liveleak, 
Funnyordie, Dotsub, Scribd, Citytv, Snotr, Wat, Novamov, Youku, Putlocker, Veoh, 
Zappinternet, Dalealplay, Zkouknito, Allocine, Break, Vzaar, 4shared, Movshare, 
Shiatv, etc… Hundreds of audio, social network, audio and photo content 
providers: SoundCloud, Flickr, Twitter, etc… 
Includes all embedding options of oEmbed Project. 
Extended control over all video providers.