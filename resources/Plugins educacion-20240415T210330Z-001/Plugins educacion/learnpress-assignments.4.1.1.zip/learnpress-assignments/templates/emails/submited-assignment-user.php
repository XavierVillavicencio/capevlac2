{{header}}

<p>Dear <strong>{{user_name}},</strong></p>

<p>You just submitted assignment "{{assignment_name}}" in <a href="{{course_url}}">{{course_name}}</a>.</p>

<p>Click <a href="{{course_url}}">{{course_name}}</a> to see more. Thanks you</p>

{{footer}}