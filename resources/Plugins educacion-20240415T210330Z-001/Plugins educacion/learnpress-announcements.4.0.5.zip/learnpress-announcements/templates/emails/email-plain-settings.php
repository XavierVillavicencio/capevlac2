== {{email_heading}} ==

Dear {{user_name}},

You have a new announcements "{{announcement_name}}" {{course_url}} ({{course_name}}).

Click {{course_url}} ({{course_name}}) to see more. Thanks you.

{{footer_text}}