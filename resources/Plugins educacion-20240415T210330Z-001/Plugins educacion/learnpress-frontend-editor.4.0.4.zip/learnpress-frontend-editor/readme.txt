=== LearnPress - Frontend Editor Plugin ===
Contributors: thimpress, nhamdv
Donate link:
Tags: education, backend manager courses.
Requires at least: 5.6
Tested up to: 6.0
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==

== Changelog ==

= 4.0.4 =
~ Add: Add new filter `learnpress_frontend_editor_localize_script` to allow edit localizations ( override logo url... ).
~ Fix: translate text.
~ Fix: some css.

= 4.0.3 (2022-09-29) =
~ Fix: error save meta field.

= 4.0.2 (2022-09-22) =
- Use tech React JS for create, edit, update faster.

